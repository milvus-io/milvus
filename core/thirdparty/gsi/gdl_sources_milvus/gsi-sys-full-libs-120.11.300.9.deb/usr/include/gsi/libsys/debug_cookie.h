/*
 * Copyright (C) 2016, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */
#ifndef GSI_DEBUG_COOKIE_H
#define GSI_DEBUG_COOKIE_H

#include <stddef.h>

struct gsi_debug_module_cookie {
	const char *module_name;
	int *module_level;
};

/*
 * gsi_debug_register_modules() has to be weak in case debug-crt.o is
 * linked when libgsisys is not.
 */
__attribute__((weak)) void gsi_debug_register_modules(struct gsi_debug_module_cookie *cookies, size_t num_cookies);

#endif /* GSI_DEBUG_COOKIE_H */
