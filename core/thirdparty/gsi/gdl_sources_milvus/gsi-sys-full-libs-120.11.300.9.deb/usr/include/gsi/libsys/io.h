/*
 * Copyright (C) 2016, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */

#ifndef GSI_IO_H
#define GSI_IO_H

// #include "config.h"

#if defined(GSI_LIBSYS_AARCH64) || defined(GSI_LIBSYS_X86_64) || defined(GSI_LIBSYS_X86_32)

#include <sys/stat.h>
#include <fcntl.h>
#include <poll.h>
#include <stdio.h>

#include <gsi/libsys/error.h>

#ifndef PATH_MAX
#define PATH_MAX 4096
#endif

typedef FILE GSI_FILE;

/*
 * Open functions return GSI_FILE * on success or encoded ERR_PTR on failure
 */
extern GSI_FILE *gsi_fopen(const char *path, const char *omode);
extern GSI_FILE *gsi_freopen(const char *path, const char *omode, GSI_FILE *fp);
extern gsi_status_t gsi_fclose(GSI_FILE *fp);

extern void gsi_fclearerr(GSI_FILE *fp);
extern bool gsi_feof(GSI_FILE *fp, bool do_clearerr);
extern gsi_status_t gsi_ferror(GSI_FILE *fp, bool do_clearerr);

/*
 * Note: @bytes must by greater than 0
 *
 * Return:
 * 	On success: positive number of bytes read from file
 * 	            (maybe be less than @bytes if hit EOF)
 * 	On failure: negative error
 */
extern ssize_t gsi_fread(GSI_FILE *fp, void *buf, ssize_t bytes);

/*
 * Return:
 * 	On success: positive number of bytes written to file
 * 	            (must be equal to @bytes)
 * 	On failure: negative error
 */
extern ssize_t gsi_fwrite(GSI_FILE *fp, void *buf, ssize_t bytes);

void gsi_frewind(GSI_FILE *fp);

enum gsi_seek_whence {
	GSI_SEEK_SET = SEEK_SET,
	GSI_SEEK_CUR = SEEK_CUR,
	GSI_SEEK_END = SEEK_END,
};

/*
 * Return current file position after seek if successful, or negative error otherwise
 */
extern long gsi_fseek(GSI_FILE *fp, long offset, enum gsi_seek_whence);
extern long gsi_ftell(GSI_FILE *fp);

gsi_status_t gsi_read_line(GSI_FILE *in_file, char *buf, size_t buf_size);
gsi_status_t gsi_write_line(GSI_FILE *out_file, const char *s);
gsi_status_t gsi_fprintf(GSI_FILE *out_file, const char *fmt, ...) __attribute__((format(printf, 2, 3)));;
#define gsi_printf(...)	gsi_fprintf(stdout, __VA_ARGS__)

GSI_FILE *gsi_cpp_pipe(const char *fname);
GSI_FILE *gsi_cpp_pipe_vopts(char *const vopts[], char *fname);
GSI_FILE *gsi_cpp_pipe_opts(char *opts, char *fname);

gsi_status_t gsi_mkdir(const char *path, int mode, bool may_exist);
gsi_status_t gsi_mkdirs(const char *p_path, int mode, bool may_exist);
gsi_status_t gsi_rmdir(const char *path);
gsi_status_t gsi_rmdirs(const char *path, int num_keep);

/*
 * Simple wrappers around read()/write() that retry on EINTR
 *
 * If @persist == true, don't return until @bytes are read/written or an error/EOF happens, and also retry on EAGAIN &
 * EWOULDBLOCK.  Note that in that case *@count may be non-zero even when an error status is returned
 *
 * Out parameters:
 * 	Total bytes read/written in the location pointed at by @count, if not null
 * 	(For read()) EOF in the location pointed at by @eof, if not null
 */
gsi_status_t gsi_read(int fd, void *buf, size_t bytes, bool persist, size_t *count, bool *eof);
gsi_status_t gsi_write(int fd, const void *buf, size_t bytes, bool persist, size_t *count);

/*
 * Simple wrapper around poll() that retries on EINTR
 */
int gsi_poll(struct pollfd *fds, nfds_t nfds, int timeout);

#endif /* defined(GSI_LIBSYS_AARCH64) || defined(GSI_LIBSYS_X86_64) || defined(GSI_LIBSYS_X86_32) */

#endif /* GSI_IO_H */
