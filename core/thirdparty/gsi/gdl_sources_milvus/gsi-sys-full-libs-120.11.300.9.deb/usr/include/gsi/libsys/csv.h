/*
 * Copyright (C) 2016, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */
#include <gsi/libsys/config.h>

#if defined(GSI_LIBSYS_X86_64) || defined(GSI_LIBSYS_X86_32)

#ifndef GSI_CSV_H
#define GSI_CSV_H

#include <stdio.h>
#include <string.h>

#include <gsi/libsys/error.h>

enum {
	GSI_CSV_MAX_DIM = 3,
	GSI_CSV_STR_LEN = 32,
};

enum gsi_csv_field_type {
	GSI_CSV_FIELD_TYPE_INT,
	GSI_CSV_FIELD_TYPE_FLOAT,
	GSI_CSV_FIELD_TYPE_STR,
};

struct gsi_csv_int_val {
	long i;
	bool undefined;
};

union gsi_csv_value {
	struct gsi_csv_int_val i_val;
	double f_val;
	char s_val[GSI_CSV_STR_LEN];
};

struct gsi_csv_field {
	const char *desc;
	size_t desc_len;
	enum gsi_csv_field_type type;
	union gsi_csv_value range_from;
	union gsi_csv_value range_to;
	/* app specific */
	int id;
	int idx_max;
};

struct gsi_csv_hdr_field {
	struct gsi_csv_field *field;
	int idx[GSI_CSV_MAX_DIM];
	int ndim;
};

struct gsi_csv_header {
	int count;
	int fields_allocated;
	int values_allocated;
	struct gsi_csv_hdr_field *hdr_fields;
	union gsi_csv_value *values;
};

#define _CSV_FLD(_name_, _type_, _id_)			{ .desc=_name_, .type=_type_, .id=_id_ }
#define CSV_FLD(_name_, _id_)				_CSV_FLD(_name_, GSI_CSV_FIELD_TYPE_INT, _id_)
#define CSV_FLD_RANGE		CSV_FLD_INT_RANGE
#define CSV_FLD_RANGE_ARRAY	CSV_FLD_INT_RANGE_ARRAY
#define CSV_FLD_BIT(_name_, _id_)			CSV_FLD_INT_RANGE(_name_, 0, 1, _id_)
#define CSV_FLD_BIT_ARRAY(_name_, _id_, _idx_max_)	CSV_FLD_INT_RANGE_ARRAY(_name_, 0, 1, _id_, _idx_max_)
#define CSV_FLD_INT_RANGE(_name_, _from_, _to_, _id_)			{ .desc=_name_, .type=GSI_CSV_FIELD_TYPE_INT, .range_from.i_val.i=_from_, .range_to.i_val.i=_to_, .id=_id_ }
#define CSV_FLD_INT_RANGE_ARRAY(_name_, _from_, _to_, _id_, _idx_max_)	{ .desc=_name_, .type=GSI_CSV_FIELD_TYPE_INT, .range_from.i_val.i=_from_, .range_to.i_val.i=_to_, .id=_id_, .idx_max=_idx_max_ }
#define CSV_FLD_FLOAT_RANGE(_name_, _from_, _to_, _id_)				{ .desc=_name_, .type=GSI_CSV_FIELD_TYPE_FLOAT, .range_from.f_val=_from_, .range_to.f_val=_to_, .id=_id_ }
#define CSV_FLD_FLOAT_RANGE_ARRAY(_name_, _from_, _to_, _id_, _idx_max_)	{ .desc=_name_, .type=GSI_CSV_FIELD_TYPE_FLOAT, .range_from.f_val=_from_, .range_to.f_val=_to_, .id=_id_, .idx_max=_idx_max_ }
#define CSV_FLD_STR(_name_, _id_)			_CSV_FLD(_name_, GSI_CSV_FIELD_TYPE_STR, _id_)
#define CSV_FLD_LAST					{ NULL }

extern gsi_status_t gsi_csv_init_header_fields(struct gsi_csv_header *header, int size);
extern gsi_status_t gsi_csv_init_header(struct gsi_csv_header *header, int size);

extern struct gsi_csv_field *gsi_csv_search_id(struct gsi_csv_field *dict, int id);

/*
 * Parse the csv header @line using the null-terminated @dict array.
 *
 * If successful, return parsed fields in allocated result,
 * Otherwise, return error ptr.
 *
 * Note that the desc members of @headers are strdup'ed and must be freed later on
 * using gsi_csv_free_header
 */
extern gsi_status_t gsi_csv_read_header(char *line, struct gsi_csv_field *dict, struct gsi_csv_header *header);
extern void gsi_csv_free_header(struct gsi_csv_header *header);

/*
 * Parse a csv value @line using the null-terminated @header array.
 *
 * If successful, return parsed fields in @values and return 0,
 * Otherwise, return error.
 *
 * Note that string members of @values are strdup'ed and must be freed later on
 * using gsi_csv_free_values
 */
extern gsi_status_t gsi_csv_read_values(char *line, struct gsi_csv_header *header);

/*
 * Parse from @in_file both the header line and a line of values
 * Return fields and values in @header on success, otherwise return negative status.
 */
extern gsi_status_t gsi_csv_read_file(FILE *in_file, struct gsi_csv_field *dict, struct gsi_csv_header *header);

extern gsi_status_t gsi_csv_fprint_fields(FILE *fp, struct gsi_csv_header *header);
extern gsi_status_t gsi_csv_fprint_values(FILE *fp, struct gsi_csv_header *header);

#endif /* GSI_CSV_H */

#endif /* defined(GSI_LIBSYS_X86_64) || defined(GSI_LIBSYS_X86_32) */
