/*
 * Copyright (C) 2016, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */
#ifndef GSI_TEST_H
#define GSI_TEST_H

#include "assert.h"
#include "log.h"

static inline void gsi_test_log_init(void)
{
	if (!gsi_min_log_level)
		gsi_min_log_level = GSI_LOG_DEBUG;
}

#define gsi_test_log(...) 	gsi_log(__VA_ARGS__)
#define gsi_test_log_begin()	gsi_test_log("BEGIN");
#define gsi_test_log_success()	gsi_test_log("PASS");
#define gsi_test_log_fail()	gsi_test_log("FAIL");

#define _GSI_TEST_ASSERT(e, failok)	(failok ? GSI_ASSERT_WARN(e) : GSI_ASSERT_ABORT(e))
#define GSI_TEST_ASSERT(e) _GSI_TEST_ASSERT(e, false)

#endif /* GSI_TEST_H */
