/*
 * Copyright (C) 2016, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */
#ifndef GSI_LIBSYS_ARC_HS_36_H
#define GSI_LIBSYS_ARC_HS_36_H

#include <gsi/libsys/config.h>

#include <gsi/libsys/atomic.h>
#include <gsi/libsys/types.h>
#include <gsi/libsys/debug.h>
#include <gsi/libsys/error.h>
#include <gsi/libsys/assert.h>
#include <gsi/libsys/endian.h>
#include <gsi/libsys/log.h>
#include <gsi/libsys/test.h>
#include <gsi/libsys/pool.h>
#include <gsi/libsys/buf.h>
// #include <gsi/libsys/gsi_arc_cache.h>

extern void gsi_libsys_exit(void);
extern int gsi_exit_status;

#endif /* GSI_LIBSYS_ARC_HS_36_H */
