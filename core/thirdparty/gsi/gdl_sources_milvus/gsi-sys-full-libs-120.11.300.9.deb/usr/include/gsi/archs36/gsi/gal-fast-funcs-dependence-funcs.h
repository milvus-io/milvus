/*
 * Copyright (C) 2020, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */

#ifndef GAL_FAST_FUNCS_DEPENDENCE_FUNCS_H_
#define GAL_FAST_FUNCS_DEPENDENCE_FUNCS_H_

#include <gsi/libgal.h>

#define GAL_FAST_L2DMA_TIMEOUT 100000
#define GAL_FAST_DIV_ROUND_UP(a, b) (((a) + ((b) - 1)) / (b))

#define gal_fast_apuc_cond(cond)		test_barrier(cond)

enum gal_fast_apuc_cond {
	/* rsp-fifo not empty */
	GAL_FAST_APUC_COND_RSP_FIFO_A,
	GAL_FAST_APUC_COND_RSP_FIFO_B,

	GAL_FAST_APUC_COND_L2DMA_CMD_FIFO_FULL_A,
	GAL_FAST_APUC_COND_L2DMA_CMD_FIFO_FULL_B,

	GAL_FAST_APUC_COND_L2_READY_A,
	GAL_FAST_APUC_COND_L2_READY_B,
};

//defines for Indirect DMA
#define GAL_FAST_DB_BASE_ADDR 										0xF3200010
#define GAL_FAST_MB0_ADDRESS										0xF1100000
#define GAL_FAST_DB_MASK_ENABLE  									0xF1200184
#define GAL_FAST_MB_READ_CMD_OFFSET 								0x0
#define GAL_FAST_MB_WRITE_CMD_OFFSET 								0x200
#define GAL_FAST_INDIRECT_RD_REQUEST_IN_PROGRESS_GPR4_REG_ADDRESS	0XF0000220
#define GAL_FAST_INDIRECT_WR_REQUEST_IN_PROGRESS_GPR5_REG_ADDRESS	0XF0000228
#define GAL_FAST_MB_CONTROL_WORD_OFFSET 							0x00
#define GAL_FAST_MB_L2T_MODE_CONTROL_WORD_OFFSET 					0x04
#define GAL_FAST_MB_L4_STEP_STRIDE_OFFSET 							0x8
#define GAL_FAST_MB_L4_ADDRS_APC_A_OFFSET 							0x0C
#define GAL_FAST_MB_L4_ADDRS_APC_B_OFFSET 							0x10C
#define GAL_FAST_WRITE_DB_OFFSET									0x4
#define GAL_FAST_READ_DB_OFFSET										0x0
#define GAL_FAST_CORE_BIT_MASK										0x3

#define GAL_FAST_RFU_L2_A_CMD_LO_REG 0xF0000300
#define GAL_FAST_RFU_L2_B_CMD_LO_REG 0xF0000380
#define GAL_FAST_RFU_L2_A_CMD_HI_REG 0xF0000308
#define GAL_FAST_RFU_L2_B_CMD_HI_REG 0xF0000388
#define GAL_FAST_RFU_L2_A_CMD_ADDR_REG 0xF0000310
#define GAL_FAST_RFU_L2_B_CMD_ADDR_REG 0xF0000390


//bit 31
#define GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK (1 << 31)

//bit30
#define GAL_FAST_L2DMA_CMD_LOW_PSEL_DMC_MASK (1 << 30)
#define GAL_FAST_L2DMA_CMD_LOW_PSEL_NO_DMC_MASK (0 << 30)

//bits 29,28
#define GAL_FAST_L2DMA_CMD_LOW_CMD_TYPE_RDSYS_MASK (0 << 28)
#define GAL_FAST_L2DMA_CMD_LOW_CMD_TYPE_WRSYS_MASK (1 << 28)
#define GAL_FAST_L2DMA_CMD_LOW_CMD_TYPE_MCRDL2_MASK (2 << 28)
#define GAL_FAST_L2DMA_CMD_LOW_CMD_TYPE_MCWRL2_MASK (3 << 28)

//bit 27,26
#define GAL_FAST_L2DMA_CMD_LOW_SYS_BURST8_MASK (0 <<26)
#define GAL_FAST_L2DMA_CMD_LOW_SYS_BURST16_MASK (1 <<26)
#define GAL_FAST_L2DMA_CMD_LOW_SYS_BURST32_MASK (2 <<26)
#define GAL_FAST_L2DMA_CMD_LOW_SYS_BURST64_MASK (3 <<26)

//bits 25,24
#define GAL_FAST_L2DMA_CMD_L2_READY_ATTR_BIT 24
#define GAL_FAST_L2DMA_CMD_L2_READY_ATTR_MASK (3 << GAL_FAST_L2DMA_CMD_L2_READY_ATTR_BIT)

#define GAL_FAST_L2DMA_CMD_LOW_ATTRIBUTE_CMD_NOP_MASK (0 << 24)
#define GAL_FAST_L2DMA_CMD_LOW_ATTRIBUTE_CMD_RESERVED_MASK (1 << 24)
#define GAL_FAST_L2DMA_CMD_LOW_ATTRIBUTE_CMD_RST_READY_MASK (2 << 24)
#define GAL_FAST_L2DMA_CMD_LOW_ATTRIBUTE_CMD_SET_READY_MASK (3 << 24)

//bits 23,22-number of bursts per transaction.
#define GAL_FAST_L2DMA_CMD_LOW_NUM_OF_BURST1_MASK (0 << 22)
#define GAL_FAST_L2DMA_CMD_LOW_NUM_OF_BURST2_MASK (1 << 22)
#define GAL_FAST_L2DMA_CMD_LOW_NUM_OF_BURST4_MASK (2 << 22)
#define GAL_FAST_L2DMA_CMD_LOW_NUM_OF_BURST8_MASK (3 << 22)

//This field apply to MC* and WRL2 command
//types:
//The number of
//command execution
//iterations NumRep =
//NumRep_Reg+1.
//bits 21-16
#define GAL_FAST_L2DMA_CMD_NUM_REP_BIT 16
#define GAL_FAST_L2DMA_CMD_NUM_REP_MASK (0x3F << GAL_FAST_L2DMA_CMD_NUM_REP_BIT)

//bit 15
#define GAL_FAST_L2DMA_CMD_LOW_IRQ_EN_MASK (1 << 15)
//bits 14-8
#define GAL_FAST_L2DMA_CMD_LOW_ROW_ADDR_MASK (0x7F << 8)

//bits 7-6
#define GAL_FAST_L2DMA_CMD_LOW_L2T_MODE8 (0<<6)
#define GAL_FAST_L2DMA_CMD_LOW_L2T_MODE16 (1<<6)
#define GAL_FAST_L2DMA_CMD_LOW_L2T_MODE32 (2<<6)
#define GAL_FAST_L2DMA_CMD_LOW_L2T_MODE64 (3<<6)

//bits 5-0
#define GAL_FAST_L2DMA_CMD_COLGRP_ADDR_BIT 0
#define GAL_FAST_L2DMA_CMD_COLGRP_ADDR_MASK 0x3F

#define GAL_FAST_L2DMA_CMD_HI_SET_INDIRECT (1 << 16)

#define GAL_FAST_CACHE_LINE_SIZE (32)

#define GAL_FAST_DC_IVDC		0x0047 /* Invalidate Data Cache */
#define GAL_FAST_DC_CTRL		0x0048 /* Control register */
#define GAL_FAST_DC_LDL		0x0049 /* Lock data line */
#define GAL_FAST_DC_IVDL		0x004a /* Invalidate data line */
#define GAL_FAST_DC_FLSH		0x004b /* Flush data cache */
#define GAL_FAST_DC_FLDL		0x004c /* Flush data line */
#define GAL_FAST_DC_STARTR		0x004d /* Data-Cache Region Start Address */
#define GAL_FAST_DC_ENDR		0x004e /* Data-Cache Region End Address */

#define _gal_fast_common_aux_rd(aux)              _lr(aux)
#define _gal_fast_common_aux_wr(aux, val)        _sr(val, aux)

/* The DMA engines (particularly the indirect DMA) can sometimes stop working, as a result
 * of mismanaged queues etc. which suggest that there is a bug in the System libraries.
 * This code helps to diagnose specific situation: if the device appears to hang the BUSY_LOOP()
 * will eventually print an error message.
 */
#ifdef DMA_DIAGNOSIS
#define NUM_ITERS_BEWTEEN_LOGS	(4 * 400000000)
#define BUSY_LOOP() \
	if (busy_loop_count++ == NUM_ITERS_BEWTEEN_LOGS) {\
		gsi_log("%d: clean_queue failed", __LINE__);\
		busy_loop_count = 0;\
	}
#else
#define BUSY_LOOP()
#endif	/* DMA_DIAGNOSIS */

static inline __attribute__((always_inline)) u32 gal_fast_common_cpu_lock_save(void)
{
	return _clri();
}

static inline __attribute__((always_inline)) void gal_fast_common_cpu_unlock_restore(const u32 status)
{
	_seti(status);
}

#define GAL_FAST_DC_IVDC_IV_MASK (1 << 0)
#define GAL_FAST_DC_CTRL_IM_MASK (1 << 6)
#define GAL_FAST_DC_CTRL_FS_MASK (1 << 8)

static inline __attribute__((always_inline)) void gal_fast_cache_dcache_invalidate_and_flush(void)
{
	u32 status;

	status = gal_fast_common_cpu_lock_save();
	_gal_fast_common_aux_wr(GAL_FAST_DC_CTRL, GAL_FAST_DC_CTRL_IM_MASK);
	_gal_fast_common_aux_wr(GAL_FAST_DC_IVDC, GAL_FAST_DC_IVDC_IV_MASK);
	/* wait for flush completion */
	while (_gal_fast_common_aux_rd(GAL_FAST_DC_CTRL) & GAL_FAST_DC_CTRL_FS_MASK);
	gal_fast_common_cpu_unlock_restore(status);
}

static inline __attribute__((always_inline)) int gal_fast_cache_dcache_flush_mlines(u32 start_addr, u32 size)
{
	u32 end_addr;
	u32 status;

	end_addr = start_addr + size - 1;
	start_addr &= (u32)(~(u32)(GAL_FAST_CACHE_LINE_SIZE - 1));

	status = gal_fast_common_cpu_lock_save();
	do {
		_gal_fast_common_aux_wr(GAL_FAST_DC_FLDL, start_addr);
		__asm__ volatile("nop_s");
		__asm__ volatile("nop_s");
		__asm__ volatile("nop_s");
		/* wait for flush completion */
// 		while (_garc_common_aux_rd(DC_CTRL) & DC_CTRL_SB_MASK);
		start_addr += GAL_FAST_CACHE_LINE_SIZE;
	} while (start_addr <= end_addr);
	gal_fast_common_cpu_unlock_restore(status);

	return 0;
}

static inline __attribute__((always_inline)) int gal_fast_cache_dcache_invalidate_mlines(u32 start_addr, u32 size)
{
	u32 end_addr;
	u32 status;

	end_addr = start_addr + size - 1;
	start_addr &= (u32)(~(u32)(GAL_FAST_CACHE_LINE_SIZE - 1));

	status = gal_fast_common_cpu_lock_save();
	do {
		_gal_fast_common_aux_wr(GAL_FAST_DC_CTRL, 0);
		_gal_fast_common_aux_wr(GAL_FAST_DC_IVDL, start_addr);
		__asm__ volatile("nop_s");
		__asm__ volatile("nop_s");
		__asm__ volatile("nop_s");
		/* wait for invalidate completion */
//		while (!(_garc_common_aux_rd(DC_CTRL) & DC_CTRL_SB_MASK));
		start_addr += GAL_FAST_CACHE_LINE_SIZE;
	} while (start_addr <= end_addr);
	gal_fast_common_cpu_unlock_restore(status);

	return 0;
}

/*
 * Write uncached u32 data
 */
static inline __attribute__((always_inline)) void gal_fast_cache_uc_u32_wr(u32 addr, u32 data)
{
	*(volatile _Uncached u32 *)addr = data;
}

/*
 * Read uncached u32 data
 */
static inline __attribute__((always_inline)) u32 gal_fast_cache_uc_u32_rd(u32 addr)
{
	return *(volatile _Uncached u32 *)addr;
}

/*
 * func name : apc_l2dma_set_cmd_lo_reg_uc().
 * description : write l2dma low command RFU reg.
 * param : uint32_t val - address  .
 * return value : none.
 */
static inline __attribute__((always_inline)) void apc0_l2dma_set_cmd_lo_reg_uc(uint32_t val)
{
	gal_fast_cache_uc_u32_wr(GAL_FAST_RFU_L2_A_CMD_LO_REG, val);
}
static inline __attribute__((always_inline)) void apc1_l2dma_set_cmd_lo_reg_uc(uint32_t val)
{
	gal_fast_cache_uc_u32_wr(GAL_FAST_RFU_L2_B_CMD_LO_REG, val);
}

/*
 * func name : apc_l2dma_get_cmd_lo_reg_uc().
 * description : get  l2dma low command RFU reg.
 * param : uint32_t val - address  .
 * return value : uint32_t - rfu reg value.
 */
static inline __attribute__((always_inline)) uint32_t apc0_l2dma_get_cmd_lo_reg_uc(void)
{
	return gal_fast_cache_uc_u32_rd(GAL_FAST_RFU_L2_A_CMD_LO_REG);
}
static inline __attribute__((always_inline)) uint32_t apc1_l2dma_get_cmd_lo_reg_uc(void)
{
	return gal_fast_cache_uc_u32_rd(GAL_FAST_RFU_L2_B_CMD_LO_REG);
}

/*
 * func name : apc_l2dma_set_cmd_hi_reg_uc().
 * description : write l2dma high command RFU reg.
 * param : uint32_t val - address  .
 * return value : none.
 */
static inline __attribute__((always_inline)) void apc0_l2dma_set_cmd_hi_reg_uc(uint32_t val)
{
	gal_fast_cache_uc_u32_wr(GAL_FAST_RFU_L2_A_CMD_HI_REG, val);
}
static inline __attribute__((always_inline)) void apc1_l2dma_set_cmd_hi_reg_uc(uint32_t val)
{
	gal_fast_cache_uc_u32_wr(GAL_FAST_RFU_L2_B_CMD_HI_REG, val);
}

/*
 * func name : apc_l2dma_set_sys_addr_reg_uc().
 * description : write system memory address into RFU reg.
 * param : uint32_t val - address  .
 * return value : none.
 */
static inline __attribute__((always_inline)) void apc0_l2dma_set_sys_addr_reg_uc(uint32_t val)
{
	gal_fast_cache_uc_u32_wr(GAL_FAST_RFU_L2_A_CMD_ADDR_REG, val);
}
static inline __attribute__((always_inline)) void apc1_l2dma_set_sys_addr_reg_uc(uint32_t val)
{
	gal_fast_cache_uc_u32_wr(GAL_FAST_RFU_L2_B_CMD_ADDR_REG, val);
}

/*
 * func name : l2dma_queue_set_l2_ready_cmd().
 * description : prepare l2dma for transfer operation.
 * return value : none.
 */
static inline __attribute__((always_inline)) void apc0_l2dma_queue_set_l2_ready_cmd(void)
{
	u32 low_cmd = 0;
	low_cmd |= GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK;		 //Trigger command execution.	Set by SW, Cleared by 	HW when copy CMD
	//to Shadow Register.
	low_cmd |= GAL_FAST_L2DMA_CMD_LOW_PSEL_NO_DMC_MASK;	 	//Peripheral Select : 0 = custom L2DMA.
	low_cmd |= GAL_FAST_L2DMA_CMD_LOW_ATTRIBUTE_CMD_SET_READY_MASK;	//Attribute of RDL2,WRL2 command and	L2_READY_SR. 3="set-ready".

	apc0_l2dma_set_cmd_lo_reg_uc(low_cmd);			//write low cmd l2dma register.
}
static inline __attribute__((always_inline)) void apc1_l2dma_queue_set_l2_ready_cmd(void)
{
	u32 low_cmd = 0;
	low_cmd |= GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK;		//Trigger command execution.	Set by SW, Cleared by 	HW when copy CMD
	//to Shadow Register.
	low_cmd |= GAL_FAST_L2DMA_CMD_LOW_PSEL_NO_DMC_MASK;	 	//Peripheral Select : 0 = custom L2DMA.
	low_cmd |= GAL_FAST_L2DMA_CMD_LOW_ATTRIBUTE_CMD_SET_READY_MASK;	//Attribute of RDL2,WRL2 command and	L2_READY_SR. 3="set-ready".

	apc1_l2dma_set_cmd_lo_reg_uc(low_cmd);			//write low cmd l2dma register.
}

static inline __attribute__((always_inline)) void apc0_l2dma_queue_rst_l2_ready_cmd(void)
{
	u32 low_cmd = 0;
	low_cmd |= GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK;		 //Trigger command execution.	Set by SW, Cleared by 	HW when copy CMD
	//to Shadow Register.
	low_cmd |= GAL_FAST_L2DMA_CMD_LOW_PSEL_NO_DMC_MASK;	 	//Peripheral Select : 0 = custom L2DMA.
	low_cmd |= GAL_FAST_L2DMA_CMD_LOW_ATTRIBUTE_CMD_RST_READY_MASK;	//Attribute of RDL2,WRL2 command and	L2_READY_SR. 3="set-ready".

	apc0_l2dma_set_cmd_lo_reg_uc(low_cmd);			//write low cmd l2dma register.
}
static inline __attribute__((always_inline)) void apc1_l2dma_queue_rst_l2_ready_cmd(void)
{
	u32 low_cmd = 0;
	low_cmd |= GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK;		//Trigger command execution.	Set by SW, Cleared by 	HW when copy CMD
	//to Shadow Register.
	low_cmd |= GAL_FAST_L2DMA_CMD_LOW_PSEL_NO_DMC_MASK;	 	//Peripheral Select : 0 = custom L2DMA.
	low_cmd |= GAL_FAST_L2DMA_CMD_LOW_ATTRIBUTE_CMD_RST_READY_MASK;	//Attribute of RDL2,WRL2 command and	L2_READY_SR. 3="set-ready".

	apc1_l2dma_set_cmd_lo_reg_uc(low_cmd);			//write low cmd l2dma register.
}

static inline __attribute__((always_inline)) void apc0_l2dma_queue_dummy(void)
{
	u32 low_cmd = 0;
	low_cmd |= GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK;		 //Trigger command execution.	Set by SW, Cleared by 	HW when copy CMD
	//to Shadow Register.
	low_cmd |= GAL_FAST_L2DMA_CMD_LOW_PSEL_NO_DMC_MASK;	 	//Peripheral Select : 0 = custom L2DMA.

	apc0_l2dma_set_cmd_lo_reg_uc(low_cmd);			//write low cmd l2dma register.
	apc0_l2dma_set_cmd_hi_reg_uc(0);					//write high cmd l2dma register.
}
static inline __attribute__((always_inline)) void apc1_l2dma_queue_dummy(void)
{
	u32 low_cmd = 0;
	low_cmd |= GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK;		//Trigger command execution.	Set by SW, Cleared by 	HW when copy CMD
	//to Shadow Register.
	low_cmd |= GAL_FAST_L2DMA_CMD_LOW_PSEL_NO_DMC_MASK;	 	//Peripheral Select : 0 = custom L2DMA.

	apc1_l2dma_set_cmd_lo_reg_uc(low_cmd);			//write low cmd l2dma register.
	apc1_l2dma_set_cmd_hi_reg_uc(0);					//write high cmd l2dma register.
}


/*
 * func name : l2dma_queue_mem_to_l2t_512().
* description : copy memory into l2t using l2dma.
* param :u32 src - source address.
* return value : none.
*/
static inline __attribute__((always_inline)) void apc0_l2dma_queue_mem_to_l2t_512(u32 src)
{
	apc0_l2dma_set_sys_addr_reg_uc(src);
	apc0_l2dma_set_cmd_hi_reg_uc(0);
	u32 low_cmd =
	        GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK |		//Trigger command execution.	Set by SW, Cleared by 	HW when copy CMD
	        //to Shadow Register.
	        GAL_FAST_L2DMA_CMD_LOW_PSEL_DMC_MASK |		//Peripheral Select : 1 = DMC.
	        GAL_FAST_L2DMA_CMD_LOW_CMD_TYPE_RDSYS_MASK |	//		(0 << 28) |	// RDSYS move data from l3 /l4 to l2t
	        GAL_FAST_L2DMA_CMD_LOW_SYS_BURST64_MASK |		//		(3 << 26) |	// burst length 64
	        GAL_FAST_L2DMA_CMD_LOW_L2T_MODE64			//		(3 << 6);	// mode 64
	        ;
	apc0_l2dma_set_cmd_lo_reg_uc(low_cmd);
}
static inline __attribute__((always_inline)) void apc1_l2dma_queue_mem_to_l2t_512(u32 src)
{
	apc1_l2dma_set_sys_addr_reg_uc(src);
	apc1_l2dma_set_cmd_hi_reg_uc(0);

	u32 low_cmd =
	        GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK |		//Trigger command execution.	Set by SW, Cleared by 	HW when copy CMD
	        //to Shadow Register.
	        GAL_FAST_L2DMA_CMD_LOW_PSEL_DMC_MASK |		//Peripheral Select : 1 = DMC.
	        GAL_FAST_L2DMA_CMD_LOW_CMD_TYPE_RDSYS_MASK |	//		(0 << 28) |	// RDSYS move data from l3 /l4 to l2t
	        GAL_FAST_L2DMA_CMD_LOW_SYS_BURST64_MASK |		//		(3 << 26) |	// burst length 64
	        GAL_FAST_L2DMA_CMD_LOW_L2T_MODE64			//		(3 << 6);	// mode 64
	        ;
	apc1_l2dma_set_cmd_lo_reg_uc(low_cmd);
}

static inline __attribute__((always_inline)) void apc0_l2dma_queue_mem_to_l2t_256(u32 src)
{
	apc0_l2dma_set_sys_addr_reg_uc(src);
	apc0_l2dma_set_cmd_hi_reg_uc(0);

	u32 low_cmd =
	        GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK |		//Trigger command execution.	Set by SW, Cleared by 	HW when copy CMD
	        //to Shadow Register.
	        GAL_FAST_L2DMA_CMD_LOW_PSEL_DMC_MASK |		//Peripheral Select : 1 = DMC.
	        GAL_FAST_L2DMA_CMD_LOW_CMD_TYPE_RDSYS_MASK |	//		(0 << 28) |	// RDSYS move data from l3 /l4 to l2t
	        GAL_FAST_L2DMA_CMD_LOW_SYS_BURST32_MASK |		//		(3 << 26) |	// burst length 32
	        GAL_FAST_L2DMA_CMD_LOW_L2T_MODE32			//		(2 << 6);	// mode 32
	        ;
	apc0_l2dma_set_cmd_lo_reg_uc(low_cmd);
}
static inline __attribute__((always_inline)) void apc1_l2dma_queue_mem_to_l2t_256(u32 src)
{
	apc1_l2dma_set_sys_addr_reg_uc(src);
	apc1_l2dma_set_cmd_hi_reg_uc(0);

	u32 low_cmd =
	        GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK |		//Trigger command execution.	Set by SW, Cleared by 	HW when copy CMD
	        //to Shadow Register.
	        GAL_FAST_L2DMA_CMD_LOW_PSEL_DMC_MASK |		//Peripheral Select : 1 = DMC.
	        GAL_FAST_L2DMA_CMD_LOW_CMD_TYPE_RDSYS_MASK |	//		(0 << 28) |	// RDSYS move data from l3 /l4 to l2t
	        GAL_FAST_L2DMA_CMD_LOW_SYS_BURST32_MASK |		//		(3 << 26) |	// burst length 32
	        GAL_FAST_L2DMA_CMD_LOW_L2T_MODE32			//		(2 << 6);	// mode 32
	        ;
	apc1_l2dma_set_cmd_lo_reg_uc(low_cmd);
}

static inline __attribute__((always_inline)) void apc0_l2dma_queue_mem_to_l2t_128(u32 src)
{
	apc0_l2dma_set_sys_addr_reg_uc(src);
	apc0_l2dma_set_cmd_hi_reg_uc(0);

	u32 low_cmd =
	        GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK |		//Trigger command execution.	Set by SW, Cleared by 	HW when copy CMD
	        //to Shadow Register.
	        GAL_FAST_L2DMA_CMD_LOW_PSEL_DMC_MASK |		//Peripheral Select : 1 = DMC.
	        GAL_FAST_L2DMA_CMD_LOW_CMD_TYPE_RDSYS_MASK |	//		(0 << 28) |	// RDSYS move data from l3 /l4 to l2t
	        GAL_FAST_L2DMA_CMD_LOW_SYS_BURST16_MASK |		//		(3 << 26) |	// burst length 16
	        GAL_FAST_L2DMA_CMD_LOW_L2T_MODE16			//		(2 << 6);	// mode 16
	        ;
	apc0_l2dma_set_cmd_lo_reg_uc(low_cmd);
}
static inline __attribute__((always_inline)) void apc1_l2dma_queue_mem_to_l2t_128(u32 src)
{
	apc1_l2dma_set_sys_addr_reg_uc(src);
	apc1_l2dma_set_cmd_hi_reg_uc(0);

	u32 low_cmd =
	        GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK |		//Trigger command execution.	Set by SW, Cleared by 	HW when copy CMD
	        //to Shadow Register.
	        GAL_FAST_L2DMA_CMD_LOW_PSEL_DMC_MASK |		//Peripheral Select : 1 = DMC.
	        GAL_FAST_L2DMA_CMD_LOW_CMD_TYPE_RDSYS_MASK |	//		(0 << 28) |	// RDSYS move data from l3 /l4 to l2t
	        GAL_FAST_L2DMA_CMD_LOW_SYS_BURST16_MASK |		//		(3 << 26) |	// burst length 16
	        GAL_FAST_L2DMA_CMD_LOW_L2T_MODE16			//		(2 << 6);	// mode 16
	        ;
	apc1_l2dma_set_cmd_lo_reg_uc(low_cmd);
}

/*
 * func name : l2dma_queue_l2t_to_mem_512().
* description : copy l2t to memory using l2dma.
* param :u32 dst - destination address.
* return value : none.
*/
static inline __attribute__((always_inline)) void apc0_l2dma_queue_l2t_to_mem_512(u32 dst)
{
	apc0_l2dma_set_sys_addr_reg_uc(dst);
	apc0_l2dma_set_cmd_hi_reg_uc(0);

	u32 low_cmd =
	        GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK |		//	(1 << 31) |	// active cmd
	        GAL_FAST_L2DMA_CMD_LOW_PSEL_DMC_MASK |		//	(1 << 30) |	// dmc
	        GAL_FAST_L2DMA_CMD_LOW_CMD_TYPE_WRSYS_MASK |	//	(1 << 28) |	// WRSYS move data from l3 /l4 to l2t
	        GAL_FAST_L2DMA_CMD_LOW_SYS_BURST64_MASK |		//	(3 << 26) |	// burst length 64
	        GAL_FAST_L2DMA_CMD_LOW_L2T_MODE64			//	(3 << 6);	// mode 64
	        ;
	apc0_l2dma_set_cmd_lo_reg_uc(low_cmd);
}
static inline __attribute__((always_inline))  void apc1_l2dma_queue_l2t_to_mem_512(u32 dst)
{
	apc1_l2dma_set_sys_addr_reg_uc(dst);
	apc1_l2dma_set_cmd_hi_reg_uc(0);

	u32 low_cmd =
	        GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK |		//	(1 << 31) |	// active cmd
	        GAL_FAST_L2DMA_CMD_LOW_PSEL_DMC_MASK |		//	(1 << 30) |	// dmc
	        GAL_FAST_L2DMA_CMD_LOW_CMD_TYPE_WRSYS_MASK |	//	(1 << 28) |	// WRSYS move data from l3 /l4 to l2t
	        GAL_FAST_L2DMA_CMD_LOW_SYS_BURST64_MASK |		//	(3 << 26) |	// burst length 64
	        GAL_FAST_L2DMA_CMD_LOW_L2T_MODE64			//	(3 << 6);	// mode 64
	        ;
	apc1_l2dma_set_cmd_lo_reg_uc(low_cmd);
}

static inline __attribute__((always_inline)) void apc0_l2dma_queue_l2t_to_mem_256(u32 dst)
{
	apc0_l2dma_set_sys_addr_reg_uc(dst);
	apc0_l2dma_set_cmd_hi_reg_uc(0);

	u32 low_cmd =
	        GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK |		//	(1 << 31) |	// active cmd
	        GAL_FAST_L2DMA_CMD_LOW_PSEL_DMC_MASK |		//	(1 << 30) |	// dmc
	        GAL_FAST_L2DMA_CMD_LOW_CMD_TYPE_WRSYS_MASK |	//	(1 << 28) |	// WRSYS move data from l3 /l4 to l2t
	        GAL_FAST_L2DMA_CMD_LOW_SYS_BURST32_MASK |		//	(3 << 26) |	// burst length 32
	        GAL_FAST_L2DMA_CMD_LOW_L2T_MODE32			//	(2 << 6);	// mode 32
	        ;
	apc0_l2dma_set_cmd_lo_reg_uc(low_cmd);
}
static inline __attribute__((always_inline))  void apc1_l2dma_queue_l2t_to_mem_256(u32 dst)
{
	apc1_l2dma_set_sys_addr_reg_uc(dst);
	apc1_l2dma_set_cmd_hi_reg_uc(0);

	u32 low_cmd =
	        GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK |		//	(1 << 31) |	// active cmd
	        GAL_FAST_L2DMA_CMD_LOW_PSEL_DMC_MASK |		//	(1 << 30) |	// dmc
	        GAL_FAST_L2DMA_CMD_LOW_CMD_TYPE_WRSYS_MASK |	//	(1 << 28) |	// WRSYS move data from l3 /l4 to l2t
	        GAL_FAST_L2DMA_CMD_LOW_SYS_BURST32_MASK |		//	(3 << 26) |	// burst length 32
	        GAL_FAST_L2DMA_CMD_LOW_L2T_MODE32			//	(2 << 6);	// mode 32
	        ;
	apc1_l2dma_set_cmd_lo_reg_uc(low_cmd);
}

static inline __attribute__((always_inline)) void apc0_l2dma_queue_l2t_to_mem_128(u32 dst)
{
	apc0_l2dma_set_sys_addr_reg_uc(dst);
	apc0_l2dma_set_cmd_hi_reg_uc(0);

	u32 low_cmd =
	        GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK |		//	(1 << 31) |	// active cmd
	        GAL_FAST_L2DMA_CMD_LOW_PSEL_DMC_MASK |		//	(1 << 30) |	// dmc
	        GAL_FAST_L2DMA_CMD_LOW_CMD_TYPE_WRSYS_MASK |	//	(1 << 28) |	// WRSYS move data from l3 /l4 to l2t
	        GAL_FAST_L2DMA_CMD_LOW_SYS_BURST16_MASK |		//	(3 << 26) |	// burst length 16
	        GAL_FAST_L2DMA_CMD_LOW_L2T_MODE16			//	(2 << 6);	// mode 16
	        ;
	apc0_l2dma_set_cmd_lo_reg_uc(low_cmd);
}
static inline __attribute__((always_inline))  void apc1_l2dma_queue_l2t_to_mem_128(u32 dst)
{
	apc1_l2dma_set_sys_addr_reg_uc(dst);
	apc1_l2dma_set_cmd_hi_reg_uc(0);

	u32 low_cmd =
	        GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK |		//	(1 << 31) |	// active cmd
	        GAL_FAST_L2DMA_CMD_LOW_PSEL_DMC_MASK |		//	(1 << 30) |	// dmc
	        GAL_FAST_L2DMA_CMD_LOW_CMD_TYPE_WRSYS_MASK |	//	(1 << 28) |	// WRSYS move data from l3 /l4 to l2t
	        GAL_FAST_L2DMA_CMD_LOW_SYS_BURST16_MASK |		//	(3 << 26) |	// burst length 16
	        GAL_FAST_L2DMA_CMD_LOW_L2T_MODE16			//	(2 << 6);	// mode 16
	        ;
	apc1_l2dma_set_cmd_lo_reg_uc(low_cmd);
}

static inline __attribute__((always_inline)) void apc0_l2dma_queue_mem_to_l2_m64(u8 l2_col_group, u8 *src, u32 num_512b_chunks, enum gal_l2dma_cmd_attr l2_ready_attr)
{
	apc0_l2dma_set_cmd_hi_reg_uc(0);
	apc0_l2dma_set_sys_addr_reg_uc((u32)src);

	u32 low_cmd =
	        GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK |		//Trigger command execution.	Set by SW, Cleared by 	HW when copy CMD
	        GAL_FAST_L2DMA_CMD_LOW_PSEL_DMC_MASK |		//Peripheral Select : 1 = DMC.
	        GAL_FAST_L2DMA_CMD_LOW_CMD_TYPE_MCWRL2_MASK |	//	(0 << 28)		|	// RDSYS move data from l3 /l4 to l2
	        GAL_FAST_L2DMA_CMD_LOW_SYS_BURST64_MASK |		//	(3 << 26)		|	// burst length 64
	        ((l2_ready_attr << GAL_FAST_L2DMA_CMD_L2_READY_ATTR_BIT)
	         & GAL_FAST_L2DMA_CMD_L2_READY_ATTR_MASK) |		//	(l2_ready_attr << 24)	|
	        (((num_512b_chunks - 1) << GAL_FAST_L2DMA_CMD_NUM_REP_BIT)
	         & GAL_FAST_L2DMA_CMD_NUM_REP_MASK) |		//	((num_reps - 1) << 16)	|
	        GAL_FAST_L2DMA_CMD_LOW_L2T_MODE64 |			//	(2 << 6)		|	// mode 64
	        ((l2_col_group << GAL_FAST_L2DMA_CMD_COLGRP_ADDR_BIT)
	         & GAL_FAST_L2DMA_CMD_COLGRP_ADDR_MASK)		//	(l2_col_group << 0)
	        ;

	apc0_l2dma_set_cmd_lo_reg_uc(low_cmd);
}

static inline __attribute__((always_inline)) void apc1_l2dma_queue_mem_to_l2_m64(u8 l2_col_group, u8 *src, u32 num_512b_chunks, enum gal_l2dma_cmd_attr l2_ready_attr)
{
	apc1_l2dma_set_cmd_hi_reg_uc(0);
	apc1_l2dma_set_sys_addr_reg_uc((u32)src);

	u32 low_cmd =
	        GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK |		//Trigger command execution.	Set by SW, Cleared by 	HW when copy CMD
	        GAL_FAST_L2DMA_CMD_LOW_PSEL_DMC_MASK |		//Peripheral Select : 1 = DMC.
	        GAL_FAST_L2DMA_CMD_LOW_CMD_TYPE_MCWRL2_MASK |	//	(0 << 28)		|	// RDSYS move data from l3 /l4 to l2
	        GAL_FAST_L2DMA_CMD_LOW_SYS_BURST64_MASK |		//	(3 << 26)		|	// burst length 64
	        ((l2_ready_attr << GAL_FAST_L2DMA_CMD_L2_READY_ATTR_BIT)
	         & GAL_FAST_L2DMA_CMD_L2_READY_ATTR_MASK) |		//	(l2_ready_attr << 24)	|
	        (((num_512b_chunks - 1) << GAL_FAST_L2DMA_CMD_NUM_REP_BIT)
	         & GAL_FAST_L2DMA_CMD_NUM_REP_MASK) |		//	((num_reps - 1) << 16)	|
	        GAL_FAST_L2DMA_CMD_LOW_L2T_MODE64 |			//	(2 << 6)		|	// mode 64
	        ((l2_col_group << GAL_FAST_L2DMA_CMD_COLGRP_ADDR_BIT)
	         & GAL_FAST_L2DMA_CMD_COLGRP_ADDR_MASK)		//	(l2_col_group << 0)
	        ;

	apc1_l2dma_set_cmd_lo_reg_uc(low_cmd);
}

static inline __attribute__((always_inline)) void apc0_l2dma_queue_mem_to_l2_m64_indirect(u8 l2_col_group, u32 num_512b_chunks, enum gal_l2dma_cmd_attr l2_ready_attr)
{
	apc0_l2dma_set_cmd_hi_reg_uc(GAL_FAST_L2DMA_CMD_HI_SET_INDIRECT);
	apc0_l2dma_set_sys_addr_reg_uc((u32)NULL);	/* It is necessary to write to the register so write NULL */

	u32 low_cmd =
	        GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK |		//Trigger command execution.	Set by SW, Cleared by 	HW when copy CMD
	        GAL_FAST_L2DMA_CMD_LOW_PSEL_DMC_MASK |		//Peripheral Select : 1 = DMC.
	        GAL_FAST_L2DMA_CMD_LOW_CMD_TYPE_MCWRL2_MASK |	//	(0 << 28)		|	// RDSYS move data from l3 /l4 to l2
	        GAL_FAST_L2DMA_CMD_LOW_SYS_BURST64_MASK |		//	(3 << 26)		|	// burst length 64
	        ((l2_ready_attr << GAL_FAST_L2DMA_CMD_L2_READY_ATTR_BIT)
	         & GAL_FAST_L2DMA_CMD_L2_READY_ATTR_MASK) |		//	(l2_ready_attr << 24)	|
	        (((num_512b_chunks - 1) << GAL_FAST_L2DMA_CMD_NUM_REP_BIT)
	         & GAL_FAST_L2DMA_CMD_NUM_REP_MASK) |		//	((num_reps - 1) << 16)	|
	        GAL_FAST_L2DMA_CMD_LOW_L2T_MODE64 |			//	(2 << 6)		|	// mode 64
	        ((l2_col_group << GAL_FAST_L2DMA_CMD_COLGRP_ADDR_BIT)
	         & GAL_FAST_L2DMA_CMD_COLGRP_ADDR_MASK)		//	(l2_col_group << 0)
	        ;
	apc0_l2dma_set_cmd_lo_reg_uc(low_cmd);
}

static inline __attribute__((always_inline)) void apc1_l2dma_queue_mem_to_l2_m64_indirect(u8 l2_col_group, u32 num_512b_chunks, enum gal_l2dma_cmd_attr l2_ready_attr)
{
	apc1_l2dma_set_cmd_hi_reg_uc(GAL_FAST_L2DMA_CMD_HI_SET_INDIRECT);
	apc1_l2dma_set_sys_addr_reg_uc((u32)NULL);	/* It is necessary to write to the register so write NULL */

	u32 low_cmd =
	        GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK |		//Trigger command execution.	Set by SW, Cleared by 	HW when copy CMD
	        GAL_FAST_L2DMA_CMD_LOW_PSEL_DMC_MASK |		//Peripheral Select : 1 = DMC.
	        GAL_FAST_L2DMA_CMD_LOW_CMD_TYPE_MCWRL2_MASK |	//	(0 << 28)		|	// RDSYS move data from l3 /l4 to l2
	        GAL_FAST_L2DMA_CMD_LOW_SYS_BURST64_MASK |		//	(3 << 26)		|	// burst length 64
	        ((l2_ready_attr << GAL_FAST_L2DMA_CMD_L2_READY_ATTR_BIT)
	         & GAL_FAST_L2DMA_CMD_L2_READY_ATTR_MASK) |		//	(l2_ready_attr << 24)	|
	        (((num_512b_chunks - 1) << GAL_FAST_L2DMA_CMD_NUM_REP_BIT)
	         & GAL_FAST_L2DMA_CMD_NUM_REP_MASK) |		//	((num_reps - 1) << 16)	|
	        GAL_FAST_L2DMA_CMD_LOW_L2T_MODE64 |			//	(2 << 6)		|	// mode 64
	        ((l2_col_group << GAL_FAST_L2DMA_CMD_COLGRP_ADDR_BIT)
	         & GAL_FAST_L2DMA_CMD_COLGRP_ADDR_MASK)		//	(l2_col_group << 0)
	        ;
	apc1_l2dma_set_cmd_lo_reg_uc(low_cmd);
}

static inline __attribute__((always_inline)) void mapc0_l2dma_queue_l2_to_mem_m64(u8 l2_col_group, u8 *dst, u32 num_512b_chunks, enum gal_l2dma_cmd_attr l2_ready_attr)
{
	apc1_l2dma_set_cmd_hi_reg_uc(0);
	apc0_l2dma_set_sys_addr_reg_uc((u32)dst);

	u32 low_cmd =
		GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK |                //Trigger command execution.    Set by SW, Cleared by   HW when copy CMD
		GAL_FAST_L2DMA_CMD_LOW_PSEL_DMC_MASK |              //Peripheral Select : 1 = DMC.
		GAL_FAST_L2DMA_CMD_LOW_CMD_TYPE_MCRDL2_MASK |       //      (0 << 28)               |       // RDSYS move data from l2 to l3 /l4
		GAL_FAST_L2DMA_CMD_LOW_SYS_BURST64_MASK |           //      (3 << 26)               |       // burst length 64
		((l2_ready_attr << GAL_FAST_L2DMA_CMD_L2_READY_ATTR_BIT)
		& GAL_FAST_L2DMA_CMD_L2_READY_ATTR_MASK) |         //      (l2_ready_attr << 24)   |
		(((num_512b_chunks - 1) << GAL_FAST_L2DMA_CMD_NUM_REP_BIT)
		& GAL_FAST_L2DMA_CMD_NUM_REP_MASK) |               //      ((num_reps - 1) << 16)  |
		GAL_FAST_L2DMA_CMD_LOW_L2T_MODE64 |                 //      (2 << 6)                |       // mode 64
		((l2_col_group << GAL_FAST_L2DMA_CMD_COLGRP_ADDR_BIT)
		& GAL_FAST_L2DMA_CMD_COLGRP_ADDR_MASK)             //      (l2_col_group << 0)
		;
	apc0_l2dma_set_cmd_lo_reg_uc(low_cmd);
}

static inline __attribute__((always_inline)) void mapc1_l2dma_queue_l2_to_mem_m64(u8 l2_col_group, u8 *dst, u32 num_512b_chunks, enum gal_l2dma_cmd_attr l2_ready_attr)
{
	apc1_l2dma_set_cmd_hi_reg_uc(0);
	apc1_l2dma_set_sys_addr_reg_uc((u32)dst);

	u32 low_cmd =
		GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK |                //Trigger command execution.    Set by SW, Cleared by   HW when copy CMD
		GAL_FAST_L2DMA_CMD_LOW_PSEL_DMC_MASK |              //Peripheral Select : 1 = DMC.
		GAL_FAST_L2DMA_CMD_LOW_CMD_TYPE_MCRDL2_MASK |       //      (0 << 28)               |       // RDSYS move data from l2 to l3 /l4
		GAL_FAST_L2DMA_CMD_LOW_SYS_BURST64_MASK |           //      (3 << 26)               |       // burst length 64
		((l2_ready_attr << GAL_FAST_L2DMA_CMD_L2_READY_ATTR_BIT)
		& GAL_FAST_L2DMA_CMD_L2_READY_ATTR_MASK) |         //      (l2_ready_attr << 24)   |
		(((num_512b_chunks - 1) << GAL_FAST_L2DMA_CMD_NUM_REP_BIT)
		& GAL_FAST_L2DMA_CMD_NUM_REP_MASK) |               //      ((num_reps - 1) << 16)  |
		GAL_FAST_L2DMA_CMD_LOW_L2T_MODE64 |                 //      (2 << 6)                |       // mode 64
		((l2_col_group << GAL_FAST_L2DMA_CMD_COLGRP_ADDR_BIT)
		& GAL_FAST_L2DMA_CMD_COLGRP_ADDR_MASK)             //      (l2_col_group << 0)
		;
	apc1_l2dma_set_cmd_lo_reg_uc(low_cmd);
}

static inline __attribute__((always_inline)) void mapc0_l2dma_queue_l2_to_mem_m64_indirect(u8 l2_col_group, u32 num_512b_chunks, enum gal_l2dma_cmd_attr l2_ready_attr)
{
	apc0_l2dma_set_cmd_hi_reg_uc(GAL_FAST_L2DMA_CMD_HI_SET_INDIRECT);
	apc0_l2dma_set_sys_addr_reg_uc((u32)NULL);	/* It is necessary to write to the register so write NULL */

	u32 low_cmd =
		GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK |                //Trigger command execution.    Set by SW, Cleared by   HW when copy CMD
		GAL_FAST_L2DMA_CMD_LOW_PSEL_DMC_MASK |              //Peripheral Select : 1 = DMC.
		GAL_FAST_L2DMA_CMD_LOW_CMD_TYPE_MCRDL2_MASK |       //      (0 << 28)               |       // RDSYS move data from l2 to l3 /l4
		GAL_FAST_L2DMA_CMD_LOW_SYS_BURST64_MASK |           //      (3 << 26)               |       // burst length 64
		((l2_ready_attr << GAL_FAST_L2DMA_CMD_L2_READY_ATTR_BIT)
		& GAL_FAST_L2DMA_CMD_L2_READY_ATTR_MASK) |         //      (l2_ready_attr << 24)   |
		(((num_512b_chunks - 1) << GAL_FAST_L2DMA_CMD_NUM_REP_BIT)
		& GAL_FAST_L2DMA_CMD_NUM_REP_MASK) |               //      ((num_reps - 1) << 16)  |
		GAL_FAST_L2DMA_CMD_LOW_L2T_MODE64 |                 //      (2 << 6)                |       // mode 64
		((l2_col_group << GAL_FAST_L2DMA_CMD_COLGRP_ADDR_BIT)
		& GAL_FAST_L2DMA_CMD_COLGRP_ADDR_MASK)             //      (l2_col_group << 0)
		;
	apc0_l2dma_set_cmd_lo_reg_uc(low_cmd);
}

static inline __attribute__((always_inline)) void mapc1_l2dma_queue_l2_to_mem_m64_indirect(u8 l2_col_group, u32 num_512b_chunks, enum gal_l2dma_cmd_attr l2_ready_attr)
{
	apc1_l2dma_set_cmd_hi_reg_uc(GAL_FAST_L2DMA_CMD_HI_SET_INDIRECT);
	apc1_l2dma_set_sys_addr_reg_uc((u32)NULL);	/* It is necessary to write to the register so write NULL */

	u32 low_cmd =
		GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK |                //Trigger command execution.    Set by SW, Cleared by   HW when copy CMD
		GAL_FAST_L2DMA_CMD_LOW_PSEL_DMC_MASK |              //Peripheral Select : 1 = DMC.
		GAL_FAST_L2DMA_CMD_LOW_CMD_TYPE_MCRDL2_MASK |       //      (0 << 28)               |       // RDSYS move data from l2 to l3 /l4
		GAL_FAST_L2DMA_CMD_LOW_SYS_BURST64_MASK |           //      (3 << 26)               |       // burst length 64
		((l2_ready_attr << GAL_FAST_L2DMA_CMD_L2_READY_ATTR_BIT)
		& GAL_FAST_L2DMA_CMD_L2_READY_ATTR_MASK) |         //      (l2_ready_attr << 24)   |
		(((num_512b_chunks- 1) << GAL_FAST_L2DMA_CMD_NUM_REP_BIT)
		& GAL_FAST_L2DMA_CMD_NUM_REP_MASK) |               //      ((num_reps - 1) << 16)  |
		GAL_FAST_L2DMA_CMD_LOW_L2T_MODE64 |                 //      (2 << 6)                |       // mode 64
		((l2_col_group << GAL_FAST_L2DMA_CMD_COLGRP_ADDR_BIT)
		& GAL_FAST_L2DMA_CMD_COLGRP_ADDR_MASK)             //      (l2_col_group << 0)
		;
	apc1_l2dma_set_cmd_lo_reg_uc(low_cmd);
}

static inline __attribute__((always_inline)) void apc0_l2dma_clean_queue(void)
{
#ifdef DMA_DIAGNOSIS
	uint32_t busy_loop_count = 0;
#endif
	while (apc0_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
		BUSY_LOOP()
	}
	apc0_l2dma_queue_dummy();
	while (apc0_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
		BUSY_LOOP()
	}
}
static inline __attribute__((always_inline)) void apc1_l2dma_clean_queue(void)
{
#ifdef DMA_DIAGNOSIS
	uint32_t busy_loop_count = 0;
#endif
	while (apc1_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
		BUSY_LOOP()
	}
	apc1_l2dma_queue_dummy();
	while (apc1_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
		BUSY_LOOP()
	}
}

/*
 * func name : l2dma_mem_to_mem_512.
* description : copy from L4 to L2T,then copy from L2T to L3/L4.
* param :u32 dst - destination address.
* param :u32 src - source address.
* return value : none.
*/
static inline __attribute__((always_inline)) void gal_fast_l2dma_mem_to_mem_512(u8 *dst, u8 *src, u32 apc_id)
{
#ifdef DMA_DIAGNOSIS
	uint32_t busy_loop_count = 0;
#endif
	if (GAL_L2DMA_APC_ID_0 == apc_id) {
		//get L2DMA status CMDLO reg command EN bit (bit 32)
		while (apc0_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
			BUSY_LOOP()
		}
		apc0_l2dma_queue_mem_to_l2t_512((u32)src);
		//get L2DMA status CMDLO reg command EN bit (bit 32)
		while (apc0_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
			BUSY_LOOP()
		}
		apc0_l2dma_queue_l2t_to_mem_512((u32)dst);
	} else {
		//get L2DMA status CMDLO reg command EN bit (bit 32)
		while (apc1_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
			BUSY_LOOP()
		}
		apc1_l2dma_queue_mem_to_l2t_512((u32)src);
		//get L2DMA status CMDLO reg command EN bit (bit 32)
		while (apc1_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
			BUSY_LOOP()
		}
		apc1_l2dma_queue_l2t_to_mem_512((u32)dst);
	}
}

/*
 * func name : l2dma_l2t_to_mem_512.
* description : copy from L2T to dst on L3/L4.
* param :u32 dst - destination address.
* return value : none.
*/
static inline __attribute__((always_inline)) void gal_fast_l2dma_l2t_to_mem_512(u8 *dst, u32 apc_id)
{
#ifdef DMA_DIAGNOSIS
	uint32_t busy_loop_count = 0;
#endif
	if (GAL_L2DMA_APC_ID_0 == apc_id) {
		while (apc0_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
			BUSY_LOOP()
		}
		apc0_l2dma_queue_l2t_to_mem_512((u32)dst);
	} else {
		while (apc1_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
			BUSY_LOOP()
		}
		apc1_l2dma_queue_l2t_to_mem_512((u32)dst);
	}
}

static inline __attribute__((always_inline)) void gal_fast_l2dma_mem_to_mem_256(u8 *dst, u8 *src, u32 apc_id)
{
#ifdef DMA_DIAGNOSIS
	uint32_t busy_loop_count = 0;
#endif
	if (GAL_L2DMA_APC_ID_0 == apc_id) {
		//get L2DMA status CMDLO reg command EN bit (bit 32)
		while (apc0_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
			BUSY_LOOP()
		}
		apc0_l2dma_queue_mem_to_l2t_256((u32)src);
		//get L2DMA status CMDLO reg command EN bit (bit 32)
		while (apc0_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
			BUSY_LOOP()
		}
		apc0_l2dma_queue_l2t_to_mem_256((u32)dst);
	} else {
		//get L2DMA status CMDLO reg command EN bit (bit 32)
		while (apc1_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
			BUSY_LOOP()
		}
		apc1_l2dma_queue_mem_to_l2t_256((u32)src);
		//get L2DMA status CMDLO reg command EN bit (bit 32)
		while (apc1_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
			BUSY_LOOP()
		}
		apc1_l2dma_queue_l2t_to_mem_256((u32)dst);
	}
}

static inline __attribute__((always_inline)) void gal_fast_l2dma_mem_to_mem_128(u8 *dst, u8 *src, u32 apc_id)
{
#ifdef DMA_DIAGNOSIS
	uint32_t busy_loop_count = 0;
#endif
	if (GAL_L2DMA_APC_ID_0 == apc_id) {
		//get L2DMA status CMDLO reg command EN bit (bit 32)
		while (apc0_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
			BUSY_LOOP()
		}
		apc0_l2dma_queue_mem_to_l2t_128((u32)src);
		//get L2DMA status CMDLO reg command EN bit (bit 32)
		while (apc0_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
			BUSY_LOOP()
		}
		apc0_l2dma_queue_l2t_to_mem_128((u32)dst);
	} else {
		//get L2DMA status CMDLO reg command EN bit (bit 32)
		while (apc1_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
			BUSY_LOOP()
		}
		apc1_l2dma_queue_mem_to_l2t_128((u32)src);
		//get L2DMA status CMDLO reg command EN bit (bit 32)
		while (apc1_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
			BUSY_LOOP()
		}
		apc1_l2dma_queue_l2t_to_mem_128((u32)dst);
	}
}

static inline __attribute__((always_inline)) bool GAL_FAST_IS_ERR(int e)
{
	return e < 0 && -e < (int)PAGE_SIZE;
}

static inline __attribute__((always_inline)) bool GAL_FAST_IS_ERR_PTR_OR_NULL(const void *ptr)
{
	return (ptr == NULL) || GAL_FAST_IS_ERR((int)(intptr_t)ptr);
}

#endif /* GAL_FAST_FUNCS_DEPENDENCE_FUNCS_H_ */
