/*
 * Copyright (C) 2019, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */

#ifndef _GSI_PERF_H_
#define _GSI_PERF_H_
#include "config.h"
//#include <gsi/libsys/config.h>
#define GSI_PERF_ENABLE 0

void gsi_perf_init(void);
u64 gsi_ticks2ms(u64 ticks);
u64 gsi_ticks2us(u64 ticks);
#if (GSI_PERF_ENABLE == 1)
#define gsi_perf_tag(name) _gsi_perf_tag(name)
#define gsi_perf_tag_with_val(name, val) _gsi_perf_tag_with_val(name, val)
#define gsi_perf_get_last_tag() gsi_perf_get_last_tag()
#else
#define gsi_perf_tag(name)
#define gsi_perf_tag_with_val(name, val)
#define gsi_perf_get_last_tag()
#endif

void _gsi_perf_tag(char *const trigger_name);
void _gsi_perf_tag_with_val(char *const trigger_name, u32 val);
u64 _gsi_perf_get_last_tag(void);
void gsi_perf_show(void);
#endif //_GSI_PERF_H_
