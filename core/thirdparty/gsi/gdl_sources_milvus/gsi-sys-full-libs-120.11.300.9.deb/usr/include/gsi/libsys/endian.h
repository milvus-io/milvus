/*
 * Copyright (C) 2016, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */
#ifndef GSI_ENDIAN_H
#define GSI_ENDIAN_H

#include "types.h"

/* Note: gcc specific definitions */
#if defined(__BYTE_ORDER__) && (__BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__)

static inline u8 gsi_get_le8p(u8 *p)
{
	return *p;
}

static inline u16 gsi_get_le16p(u16 *p)
{
	return *p;
}

static inline u32 gsi_get_le32p(u32 *p)
{
	return *p;
}

static inline u64 gsi_get_le64p(u64 *p)
{
	return *p;
}

static inline void gsi_set_le8p(u8 *p, u8 val)
{
	*p = val;
}

static inline void gsi_set_le16p(u16 *p, u16 val)
{
	*p = val;
}

static inline void gsi_set_le32p(u32 *p, u32 val)
{
	*p = val;
}

static inline void gsi_set_le64p(u64 *p, u64 val)
{
	*p = val;
}

#else  /* __ORDER_LITTLE_ENDIAN__ */
#error big endian not supported yet
#endif /* __ORDER_LITTLE_ENDIAN__ */

#endif /* GSI_ENDIAN_H */
