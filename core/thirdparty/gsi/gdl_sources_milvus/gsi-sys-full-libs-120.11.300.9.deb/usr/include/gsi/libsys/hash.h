/*
 * Copyright (C) 2016, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */

#ifndef GSI_HASH_H
#define GSI_HASH_H

// #include "config.h"

#if defined(GSI_LIBSYS_AARCH64) || defined(GSI_LIBSYS_X86_64) || defined(GSI_LIBSYS_X86_32)

#include "list.h"

enum {
	GSI_HASH_DEFAULT_NUM_BUCKETS = 256,
	GSI_HASH_DEFAULT_AUTO_RESIZE_FACTOR = 2,
};

typedef size_t (gsi_hash_func)(struct gsi_dlist *, size_t num_buckets);
typedef int (gsi_hash_cmp_func)(struct gsi_dlist *, const void *key);
typedef void (gsi_hash_destroy_func)(struct gsi_dlist *);
typedef bool (gsi_hash_iter_func)(struct gsi_dlist *, void *priv);

struct gsi_hash_table {
	struct gsi_dlist *hash_buckets;
	size_t	hash_num_items;
	gsi_hash_func *hash_func;
	gsi_hash_cmp_func *hash_cmp_func;
	gsi_hash_destroy_func *hash_destroy_func;
	size_t	hash_num_buckets;
	int	hash_auto_resize_factor;
};

static inline size_t gsi_hash_num_items(struct gsi_hash_table *htp)
{
	return htp->hash_num_items;
}

gsi_status_t gsi_hash_init_ext(struct gsi_hash_table *, gsi_hash_func *, gsi_hash_cmp_func *, gsi_hash_destroy_func *, size_t num_buckets, int auto_resize_factor);

static inline gsi_status_t gsi_hash_init(struct gsi_hash_table *htp, gsi_hash_func *hash_func, gsi_hash_cmp_func *cmp_func, gsi_hash_destroy_func *destroy_func)
{
	return gsi_hash_init_ext(htp, hash_func, cmp_func, destroy_func, 0, 0);
}

void gsi_hash_destroy(struct gsi_hash_table *htp);
gsi_status_t gsi_hash_resize(struct gsi_hash_table *htp, size_t num_buckets);

/*
 * Insert item to hash table
 */
gsi_status_t _gsi_hash_insert_item(struct gsi_hash_table *htp, struct gsi_dlist *item, size_t hval);

static inline gsi_status_t gsi_hash_insert_item(struct gsi_hash_table *htp, struct gsi_dlist *item)
{
	return _gsi_hash_insert_item(htp, item, htp->hash_func(item, htp->hash_num_buckets));
}

/*
 * Insert item to hash table iff it does not exist, based on @hval, @key
 *
 * Return 0 on success, -EEXIST if already found, or other error otherwise
 * Optionally get existing item in @cur_item
 */
gsi_status_t gsi_hash_insert_item_unique(struct gsi_hash_table *htp, struct gsi_dlist *item, size_t hval, const void *key, struct gsi_dlist **cur_item);

/*
 * Lookup item by @key
 *
 * Return item if found, or NULL otherwise
 */
struct gsi_dlist *gsi_hash_lookup_item(struct gsi_hash_table *htp, size_t hval, const void *key);

/*
 * Lookup and delete item by @key
 *
 * Return item if found, or NULL otherwise
 */
struct gsi_dlist *gsi_hash_delete_item(struct gsi_hash_table *htp, size_t hval, const void *key);

/*
 * Lookup and destroy item by @key
 *
 * Return true if found, or false otherwise
 */
bool gsi_hash_destroy_item(struct gsi_hash_table *htp, size_t hval, const void *key);

/*
 * Iterate over all items in hash table
 *
 * item and @priv are passed to iter_func
 * Return number of times iter_func returned true
 */
size_t gsi_hash_foreach(struct gsi_hash_table *htp, gsi_hash_iter_func *, void *priv);

/*
 * Iterate over all items in hash table and destroy all items for which predicate returned true
 *
 * item and @priv are passed to iter_func
 * Return number of destroyed items
 */
size_t gsi_hash_foreach_destroy(struct gsi_hash_table *htp, gsi_hash_iter_func *predicate, void *priv);

/*
 * Hash table with immediate key-value pairs
 */
typedef bool (gsi_ikvhash_iter_func)(uintptr_t key, uintptr_t data, void *priv);

gsi_status_t gsi_ikvhash_init_ext(struct gsi_hash_table *, size_t num_buckets, int auto_resize_factor);

static inline gsi_status_t gsi_ikvhash_init(struct gsi_hash_table *htp)
{
	return gsi_ikvhash_init_ext(htp, 0, 0);
}

static inline void gsi_ikvhash_destroy(struct gsi_hash_table *htp)
{
	gsi_hash_destroy(htp);
}

static inline size_t gsi_ikvhash_num_items(struct gsi_hash_table *htp)
{
	return gsi_hash_num_items(htp);
}

/*
 * Insert a new item by <@key, @val>
 *
 * If @key already exists:
 * 	if not @do_update then fail with -EEXIST
 * 	else update new @val and return 1
 * 	In both cases, optionally return old val in @old_valp
 * Otherwise return 0 on success or system error
 */
gsi_status_t gsi_ikvhash_insert_or_update_item(struct gsi_hash_table *htp, uintptr_t key, uintptr_t val, uintptr_t *old_valp, bool do_update);

static inline gsi_status_t gsi_ikvhash_insert_item(struct gsi_hash_table *htp, uintptr_t key, uintptr_t val, uintptr_t *old_valp)
{
	return gsi_ikvhash_insert_or_update_item(htp, key, val, old_valp, false);
}

static inline gsi_status_t gsi_ikvhash_update_item(struct gsi_hash_table *htp, uintptr_t key, uintptr_t val, uintptr_t *old_valp)
{
	return gsi_ikvhash_insert_or_update_item(htp, key, val, old_valp, true);
}

/*
 * Lookup item by @key
 *
 * Return 0 and val in @valp if found, or -ENOENT otherwise
 */
gsi_status_t gsi_ikvhash_lookup_item(struct gsi_hash_table *htp, uintptr_t key, uintptr_t *valp);

/*
 * Lookup and delete item by @key
 *
 * Return 0 and val in @valp if found, or -ENOENT otherwise
 */
gsi_status_t gsi_ikvhash_delete_item(struct gsi_hash_table *htp, uintptr_t key, uintptr_t *valp);

/*
 * Iterate over all items in kvhash table
 *
 * @val and @priv are passed to iter_func
 * Return count
 */
size_t gsi_ikvhash_foreach(struct gsi_hash_table *htp, gsi_ikvhash_iter_func *, void *priv);

#endif /* defined(GSI_LIBSYS_AARCH64) || defined(GSI_LIBSYS_X86_64) || defined(GSI_LIBSYS_X86_32) */

#endif /* GSI_HASH_H */
