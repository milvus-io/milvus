/*
 * GSI Device Library for Host code running User Tasks remotely on GSI's APU System
 *
 * Copyright (C) 2019, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */

#ifndef GSI_LIBGAL_H_
#define GSI_LIBGAL_H_

#include <gsi/apl_defs.h>
#include <stdbool.h>

#define GAL_TASK_NAME_SECTION "GSI_task_ep_names"

typedef int gsi_prod_status_t;
typedef u64 gal_mem_handle_t;

#define GAL_TASK_ENTRY_POINT(name, in, out)          \
        static const char __attribute__((section(GAL_TASK_NAME_SECTION), used)) \
        name##__name[] = #name; \
        static gsi_prod_status_t __attribute__((used)) \
        name(void * in __attribute__((unused)), \
             void *out __attribute__((unused)))

#define GAL_INCLUDE_INIT_TASK \
        void gal_call_init_task(void); \
        static void __attribute__((used)) gal_include_init_task(void) \
        { \
                gal_call_init_task(); \
        }; \

#define GAL_L2DMA_APC_ID_0 0
#define GAL_L2DMA_APC_ID_1 1
#define GAL_MAX_NUM_L4_ADDRESSES 64

typedef u32 CHUNK_SIZE;

enum gal_log_level {
	GAL_LOG_ERROR = 5,
};

enum gal_l2_defs {
	GAL_L2_COLGRP_COLS = GSI_APC_CBUS_BITS,
};

enum gal_l2dma_defs {
	GAL_L2DMA_CHUNK_SIZE_512 = 512,
	GAL_L2DMA_MIN_CHUNK_SIZE_512 = 512,
};


enum gal_apuc_mem_map_defs {
	GAL_TASK_SYS_MEM_PAGE_SIZE = 1 << 28,
};

enum gal_apuc_rsp_fifo_defs {
	GAL_APUC_IFR_FIFO_LEN = 16,
	GAL_APUC_RSP_FIFO_LEN = 16,
};

enum gal_bank_defs {
	GAL_BANK_NUM_SECTIONS = 16,
	GAL_BANK_SECTIONS_MASK = (1 << GAL_BANK_NUM_SECTIONS) - 1,
};

enum gal_l2_addr_regs {
	L2_ADDR_REG_0 = 0,
	GAL_NUM_L2_ADDR_REGS,
};

enum gal_l2t_mode_type {
	GAL_L2T_MODE_8 = 0,
	GAL_L2T_MODE_16 = 1,
	GAL_L2T_MODE_32 = 2,
	GAL_L2T_MODE_64 = 3,
};

enum gal_l2dma_cmd_attr {
	GAL_L2DMA_L2_READY_NOP = 0,
	GAL_L2DMA_L2_READY_RST = 2,
	GAL_L2DMA_L2_READY_SET = 3,
};

enum gal_l2dma_dma_mode {
	GAL_L2DMA_MODE_DIRECT = 0,
	GAL_L2DMA_MODE_INDIRECT = 1,
};

enum gal_l4_dma_transaction_type {
	GAL_L4DMA_WRITE = 0,
	GAL_L4DMA_READ = 1,
};
struct gal_l2dma_l2_addr {
	u8 l2_col_group;        /* column groups in 64 l2 columns resolution (values 0 - 63) */
	u8 l2_byte_row;                /* rows in byte resolution (values 0 - 7) */
} __attribute__((packed));

struct gal_l2dma_l4_l2_transaction {
	uint num_steps;
	uint step_size_num_64b_chunk; /*number of chunks - each chunk is 64 bytes */
	void *l4_addr;
	uint l4_step_stride;        /* in bytes */
	u8 l2_mode;
	u8 l2_step_col_group;        /* column group step size */
	u8 l2_rep_colgrp_stride;
	struct gal_l2dma_l2_addr l2_addr;
};
struct gal_l4dma_cmd_desc {
	uint step_size;											// size in bytes
	uint repeat;											// number of times to repeat the description of the block
	uint l4_step_stride;									// stride in l4
	uint num_l4_addrs;										// number of l4 addresses for a single APC ( max = GAL_MAX_NUM_L4_ADDRESSES / 2)
	uint interleaved_factor;								// number of strides to advance in a given address before moving to the next adress
	uint padding;											// number of bytes to add in the last interleaved transaction 
	void *APC_l4_addr[GAL_MAX_NUM_L4_ADDRESSES];			// interleaved between APC_A[even locations] and APC_B[odd locations]
};

/*
 * mem alloc  functions
 */

/*
 * gal_zalloc - Allocate memory from L3, memory is initialize to zero.
 *
 * Input:
 *         @size - Number of bytes to allocate.
 *
 * Return value:
 *         Pointer to address on L3 - OK.
 *         Pointer with ENOMEM value - allocation failed.
 *
 * Comments:
 *         Validate pointer with GSI_IS_ERR_PTR define.
 *         If size = 0, assert will appear in debug mode.
 */
void *gal_zalloc(u32 size);

/*
 * gal_malloc - Allocate memory from L3.
 *
 * Input:
 *         @size - Number of bytes to allocate.
 *
 * Return value:
 *         Pointer to address on L3 - OK.
 *         Pointer with ENOMEM value - allocation failed.
 *
 * Comments:
 *         Validate pointer with GSI_IS_ERR_PTR define.
 *         If size = 0, assert will appear in debug mode.
 */
void *gal_malloc(u32 size);

/*
 * gal_free - Deallocate memory on L3.
 *
 * Input:
 *         @p - pointer to memory.
 */
void gal_free(const void *p);
/*
 *gal_init_l3_1kb_buffer  - Initialize 1KB (256 events) memory buffer in L3 memroy for debug.
 *
 * Return value:
 *         Buffer address.
 *
 * Comments:
 *         Use gal_fast_event(u32 data) from gal-fast-func.h for write data to the buffer.
 */

u32 gal_init_l3_1kb_buffer(void);
/*
 * gal_get_l3_buffer_events -  Read the events from L3 to destination buffer.
 *
 * Input:
 *         @dst_buffer - Destination buffer.
 *         @events_num - Number of events to read from L3 (up to 256 events).
 *
 * Comments:
 *         The evevnts order in the destination buffer is from the last to the first.
 */
void gal_get_l3_buffer_events(u32 *dst_buffer, int events_num);

//void gal_event(u32* buffer, u32 data);
/*
 * Init / Exit  functions
 */
void gal_init(void);
void gal_exit(void);

typedef void  gal_l2dma_hndl_t;

/*
 * l2dma functions
 */
/*
*        L2 Memory Description -
*                The L2 memory divide to 2 APC's: L2-APC-0, L2-APC-1.
*                Each L2-APC contains 4K columns of 64b(i.e. 8 Bytes per column) the APCs 4K columns divided into 64 column groups, each contains 64 columns.
*		  The total size of each Each L2-APC is 32KB (4K*8B).
*
*        L2-APC-0 (L2-APC-1 looks the same)
*
* Column group                   |                        0                        |                        ...                        |                        63                        |
*                                |-------------------------------------------------|---------------------------------------------------|--------------------------------------------------|
*         Column                 |        0        |        ...     |        63    |    0       |        ...        |        63        |        0       |        ...     |        63      |
*                                ----------------------------------------------------------------------------------------------------------------------------------------------------------
*                                0|                |                |              |                                                   |                |                |                |
*                                ----------------------------------------------------------------------------------------------------------------------------------------------------------
*                                1|                |                |              |                                                   |                |                |                |
*                b               ----------------------------------------------------------------------------------------------------------------------------------------------------------
*                y               2|                |                |              |                                                   |                |                |                |
*                t               ----------------------------------------------------------------------------------------------------------------------------------------------------------
*                e               3|                |                |              |                                                   |                |                |                |
*                                ----------------------------------------------------------------------------------------------------------------------------------------------------------
*                r               4|                |                |              |                                                   |                |                |                |
*                o               ----------------------------------------------------------------------------------------------------------------------------------------------------------
*                w               5|                |                |              |                                                   |                |                |                |
*                                ----------------------------------------------------------------------------------------------------------------------------------------------------------
*                                6|                |                |              |                                                   |                |                |                |
*                                ----------------------------------------------------------------------------------------------------------------------------------------------------------
*                                7|                |                |              |                                                   |                |                |                |
*                                ----------------------------------------------------------------------------------------------------------------------------------------------------------
*
*         Working in different mode type - the data from L4 transposed to the L2-APC by mode type: (512 bytes for example)
*                 GAL_L2T_MODE_64  - the data arrange in 8 byte rows in each column, 512 bytes allocate 1 column group (8 byte rows x 64 columns = 512 bytes).
*                 GAL_L2T_MODE_32 - the data arrange only in 4 byte rows in each column, 512 bytes allocate 2 column groups.
*                 GAL_L2T_MODE_16 - the data arrange only in 2 byte rows in each column, 512 bytes allocate 4 column groups.
*                 GAL_L2T_MODE_8 - the data arrange only in one byte rows in each column, 512 bytes allocate 8 column groups.
*
*                 2nd example : data vector (each # allocate 1 byte) = [0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9, 0xA, 0xB, 0xC, 0xD, 0xE, 0xF] copy to L2-APC-0/1
*
*                                                                               MODE 8
*Column group                    |                                                0                                                                                |
*                                |---------------------------------------------------------------------------------------------------------------------------------|
*        Column                  |        0         |        1        |        ...        |        15       |        16       |        ...        |        63      |
*                                -----------------------------------------------------------------------------------------------------------------------------------
*                                0|        0x0      |        0x1      |        ...        |        0xF      |        0        |        ...        |        0       |
*                                -----------------------------------------------------------------------------------------------------------------------------------
*                                1|        0        |        0        |        ..         |        0        |        0        |        ...        |        0       |
*                b               -----------------------------------------------------------------------------------------------------------------------------------
*                y               2|        0        |        0        |        ...        |        0        |        0        |        ...        |        0       |
*                t               -----------------------------------------------------------------------------------------------------------------------------------
*                e               3|        0        |        0        |        ...        |        0        |        0        |        ...        |        0       |
*                                -----------------------------------------------------------------------------------------------------------------------------------
*                r               4|        0        |        0        |        ...        |        0        |        0        |        ...        |        0       |
*                o               -----------------------------------------------------------------------------------------------------------------------------------
*                w               5|        0        |        0        |        ...        |        0        |        0        |        ...        |        0       |
*                                -----------------------------------------------------------------------------------------------------------------------------------
*                                6|        0        |        0        |        ...        |        0        |        0        |        ...        |        0       |
*                                -----------------------------------------------------------------------------------------------------------------------------------
*                                7|        0        |        0        |        ...        |        0        |        0        |        ...        |        0       |
*                                -----------------------------------------------------------------------------------------------------------------------------------
*
*                                                                               MODE 16
*Column group                    |                                                0                                                                                |
*                                |---------------------------------------------------------------------------------------------------------------------------------|
*        Column                  |        0        |        1        |        ...        |        7        |        8        |        ...        |        63       |
*                                -----------------------------------------------------------------------------------------------------------------------------------
*                                0|        0x0     |        0x2      |        ...        |        0xE      |        0        |        ...        |        0        |
*                                -----------------------------------------------------------------------------------------------------------------------------------
*                                1|        0x1     |        0x3      |        ...        |        0xF      |        0        |        ...        |        0        |
*                b               -----------------------------------------------------------------------------------------------------------------------------------
*                y               2|        0       |        0        |        ...        |        0        |        0        |        ...        |        0        |
*                t               -----------------------------------------------------------------------------------------------------------------------------------
*                e               3|        0       |        0        |        ...        |        0        |        0        |        ...        |        0        |
*                                -----------------------------------------------------------------------------------------------------------------------------------
*                r               4|        0       |        0        |        ...        |        0        |        0        |        ...        |        0        |
*                o               -----------------------------------------------------------------------------------------------------------------------------------
*                w               5|        0       |        0        |        ...        |        0        |        0        |        ...        |        0        |
*                                -----------------------------------------------------------------------------------------------------------------------------------
*                                6|        0       |        0        |        ...        |        0        |        0        |        ...        |        0        |
*                                -----------------------------------------------------------------------------------------------------------------------------------
*                                7|        0       |        0        |        ...        |        0        |        0        |        ...        |        0        |
*                                -----------------------------------------------------------------------------------------------------------------------------------
*
*                                                                               MODE 32
*Column group                    |                                                0                                                                                |
*                                |---------------------------------------------------------------------------------------------------------------------------------|
*        Column                  |        0        |        1         |        2          |        3          |        4        |        ...        |        63    |
*                                -----------------------------------------------------------------------------------------------------------------------------------
*                                0|        0x0     |        0x4       |        0x8        |        0xC        |        0        |        ...        |        0     |
*                                -----------------------------------------------------------------------------------------------------------------------------------
*                                1|        0x1     |        0x5       |        0x9        |        0xD        |        0        |        ...        |        0     |
*                b               -----------------------------------------------------------------------------------------------------------------------------------
*                y               2|        0x2     |        0x6       |        0xA        |        0xE        |        0        |        ...        |        0     |
*                t               -----------------------------------------------------------------------------------------------------------------------------------
*                e               3|        0x3     |        0x7       |        0xB        |        0xF        |        0        |        ...        |        0     |
*                                -----------------------------------------------------------------------------------------------------------------------------------
*                r               4|        0        |        0        |        ...        |        0          |        0        |        ...        |        0     |
*                o               -----------------------------------------------------------------------------------------------------------------------------------
*                w               5|        0        |        0        |        ...        |        0          |        0        |        ...        |        0     |
*                                -----------------------------------------------------------------------------------------------------------------------------------
*                                6|        0        |        0        |        ...        |        0          |        0        |        ...        |        0     |
*                                -----------------------------------------------------------------------------------------------------------------------------------
*                                7|        0        |        0        |        ...        |        0          |        0        |        ...        |        0     |
*                                -----------------------------------------------------------------------------------------------------------------------------------
*
*                                                                               MODE 64
*Column group                    |                                                0                                                                                |
*                                |---------------------------------------------------------------------------------------------------------------------------------|
*        Column                  |        0           |        1          |        2        |        3        |        4        |        ...        |        63    |
*                                 ----------------------------------------------------------------------------------------------------------------------------------
*                                0|        0x0        |        0x8        |        0        |        0        |        0        |        ...        |        0     |
*                                -----------------------------------------------------------------------------------------------------------------------------------
*                                1|        0x1        |        0x9        |        0        |        0        |        0        |        ...        |        0     |
*                b               -----------------------------------------------------------------------------------------------------------------------------------
*                y               2|        0x2        |        0xA        |        0        |        0        |        0        |        ...        |        0     |
*                t               -----------------------------------------------------------------------------------------------------------------------------------
*                e               3|        0x3        |        0xB        |        0        |        0        |        0        |        ...        |        0     |
*                                -----------------------------------------------------------------------------------------------------------------------------------
*                r               4|        0x4        |        0xC        |        0        |        0        |        0        |        ...        |        0     |
*                o               -----------------------------------------------------------------------------------------------------------------------------------
*                w               5|        0x5        |        0xD        |        0        |        0        |        0        |        ...        |        0     |
*                                -----------------------------------------------------------------------------------------------------------------------------------
*                                6|        0x6        |        0xE        |        0        |        0        |        0        |        ...        |        0     |
*                                -----------------------------------------------------------------------------------------------------------------------------------
*                                7|        0x7        |        0xF        |        0        |        0        |        0        |        ...        |        0     |
*                                -----------------------------------------------------------------------------------------------------------------------------------
*
*        L2_READY Description -
*                There is two states: 1) GAL_L2DMA_L2_READY_SET - the direction of transferring data is between L4/L3 <---> L2.
*                                     2) GAL_L2DMA_L2_READY_RST - the direction of transferring data is between L2 <---> L1.
*                When the device FW start, the l2_ready state is GAL_L2DMA_L2_READY_SET.
*                Each application that uses L2DMA should return the state to GAL_L2DMA_L2_READY_SET before running gal_l2dma functions.
*                To keep l2_ready state without change you can use GAL_L2DMA_L2_READY_NOP instead of GAL_L2DMA_L2_READY_SET or GAL_L2DMA_L2_READY_RST.
*
*        L2DMA Transaction Description (see struct gal_l2dma_l4_l2_transaction declaration) -
*        When using gal_l2dma_l2_to_mem_start & gal_l2dma_mem_to_l2_start functions, there is a need to set the transaction parameters.
*                        step_size - size in bytes, start where l4_addr point to. TODO remove this line
*                        step_size_num_64b_chunk - number of 64 bytes chunks, start where l4_addr point to.
*                        num_steps - number of iterations of copying steps, if l4_step_stride = 0, num_step value must be 1.
*                        l4_addr - pointer to L4/L3.
*                        l4_step_stride - describe the size in bytes from the first byte of a step to the first byte of the next step, if num_step = 1,  l4_step_stride has no meaning.
*                        l2_mode - mode type, see explanation above "working in different mode type".
*                        l2_addr.l2_col_group - start copying the data to this column group (0 - 63).
*                        l2_addr.l2_byte_row - start copying the data to this byte row.
*                                1) In GAL_L2T_MODE_64: l2_addr.l2_byte_row must be 0.
*                                2) In GAL_L2T_MODE_32: l2_addr.l2_byte_row can be 0 - 4.
*                                3) In GAL_L2T_MODE_16: l2_addr.l2_byte_row can be 0 - 6.
*                                3) In GAL_L2T_MODE_8: l2_addr.l2_byte_row can be 0 - 7.
*                        l2_step_col_group - step to the next column continuously (value can be 0 - 63).
*                                example:  l2_step_col_group = 4, l2_addr.l2_col_group = 0, num_steps = 15, data of steps 0..15 will copy to column groups 0, 4, 8, 12, 16, ..., 60.
*                        l2_rep_colgrp_stride - duplicated the transaction defined by above fields repeatedly to the next column groups.
*                                example:  if l2_addr.l2_col_group = 0 and l2_rep_colgrp_stride = 2, the transaction data will be duplicated to column groups 0, 2, 4, 6, 8, ..., 62.
*/

/*
 * gal_l2dma_rep_mem_to_l2 - Copy data from L4/L3 to L2 using l2dma, data duplicated to both L2-APC's.
 *
 * Input:
 *         @sys_addr - Address in L4/L3.
 *         @num_64b_chunk - Number of 64 byte chunks to copy, more info in comments.
 *         @gal_l2t_mode_type - L2T mode type, more info in comments.
 *         @l2_ready_attr - l2_ready next-state for both L2-APC's.
 *
 * Comments:
 *         If num_64b_chunk = 0: l2_ready next-state change to l2_ready_attr value
 *
 *         When num_64b_chunk * 64 bytes > max L2-APC 0 size per l2t_mode the data isn't duplicated between L2-APC-0 & L2-APC-1, it's divided between the L2-APC's(start in L2-APC-0).
 *                 GAL_L2T_MODE_8: L2-APC 0/1 max size = 4096 bytes.
 *                 GAL_L2T_MODE_16: L2-APC 0/1 max size = 8192 bytes.
 *                 GAL_L2T_MODE_32: L2-APC 0/1 max size = 16384 bytes.
 *                 GAL_L2T_MODE_64: L2-APC 0/1 max size =  32768 bytes.
 *
 *         If num_64b_chunk * 64 bytes > 2 * L2-APC 0/1 max size: will generate an error
 */
void gal_l2dma_rep_mem_to_l2(u8 *sys_addr, u32 num_64b_chunk, enum gal_l2t_mode_type mode_type, enum gal_l2dma_cmd_attr l2_ready_attr);

/*
 * gal_l2dma_copy_l2_to_mem_ext - Copy data from L2 to L4/L3 using l2dma, depend on, mode_type, num_bytes & l2_colgrp values to copy from both L2-APC's.
 *
 * Input:
 *         @sys_addr - Address in L4/L3.
 *         @l2_colgrp - Start copy from this column group (0 - 63 L2-APC-0 / 64 - 127 L2-APC-1)
 *         @ num_64b_chunk - Number of 64 byte chunks to copy.
 *         @gal_l2t_mode_type - L2T mode type, more info in comments.
 *         @l2_ready_attr - l2_ready next state for both L2-APC's.
 *
 * Comments:
 *         If num_64b_chunk = 0: l2_ready next state change in both L2-APC's.
 *        When num_64b_chunk * 64 bytes + l2_colgrp(0 - 63) > L2-APC-0 size, remain bytes copied to L2-APC-1, start from column group 0.
 *         If num_64b_chunk * 64 bytes + l2_colgrp >  2 * APC 0/1 max size: Will generate an error
 */
void gal_l2dma_copy_l2_to_mem_ext(u8 *sys_addr, u8 l2_colgrp, u32 num_64b_chunk, enum gal_l2t_mode_type mode_type, enum gal_l2dma_cmd_attr l2_ready_attr);

/*
 * gal_l2dma_copy_mem_to_l2_ext - Copy data from L4/L3 to L2 using l2dma, depend on, mode_type, num_bytes & l2_colgrp values to copy to both L2-APC's.
 *
 * Input:
 *         @l2_colgrp - Start copy to this column group (0 - 63 L2-APC-0 / 64 - 127 L2-APC-1)
 *         @sys_addr - Address in L4/L3.
 *         @num_64b_chunk - Number of 64 byte chunks to copy.
 *         @gal_l2t_mode_type - L2T mode type, more info in comments.
 *         @l2_ready_attr - l2_ready next state for both L2-APC's.
 *
 * Comments:
 *         If num_64b_chunk = 0: l2_ready next state change in both L2-APC's.
 *        When num_64b_chunk * 64 bytes + l2_colgrp(0 - 63) > L2-APC-0 size, remain bytes copied to L2-APC-1, start from column group 0.
 *         If num_64b_chunk * 64 bytes + l2_colgrp >  2 * APC 0/1 max size: Will generate an error
 */
void gal_l2dma_copy_mem_to_l2_ext(u8 l2_colgrp, u8 *sys_addr, u32 num_64b_chunk, enum gal_l2t_mode_type mode_type, enum gal_l2dma_cmd_attr l2_ready_attr);

/*
 * gal_l2dma_l2_ready_rst_all - Change l2_ready state to GAL_L2DMA_L2_READY_RST on both L2-APC's
 *
 * Comments:
 *         Call to this function only if l2_ready current state is GAL_L2DMA_L2_READY_SET.
 */
void gal_l2dma_l2_ready_rst_all(void);

/*
 * gal_l2dma_l2_to_mem_start - Copy data from specific L2-APC to L4/L3 using l2dma.
 *
 * Input:
 *         @apc_id - L2-APC-# (0 - L2-APC 0/ 1 - L2-APC-1).
 *         @num_transactions -  Number of transactions to do.
 *         @transactions - Array of transactions.
 *         @l2_ready_attr - l2_ready state for the L2-APC-# after all transactions ended.
 *
 * Return value:
 *        @gal_l2dma_hndl_t * - Handle to the transactions, pass the the handle to gal_l2dma_sync() or gal_sync_many().
 *
 * Comments:
 *         See L2DMA transaction description above.
 *        After calling this function you must call to gal_l2dma_sync() or gal_sync_many() for transactions completion.
 *
 */
gal_l2dma_hndl_t *gal_l2dma_l2_to_mem_start(uint apc_id, uint num_transactions, struct gal_l2dma_l4_l2_transaction *transactions, enum gal_l2dma_cmd_attr l2_ready_attr);

/*
 * gal_l2dma_mem_to_l2_start - Copy data from L4/L3 to specific L2-APC using l2dma.
 *
 * Input:
 *         @apc_id - L2-APC-# (0 - L2-APC 0/ 1 - L2-APC-1).
 *         @num_transactions -  Number of transactions to do.
 *         @transactions - Array of transactions.
 *         @l2_ready_attr - l2_ready state for the L2-APC-# after all transactions ended.
 *
 * Return value:
 *        @gal_l2dma_hndl_t * - Handle to the transactions.
 *
 * Comments:
 *         See L2DMA transaction description above.
 *        After calling this function you must call to gal_l2dma_sync() or gal_sync_many() for transactions completion.
 */
gal_l2dma_hndl_t *gal_l2dma_mem_to_l2_start(uint apc_id, uint num_transactions, struct gal_l2dma_l4_l2_transaction *transactions, enum gal_l2dma_cmd_attr l2_ready_attr);

/*
 * gal_l2dma_sync - Wait for transactions completion.
 *
 * Input:
 *         @ioxs - Handle to transactions.
 *         @do_blocking - true: function wait until the transactions complete.
 *                                     false: function return without transactions complete, user responsibility to check when the transactions complete.
 *
 * Return value:
 *        true - transactions completed.
 *        false - transactions not completed.
 */
bool gal_l2dma_sync(gal_l2dma_hndl_t *ioxs, bool do_blocking);

/*
 * gal_sync_many_blocking - Wait for transactions completion from different L2-APC's.
 *
 * Input:
 *         @ioxs - Array of handles to transactions from different L2-APC's.
 *         @count - Size of the handles array (array max size count = 2, L2-APC-A/L2-APC-B).
 */
void gal_sync_many_blocking(gal_l2dma_hndl_t **ioxs, int count);

/*
 * profile functions
 */

/*
 * gal_prof_reset - Reset Performance Monitor count.
 *
 * Comments - use only in simulation, on HW this is an empty function.
 */
//use only in simulator
void gal_prof_reset(void);

/*
 * gal_pm_start - Start Performance Monitor count.
 */
void gal_pm_start(void);

/*
 * gal_pm_stop - Stop Performance Monitor count.
 */
void gal_pm_stop(void);

/*
 * gal_get_pm_cycle_count - Get Performance Monitor cycle count.
 *
 * Input:
 * 	    @is_live - If false there is a need to call gal_pm_stop before calling this function.
 * 	    		      If true there is no need to call gal_pm_stop before calling this function.
 *
 * Return value:
 * 	     Number of cycles.
 */
unsigned long long gal_get_pm_cycle_count(bool is_live);

/*
 * gal_get_pm_inst_count - Get Performance Monitor instruction count.
 *
 * Input:
 * 	    @is_live - If false there is a need to call gal_pm_stop before calling this function.
 * 	    		      If true there is no need to call gal_pm_stop before calling this function.
 *
 * Return value:
 * 	     Number of instructions.
 */
unsigned long long gal_get_pm_inst_count(bool is_live);

/*
 * gal_pm_get_cycle_reg_no_reset - Get Performance Monitor cycle count.
 *
 * Return value:
 * 	     Number of cycles.
 */
unsigned long long gal_pm_get_cycle_reg_no_reset(void);

/*
 * L2/L1 Address funcs
 */
unsigned char gal_encode_l2_addr(uint byte_idx, uint bit_idx);
unsigned short gal_vm_reg_to_addr(int vm_reg);
unsigned short gal_vm_reg_to_set_ext(int vm_reg, unsigned int *parity_set, unsigned int *row_in_set, unsigned int *parity_grp, unsigned int *parity_row);

/*
 * Log functions
 */

/*
 * gal_fatal - Output an error message and abort the program.
 */
#define gal_fatal(...) _gal_log_fatal(__FILE__, __LINE__, __func__, "FATAL", ##__VA_ARGS__)
void _gal_log_fatal(const char *file, int line, const char *func, const char *prompt, const char *fmt, ...);

/*
 * Info funcs
 */

/*
 * gal_apc_num_banks - Return the number of banks in an APC.
 *
 * Return value:
 *        Number of banks in an APC.
 */
unsigned int gal_apc_num_banks(void);

/*
 * gal_apuc_num_apcs - Return the number of APC's.
 *
 * Return value:
 *        Number of  APC's.
 */
unsigned int gal_apuc_num_apcs(void);

/*
 * gal_cache_uc_u32_rd - Read uncached data from L4/L3.
 *
 * Input:
 * 	     @addr - Address where data located.
 *
 * Return value:
 *        Data vlaue.
 */
//u32 gal_cache_uc_u32_rd(u32 addr);

/*
 * gal_cache_uc_u32_wr - Write uncached data to L4/L3.
 *
 * Input:
 * 	     @addr - Address to write the data.
 * 	     @data - Data to write.
 */
//void gal_cache_uc_u32_wr(u32 addr, u32 data);

/*
 *        param :[in] uint32_t chunk_index - chunk # that user function about to process.
 *        param :[in] uint32_t l3_buffer_ptr - beginning point of one of the double buffer.
 *        param :[in/out] void * user_data - I/O I/F for user.
 */
typedef void (*gal_user_func_t)(u32 chunk_index, u32 l3_buffer_ptr, void *user_data);

/*
 * function name : gal_l2dma_proc_l4_on_l3.
 * description: copy buffer from L4 into L3 using l2dma and run user function.
 * param :[in]uint8_t *buffer_l4_start_ptr - start address of L4 buffer that is going to be processed at L3.
 * param :[in]uint32_t buffer_l4_size - L4 buffer size, should be aligned to chunk_size.
 * param :[in]uint32_t chunk_size - size of buffer that user wish to process on L3 per one user function call. max size 64*1024 bytes, aligned to 512.
 * param :[in]gal_user_func_t user_func_ptr -  pointer for user processing function.
 * return 0 for success or negative errno number for failure .
 */
int gal_l2dma_proc_l4_on_l3(u8 *buffer_l4_start_ptr, u32 buffer_l4_size, u32 chunk_size, gal_user_func_t user_func_ptr, void *user_data_ptr);

/*
 * function name : gal_l2dma_copy_L4_to_L3.
 * description:  apuc_l2dma copy 512 bytes from l4 to l3 via l2t.
 * param : [in]u32 dst - L3 destination address.
 * param : [in]u32 src - L4 source address.
 *param : [in]u32 size_in_byte - buffer size,should be 512 align.
 * return 0 for success, -1 for fail.
 */


u32 gal_l2dma_copy_L4_to_L3(u32 dst, u32 src, u32 size_in_byte);

/*
 * gal_is_l3_addr - Check if the address is in L3
 *
 * Return value:
 * 	     0 - Address isn't on L3.
 * 	     1 - Address is on L3.
 */


u32 gal_is_l3_addr(u32 addr);

/*
 * function name : gal_mem_handle_to_apu_ptr
 * description: translates a memory handle to an apu address the device can access
 * param: [in]: handle - a memory handle allocated from the L4 apu's memory.
 * return value : void * - a 32 bit address that the apu can access, on failure returns NULL.
 * 
 * comments:
 * 	the functions can receive memory handles from both the dynamic memory and the constant memory 
 */

void *gal_mem_handle_to_apu_ptr(gal_mem_handle_t handle);

// garc cache functions

/*
 * gal_cache_dcache_flush - Flush all data cache lines
 */

void gal_cache_dcache_flush(void);

/*
 * gal_cache_uc_u8_dst_memset - Uncached memset.
* Input:
 * 	     @dst_addr - Address of memory to set.
 * 	     @data - Data to set.
 * 	     @size - Size of memory to set.
 */

void gal_cache_uc_u8_dst_memset(u32 dst_addr, u8 data, u32 size);

/*
 * gal_set_l4_dma_desc - set the descriptors for the L4 DMA for both APC's and activate it.
 *
 * Input:
 *         @cmd_desc - a single command descriptors.
 * 		   @type - type of transaction (read/write).
 *
 * Return value:
 *
 * 			= 0 - OK.
 *  		!= 0 - error code
 *
 * Comments:
 * 			- cmd_desc.num_l4_addrs must be <= 32
 * 			- cmd_desc.repeat must be <= 4095
 * 			- This function should only be called when indirect mode is enabled, if the function is called in
 * 			  direct mode then the next time l2dma will be called in indirect mode undefined behavior could occur.
 * 			- the function prepares the descriptors for both APC's, if there is a need to work with a single APC then DIRECT DMA mode should be used.
 * 			- The function should not be called again until the L2 DMA has finished transfering all the data that was described in the descriptors,
 * 			  if the function is called before the DMA has finished with all the L4 descriptors the function will block until the DMA has finished.
 * 			- currently l2t_mode and step_stride_in_col_group are unused.
 *								
 */
int gal_set_l4_dma_desc(struct gal_l4dma_cmd_desc *cmd_desc, enum gal_l4_dma_transaction_type type);

/*
 * gal_set_l2dma_dma_mode - set the dma mode for all the following l2dma transactions.
 *
* Input:
 * 	     @dma_mode - the wanted dma mode to set ( GAL_L2DMA_MODE_DIRECT | GAL_L2DMA_MODE_INDIRECT).
 *
 * Return value:
 * 	       	= 0 - OK.
 *  		!= 0 - error code
 *
 * Comments:
 *
 * 		- Once the dma mode is set all the l2dma transcation from thenceforth will be executed according to to the requested state, until the mode will be changed again.
 * 		- The function can be called unlimited amount of times and the mode can be changed per transaction.
 *
 */
int gal_set_l2dma_dma_mode(enum gal_l2dma_dma_mode dma_mode);

/*
 * gal_get_l2dma_dma_mode - get the current dma mode.
 *
 *
 * Return value:
 *
 * 		- the current dma mode ( 0 = Direct | 1 = Indirect)
 *
 */

uint gal_get_l2dma_dma_mode(void);

/*
 * gal_cache_dcache_invalidate_mlines - Invalidate multi data cache lines.
* Input:
 * 	     @start_addr - Start address in data cache.
 * 	     @size - The bytes to be invalidated.
 *
 * Return value:
 * 	     0 - Succeeded.
 */
//int gal_cache_dcache_invalidate_mlines(u32 start_addr, u32 size);

/*
 * gal_cache_dcache_flush_mlines - Flush multi lines in data cache.
* Input:
 * 	     @start_addr - Start address in data cache.
 * 	     @size - The bytes to be flushed.
 *
 * Return value:
 * 	     0 - Succeeded.
 */
//int gal_cache_dcache_flush_mlines(u32 start_addr, u32 size);


#endif /* GSI_LIBGAL_H_ */
