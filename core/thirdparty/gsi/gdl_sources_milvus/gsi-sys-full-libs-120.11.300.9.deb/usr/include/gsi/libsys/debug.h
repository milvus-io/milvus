/*
 * Copyright (C) 2016, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */
#ifndef GSI_DEBUG_H
#define GSI_DEBUG_H

#include "log.h"
#include "types.h"
#include "debug_cookie.h"

#if defined(GSI_LIBSYS_AARCH64) || defined(GSI_LIBSYS_X86_64) || defined(GSI_LIBSYS_X86_32)
#include <gsi/libsys/io.h>
#endif

extern int gsi_debug_level;

#define GSI_DEBUG_MAX_MODULE_NAME (32-1)
#define GSI_DEBUG_MAX_MODULES 1024
#define GSI_DEBUG_MAX_DEBUG_OPT_LEN 64

extern const char *gsi_debug_get_opt(void);
extern void arc_register_modules(void);
/*
 * opt syntax: name[=level][,...]
 *
 * *[=level]: set global debug level
 */
extern void gsi_debug_set_opt(const char *opt);

#define _gsi_debug_module_decl_str(_var, _module_str)               \
static struct gsi_debug_module_cookie __attribute__((section("gsi_debug"), unused)) __gsi_debug_module_##_var = { \
	.module_name = _module_str, \
};
#define _gsi_debug_module_decl(_var, _module) _gsi_debug_module_decl_str(_var, #_module)

#ifdef DEBUG_BUILD
static inline int _gsi_debug_module_level(const struct gsi_debug_module_cookie *cookie)
{
	return (cookie->module_level && *cookie->module_level >= 0) ? *cookie->module_level : gsi_debug_level;
}
#else
static inline int _gsi_debug_module_level(GSI_UNUSED(const struct gsi_debug_module_cookie *cookie))
{
	return 0;
}
#endif

#define _gsi_debug_module_cookie(_var) __gsi_debug_module_##_var

#define gsi_debug_module_level() _gsi_debug_module_level(&gsi_debug_module_cookie())

extern void _gsi_debug(int level, const struct gsi_debug_module_cookie *cookie,
                       const char *file, int line, const char *func,
                       const char *fmt, ...) __attribute__((format(printf, 6, 7)));

extern void _gsi_vdebug(int level, const struct gsi_debug_module_cookie *cookie,
                        const char *file, int line, const char *func,
                        const char *fmt, va_list ap);
/*
 * if level < 0, gsi_debug() acts like gsi_info()
 */
#define gsi_debug(_level, ...) do {                           \
		if ((_level) <= gsi_debug_module_level()) { \
			if((_level) < 0) { \
				_gsi_log(__FILE__, __LINE__, __func__, GSI_LOG_INFO, "INFO", ##__VA_ARGS__); \
			} else { \
				_gsi_debug(_level, &gsi_debug_module_cookie(), __FILE__, __LINE__, __func__, ##__VA_ARGS__); \
			} \
		} \
	} while (0)

#if defined(GSI_LIBSYS_AARCH64) || defined(GSI_LIBSYS_X86_64) || defined(GSI_LIBSYS_X86_32)
extern void gsi_debug_desc(GSI_FILE *fp);
#endif

#include "debug_module.h"

#endif /* GSI_DEBUG_H */
