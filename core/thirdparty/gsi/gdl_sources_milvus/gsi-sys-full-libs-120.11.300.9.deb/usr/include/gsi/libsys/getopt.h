/*
 * Copyright (C) 2016, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */

#ifndef GSI_GETOPT_H
#define GSI_GETOPT_H

// #include "config.h"

#if defined(GSI_LIBSYS_AARCH64) || defined(GSI_LIBSYS_X86_64) || defined(GSI_LIBSYS_X86_32)

#include <stdio.h>
#include <unistd.h>

enum gsi_getopt_type {
	GSI_OPT_NO_TYPE = 0,
	GSI_OPT_BOOL,
	GSI_OPT_INT,
	GSI_OPT_LONG,
	GSI_OPT_FLOAT,
	GSI_OPT_STRING,
	GSI_OPT_STR_OPT,
	GSI_OPT_PATH,
	GSI_OPT_CONCATENATED_STRINGS,
};

enum gsi_getopt_flags {
	GSI_OPT_REQUIRED		= 1 << 0,
	GSI_OPT_HAS_ARG			= 1 << 1,
	GSI_OPT_HAS_DEFAULT		= 1 << 3,
	GSI_OPT_HAS_OPTIONAL_ARG	= (GSI_OPT_HAS_ARG | GSI_OPT_HAS_DEFAULT),
	GSI_OPT_POSITIONAL		= 1 << 4,
	GSI_OPT_HAS_RANGE		= 1 << 5,
	GSI_OPT_USAGE			= 1 << 6,
	GSI_OPT_USAGE_EXIT		= 1 << 7,
	GSI_OPT_ADVANCED		= 1 << 8,	/* Advanced option, not printed by default usage */
	GSI_OPT_FUNCTION		= 1 << 9,
	GSI_OPT_DESC_FUNCTION		= 1 << 10,

	GSI_OPT_INDIR			= 1 << 30,	/* indirect, point to a gsi_option array */
	GSI_OPT_IGNORE			= 1 << 31,
};

enum gsi_getopt_help_flags {
	GSI_OPT_HELP_FLAG_BASIC		= 1 << 0,
	GSI_OPT_HELP_FLAG_POSITIONAL	= 1 << 1,
	GSI_OPT_HELP_FLAG_EXTENDED	= 1 << 2,
	GSI_OPT_HELP_FLAG_EXTRA		= 1 << 3,
	GSI_OPT_HELP_FLAG_ADVANCED	= 1 << 4,

	GSI_OPT_HELP_MODE_DEFAULT	= GSI_OPT_HELP_FLAG_BASIC | GSI_OPT_HELP_FLAG_POSITIONAL |
	                                  GSI_OPT_HELP_FLAG_EXTENDED | GSI_OPT_HELP_FLAG_EXTRA |
	                                  GSI_OPT_HELP_FLAG_ADVANCED,
};

/*
 * string to int mapping
 */
struct gsi_str_opt {
	const char *str;	/* last entry in table marked with NULL */
	size_t min_len;		/* optional: min number of chars to match. 0=all */
	int val;
	const char *desc;
};

struct gsi_option {
	const char *name;
	char opt_char;
	void *desc; /* optional */
	uint flags;
	enum gsi_getopt_type type;
	/* optional */
	void *opt_arg;
	void *opt_extra;	/* used for str_opt table */
	union {
		bool b;
		long i;
		double d;
		const char *s;
	} def, range_min, range_max;

	/* library set */
	bool encountered;
};

extern struct gsi_str_opt gsi_getopt_log_level_opts[];

extern const char *gsi_getopt_optarg;
extern enum gsi_getopt_help_flags gsi_getopt_help_mode;

extern void gsi_usage(const struct gsi_option *opts, bool do_exit);
extern void gsi_fusage(FILE *fp, const struct gsi_option *opts, bool do_exit);
extern struct gsi_option *gsi_getopt(int argc, char *const argv[], struct gsi_option *opts);
extern void gsi_getopt_rewind(struct gsi_option *opt /* optional */);
extern gsi_status_t gsi_getopt_ignore(struct gsi_option *opt, char opt_char, const char *long_opt);
extern void gsi_getopts(int argc, char *const argv[], struct gsi_option *opts);
extern void gsi_fw_getopts(int argc, char *const argv[], struct gsi_option *opts);

extern const char *get_str_opt_str(const struct gsi_str_opt *sop, int val);
extern int get_str_opt_val(const struct gsi_str_opt *sop, const char *str);

#endif /* defined(GSI_LIBSYS_AARCH64) || defined(GSI_LIBSYS_X86_64) || defined(GSI_LIBSYS_X86_32) */

#endif /* GSI_GETOPT_H */
