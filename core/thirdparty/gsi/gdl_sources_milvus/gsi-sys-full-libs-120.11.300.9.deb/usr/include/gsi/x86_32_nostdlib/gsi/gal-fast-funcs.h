/*
 * Copyright (C) 2020, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */

#ifndef GAL_FAST_FUNCS_H_
#define GAL_FAST_FUNCS_H_

#include <gsi/libgal.h>

#ifndef PAGE_SIZE
#define PAGE_SIZE (4096)
#endif

#ifndef NULL
#define NULL	((void *)0)
#endif

struct gal_fast_l2dma_l4_l2_transaction {
	uint num_steps;
	uint step_size_num_512b_chunk; /* number of chunks - each chunk is 512 bytes */
	void *l4_addr;
	u8 l2_mode;
	u8 l2_col_group;        /* column groups in 64 l2 columns resolution (values 0 - 63) */
};

static inline void gal_fast_event(GSI_UNUSED(u32 buffer), GSI_UNUSED(u32 data))
{

}

static inline void gal_fast_cache_uc_u32_wr( GSI_UNUSED(u32 addr),  GSI_UNUSED(u32 data))
{
	return;
}

static inline u32 gal_fast_cache_uc_u32_rd( GSI_UNUSED(u32 addr))
{
	return 0;
}

static inline gal_l2dma_hndl_t *gal_fast_l2dma_mem_to_l2_start(uint apc_id, uint num_transactions, struct gal_fast_l2dma_l4_l2_transaction *transactions, enum gal_l2dma_cmd_attr l2_ready_attr)
{
	struct gal_l2dma_l4_l2_transaction trans[num_transactions];

	for(uint i = 0; i < num_transactions; ++i) {
//		memset(trans[i], 0, sizeof(gal_l2dma_l4_l2_transaction));
		trans[i].l4_addr = transactions[i].l4_addr;
		trans[i].l2_mode = transactions[i].l2_mode;
		trans[i].num_steps = transactions[i].num_steps;
		trans[i].step_size_num_64b_chunk = transactions[i].step_size_num_512b_chunk * 8;
		trans[i].l2_addr.l2_col_group = transactions[i].l2_col_group;
	}

	return gal_l2dma_mem_to_l2_start(apc_id, num_transactions, trans, l2_ready_attr);
}

static inline gal_l2dma_hndl_t *gal_fast_l2dma_mem_to_l2_start_indirect(uint apc_id, uint num_transactions, struct gal_fast_l2dma_l4_l2_transaction *transactions, enum gal_l2dma_cmd_attr l2_ready_attr)
{
	struct gal_l2dma_l4_l2_transaction trans[num_transactions];

	for(uint i = 0; i < num_transactions; ++i) {
//		memset(trans[i], 0, sizeof(gal_l2dma_l4_l2_transaction));
		trans[i].l4_addr = transactions[i].l4_addr;
		trans[i].l2_mode = transactions[i].l2_mode;
		trans[i].num_steps = transactions[i].num_steps;
		trans[i].step_size_num_64b_chunk = transactions[i].step_size_num_512b_chunk * 8;
		trans[i].l2_addr.l2_col_group = transactions[i].l2_col_group;
	}

	gal_set_l2dma_dma_mode(GAL_L2DMA_MODE_INDIRECT);

	return gal_l2dma_mem_to_l2_start(apc_id, num_transactions, trans, l2_ready_attr);
}

static inline gal_l2dma_hndl_t *gal_fast_l2dma_l2_to_mem_start(uint apc_id, uint num_transactions, struct gal_fast_l2dma_l4_l2_transaction *transactions, enum gal_l2dma_cmd_attr l2_ready_attr)
{
	struct gal_l2dma_l4_l2_transaction trans[num_transactions];

	for(uint i = 0; i < num_transactions; ++i) {
//		memset(trans[i], 0, sizeof(gal_l2dma_l4_l2_transaction));
		trans[i].l4_addr = transactions[i].l4_addr;
		trans[i].l2_mode = transactions[i].l2_mode;
		trans[i].num_steps = transactions[i].num_steps;
		trans[i].step_size_num_64b_chunk = transactions[i].step_size_num_512b_chunk * 8;
		trans[i].l2_addr.l2_col_group = transactions[i].l2_col_group;
	}

	return gal_l2dma_l2_to_mem_start(apc_id, num_transactions, trans, l2_ready_attr);
}

static inline gal_l2dma_hndl_t *gal_fast_l2dma_l2_to_mem_start_indirect(uint apc_id, uint num_transactions, struct gal_fast_l2dma_l4_l2_transaction *transactions, enum gal_l2dma_cmd_attr l2_ready_attr)
{
	struct gal_l2dma_l4_l2_transaction trans[num_transactions];

	for(uint i = 0; i < num_transactions; ++i) {
//		memset(trans[i], 0, sizeof(gal_l2dma_l4_l2_transaction));
		trans[i].l4_addr = transactions[i].l4_addr;
		trans[i].l2_mode = transactions[i].l2_mode;
		trans[i].num_steps = transactions[i].num_steps;
		trans[i].step_size_num_64b_chunk = transactions[i].step_size_num_512b_chunk * 8;
		trans[i].l2_addr.l2_col_group = transactions[i].l2_col_group;
	}

	gal_set_l2dma_dma_mode(GAL_L2DMA_MODE_INDIRECT);

	return gal_l2dma_l2_to_mem_start(apc_id, num_transactions, trans, l2_ready_attr);
}

static inline bool gal_fast_l2dma_sync(gal_l2dma_hndl_t *ioxs, GSI_UNUSED(u32 apc_id), bool do_blocking)
{
	return gal_l2dma_sync(ioxs, do_blocking);
}

static inline void gal_fast_sync_many_blocking(gal_l2dma_hndl_t **ioxs, int count)
{
	gal_sync_many_blocking(ioxs, count);
}

static inline void gal_fast_l2dma_memset(u8 *dst, u8 data, u32 size, GSI_UNUSED(u32 apc_id), GSI_UNUSED(bool inval_dst), GSI_UNUSED(void *l3_512_bytes_buffer))
{
	memset(dst, data, size);
}

static inline void gal_fast_l2dma_async_memcpy_init(GSI_UNUSED(u32 apc_id))
{
	return;
}

static inline void gal_fast_l2dma_async_memcpy_end(GSI_UNUSED(u32 apc_id))
{
	return;
}

static inline int gal_fast_cache_dcache_flush_mlines(GSI_UNUSED(u32 start_addr), GSI_UNUSED(u32 size))
{
	return 0;
}

static inline void gal_fast_set_l2dma_direct_mode(void)
{
	gal_set_l2dma_dma_mode(GAL_L2DMA_MODE_DIRECT);
}

static inline int gal_fast_cache_dcache_invalidate_mlines(GSI_UNUSED(u32 start_addr), GSI_UNUSED(u32 size))
{
	return 0;
}

static inline void gal_fast_l2dma_l2_ready_rst_all()
{
	gal_l2dma_l2_ready_rst_all();
}

static inline void gal_fast_l2dma_async_memcpy(u8 *dst,
                u8 *src,
                u32 size,
                GSI_UNUSED(u32 apc_id),
                GSI_UNUSED(bool flush_src),
                GSI_UNUSED(bool inval_dst),
                GSI_UNUSED(bool flush_dst_edges),
		GSI_UNUSED(bool inval_dst_post_memcpy),
		GSI_UNUSED(bool inval_src_post_memcpy))
{
	memcpy(dst, src, size);
}

static inline u32 gal_fast_apuc_id(void)
{
	return 0;
}

enum {
	GAL_FAST_APUC_HZ	= 400000000,
	GAL_FAST_CYCLES_PER_US =  GAL_FAST_APUC_HZ / 1000000,
};

static inline void gal_fast_us_delay(u32 us)
{
	unsigned long long start = gal_get_pm_cycle_count(true);

	while (start + us * GAL_FAST_CYCLES_PER_US > gal_get_pm_cycle_count(true));
}

static inline void gal_fast_cycles_delay(u32 cycles)
{
	unsigned long long start = gal_get_pm_cycle_count(true);

	while (start + cycles > gal_get_pm_cycle_count(true));
}

static inline bool GAL_FAST_IS_ERR(int e)
{
	return e < 0 && -e < (int)PAGE_SIZE;
}

static inline bool GAL_FAST_IS_ERR_PTR_OR_NULL(const void *ptr)
{
	return (ptr == NULL) || GAL_FAST_IS_ERR((int)(intptr_t)ptr);
}

static inline void *gal_fast_malloc_cache_aligned(u32 size, GSI_UNUSED(bool invalidate))
{
	u8 *p = gal_malloc(size + 32 + 32);
	if (GAL_FAST_IS_ERR_PTR_OR_NULL(p))
		return p;

	u32 *algn_p_u32 = (u32 *)((u32)(p + 32) & 0xffffffe0);

	*(algn_p_u32 - 1) = (u32)p;

// 	gsi_info("gal_fast_malloc p = %p algn_p_u32 %p size %d", p, algn_p_u32, size);
	return (void *)algn_p_u32;
}

static inline void gal_fast_free_cache_aligned(void *algn_p)
{
	gal_free((void *)(*(((u32 *)algn_p) - 1)));
}

static inline int gal_fast_set_l4_dma_desc(GSI_UNUSED(struct gal_l4dma_cmd_desc *cmd_desc), GSI_UNUSED(enum gal_l4_dma_transaction_type type)) 
{
	return 0;
}

#endif /*GAL_FAST_FUNCS_H_ */


