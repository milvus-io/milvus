/*
 * Copyright (C) 2016, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */

#ifndef GSI_THREAD_H
#define GSI_THREAD_H

#include "config.h"

#if defined(GSI_LIBSYS_AARCH64) || defined(GSI_LIBSYS_X86_64) || defined(GSI_LIBSYS_X86_32)

#define GSI_THREAD_DEFINED

#include <gsi/libsys/atomic.h>
#include "error.h"

extern bool gsi_libsys_threads_initted;

extern gsi_status_t gsi_libsys_threads_init(void);
extern void gsi_libsys_threads_exit(void);

/* pthread based wrappers */

#include <pthread.h>
#include <semaphore.h>

typedef pthread_t gsi_thread_t;
typedef void *(gsi_thread_func)(void *);

/*
 * create a new thread (with default attributes)
 */
extern gsi_status_t gsi_thread_create(gsi_thread_t *thread_p, gsi_thread_func *start_func, void *arg);

/*
 * join with a terminated thread
 */
extern gsi_status_t gsi_thread_join(gsi_thread_t thread, void **retval_p);

/*
 * detach a thread
 */
extern gsi_status_t gsi_thread_detach(gsi_thread_t thread);

/*
 * cancel a thread
 */
extern gsi_status_t gsi_thread_cancel(gsi_thread_t thread);

/*
 * yield the processor to another thread
 * cancellation point (unlike linux pthread_yield)
 */
extern void gsi_thread_yield(void);
extern void gsi_thread_yield_no_cancel(void);

static inline bool gsi_thread_is_locked(gsi_atomic_t *lock)
{
	return gsi_atomic_is_locked(lock);
}

static inline bool gsi_thread_trylock(gsi_atomic_t *lock)
{
	return gsi_atomic_trylock(lock);
}

static inline void gsi_thread_spinlock(gsi_atomic_t *lock)
{
	while (!gsi_atomic_trylock(lock)) {
		gsi_thread_yield();
	}
}

static inline void gsi_thread_unlock(gsi_atomic_t *lock)
{
	return gsi_atomic_unlock(lock);
}

/*
 * terminate calling thread
 */
static inline void gsi_thread_exit(void *retval)
{
	pthread_exit(retval);
}

/*
 * obtain ID of the calling thread
 */
static inline gsi_thread_t gsi_thread_self(void)
{
	return (gsi_thread_t)pthread_self();
}

/*
 * Mutex
 */
typedef pthread_mutex_t	gsi_thread_mutex_t;

extern gsi_status_t gsi_thread_mutex_init(gsi_thread_mutex_t *mutex);
extern gsi_status_t gsi_thread_mutex_destroy(gsi_thread_mutex_t *mutex);

extern gsi_status_t gsi_thread_mutex_lock_safe(gsi_thread_mutex_t *mutex);
extern gsi_status_t gsi_thread_mutex_trylock_safe(gsi_thread_mutex_t *mutex, bool *acquired);
extern gsi_status_t gsi_thread_mutex_unlock_safe(gsi_thread_mutex_t *mutex);
extern void gsi_thread_mutex_lock(gsi_thread_mutex_t *mutex);

/*
 * trylock follow linux kernel convention (and gsi_atomic_trylock):
 * returns true if lock acquired or false if failed
 */
extern bool gsi_thread_mutex_trylock(gsi_thread_mutex_t *mutex);
extern bool gsi_thread_mutex_is_locked(gsi_thread_mutex_t *mutex);
extern void gsi_thread_mutex_unlock(gsi_thread_mutex_t *mutex);

/*
 * Semaphore
 */
typedef sem_t gsi_thread_sem_t;

extern gsi_status_t gsi_thread_sem_init(gsi_thread_sem_t *sem, int val);
extern gsi_status_t gsi_thread_sem_post(gsi_thread_sem_t *sem);
extern gsi_status_t gsi_thread_sem_wait(gsi_thread_sem_t *sem, bool persist);
extern gsi_status_t gsi_thread_sem_timedwait(gsi_thread_sem_t *sem, bool persist, const struct timespec *abs_timeout);
extern gsi_status_t gsi_thread_sem_destroy(gsi_thread_sem_t *sem);

/*
 * Condition variables
 */
typedef pthread_cond_t	gsi_thread_cond_t;

extern gsi_status_t gsi_thread_cond_init(gsi_thread_cond_t *cond);
extern gsi_status_t gsi_thread_cond_destroy(gsi_thread_cond_t *cond);

extern gsi_status_t gsi_thread_cond_wait_safe(gsi_thread_cond_t *cond, gsi_thread_mutex_t *mutex);
extern gsi_status_t gsi_thread_cond_wait_until_safe(gsi_thread_cond_t *cond, gsi_thread_mutex_t *mutex, const struct timespec *abstime);
extern void gsi_thread_cond_wait(gsi_thread_cond_t *cond, gsi_thread_mutex_t *mutex);
/* return true if timed out */
extern void gsi_thread_cond_get_abstime(struct timespec *abstime, const struct timespec *delta);
extern bool gsi_thread_cond_wait_until(gsi_thread_cond_t *cond, gsi_thread_mutex_t *mutex, const struct timespec *abstime);

static inline bool gsi_thread_cond_wait_delta(gsi_thread_cond_t *cond, gsi_thread_mutex_t *mutex, const struct timespec *delta)
{
	struct timespec abstime;
	gsi_thread_cond_get_abstime(&abstime, delta);
	return gsi_thread_cond_wait_until(cond, mutex, &abstime);
}

/*
 * cond_signal and cond)broadcast should be called under
 * the same mutex lock used for cond_wait
 */
extern gsi_status_t gsi_thread_cond_signal_safe(gsi_thread_cond_t *cond, gsi_thread_mutex_t *mutex);
extern gsi_status_t gsi_thread_cond_broadcast_safe(gsi_thread_cond_t *cond, gsi_thread_mutex_t *mutex);
extern void gsi_thread_cond_signal(gsi_thread_cond_t *cond, gsi_thread_mutex_t *mutex);
extern void gsi_thread_cond_broadcast(gsi_thread_cond_t *cond, gsi_thread_mutex_t *mutex);

/*
 * Thread pool
 */
struct gsi_thread_pool;

/*
 * Create a thread pool of @num_threads threads using @job_size sized jobs
 * @worker is called for each job
 */
extern struct gsi_thread_pool *gsi_thread_pool_create(uint num_threads);
extern void gsi_thread_pool_destroy(struct gsi_thread_pool *tp);
extern uint gsi_thread_pool_num_threads(struct gsi_thread_pool *tp);

/*
 * Gracefully terminate the thread pool
 * Wait until all workers exit with optional @timeout
 */
extern gsi_status_t gsi_thread_pool_terminate(struct gsi_thread_pool *tp, struct timespec *timeout);

/*
 * Work queue
 */
struct gsi_workqueue;
struct gsi_workqueue_job;
typedef gsi_status_t (gsi_worker_func)(struct gsi_workqueue_job *job);

enum gsi_workqueue_job_state {
	GSI_WQ_JOB_FREE,
	GSI_WQ_JOB_ALLOC,
	GSI_WQ_JOB_QUEUED,
	GSI_WQ_JOB_EXEC,
	GSI_WQ_JOB_DONE,
};

enum gsi_workqueue_job_flags {
	GSI_WQ_JOB_FLAG_NO_AUTOFREE	= 1 << 0,
	GSI_WQ_JOB_FLAG_DONE_SIGNAL	= 1 << 1,
	GSI_WQ_JOB_FLAG_DONE_BROADCAST	= 1 << 2,
	GSI_WQ_JOB_FLAG_COUNTER		= 1 << 3,

	GSI_WQ_JOB_NO_FLAGS = 0,
	GSI_WQ_JOB_VALID_FLAGS =
	        GSI_WQ_JOB_FLAG_NO_AUTOFREE |
	        GSI_WQ_JOB_FLAG_DONE_SIGNAL |
	        GSI_WQ_JOB_FLAG_DONE_BROADCAST |
	        GSI_WQ_JOB_FLAG_COUNTER
};

struct gsi_workqueue_job {
	struct gsi_slist list;
	gsi_worker_func *worker;
	gsi_thread_cond_t *done_cond;	/* optional, signal when done */
	gsi_thread_mutex_t *done_mutex;	/* optional (yet mandatory with counter) */

	/* optional counter-based signaling */
	gsi_atomic_t *counter;
	int max_count;			/* signal done_cond when *counter >= max_count */

	uint job_flags;
	enum gsi_workqueue_job_state job_state;
	gsi_status_t ret_status;
	struct gsi_workqueue *wq;
	void *arg;			/* arg pointer, or beginning of private data area if priv_size used */
};

static inline void *gsi_workqueue_job_priv_args(struct gsi_workqueue_job *job)
{
	return (void *)&job->arg;
}

extern struct gsi_workqueue *gsi_workqueue_create(struct gsi_thread_pool *tp, size_t priv_size, int init_num_jobs);
extern void gsi_workqueue_destroy(struct gsi_workqueue *);
extern uint gsi_workqueue_num_threads(struct gsi_workqueue *wq);

/*
 * Allocate a job from the workqueue mem_cache
 */
extern struct gsi_workqueue_job *gsi_workqueue_job_alloc(struct gsi_workqueue *wq, uint job_flags);

/*
 * job_free must be called explicitly by allocator if GSI_WQ_JOB_FLAG_NO_AUTOFREE is specified
 */
extern void gsi_workqueue_job_free(struct gsi_workqueue_job *job);

/*
 * Enqueue a job for execution
 */
extern gsi_status_t gsi_workqueue_job_queue(struct gsi_workqueue_job *job, gsi_worker_func *worker, void *opt_arg, gsi_thread_cond_t *opt_done_cond);

static inline bool gsi_workqueue_job_is_done(struct gsi_workqueue_job *job)
{
	return job->job_state == GSI_WQ_JOB_DONE;
}

static inline gsi_status_t gsi_workqueue_job_ret_status(struct gsi_workqueue_job *job)
{
	return gsi_workqueue_job_is_done(job) ? job->ret_status : gsi_status(EBUSY);
}

/*
 * Wait for all executing jobs to complete and pause (some jobs might be left queued)
 */
extern gsi_status_t gsi_workqueue_pause(struct gsi_workqueue *);

/*
 * Wait for all jobs, executing and queued, to complete and pause
 */
extern gsi_status_t gsi_workqueue_flush(struct gsi_workqueue *);

/*
 * Resume workqueue execution after pause
 */
extern void gsi_workqueue_resume(struct gsi_workqueue *);

/*
 * Cancel all pending jobs in queue
 */
extern void gsi_workqueue_cancel(struct gsi_workqueue *);

#endif /* defined(GSI_LIBSYS_AARCH64) || defined(GSI_LIBSYS_X86_64) || defined(GSI_LIBSYS_X86_32) */

#endif /* GSI_THREAD_H */
