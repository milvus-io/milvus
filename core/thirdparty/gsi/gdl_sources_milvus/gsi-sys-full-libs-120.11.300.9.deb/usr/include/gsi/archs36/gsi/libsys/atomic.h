/*
 * Copyright (C) 2016, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */
#ifndef GSI_ATOMIC_H
#define GSI_ATOMIC_H

#include <gsi/libsys/types.h>

typedef struct {
	volatile u32 val;
}  gsi_atomic32_t;

typedef struct {
	volatile u64 val;
}  gsi_atomic64_t;

static inline u32 gsi_atomic32_get(const gsi_atomic32_t *p)
{
	return p->val;
}

static inline u64 gsi_atomic64_get(const gsi_atomic64_t *p)
{
	return p->val;
}

static inline void gsi_atomic32_set(gsi_atomic32_t *p, u32 new_val)
{
	p->val = new_val;
}

static inline void gsi_atomic64_set(gsi_atomic64_t *p, u64 new_val)
{
	p->val = new_val;
}

static inline void gsi_atomic32_add(gsi_atomic32_t *p, u32 val)
{
	p->val += val;
}

static inline void gsi_atomic64_add(gsi_atomic64_t *p, u64 val)
{
	p->val += val;
}

static inline void gsi_atomic32_inc(gsi_atomic32_t *p)
{
	gsi_atomic32_add(p, 1);
}

static inline void gsi_atomic64_inc(gsi_atomic64_t *p)
{
	gsi_atomic64_add(p, 1);
}

#endif /* GSI_ATOMIC_H */
