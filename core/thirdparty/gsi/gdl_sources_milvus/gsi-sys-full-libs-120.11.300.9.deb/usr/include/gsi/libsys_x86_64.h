/*
 * Copyright (C) 2016, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */
#ifndef GSI_LIBSYS_X86_64_H
#define GSI_LIBSYS_X86_64_H

#include <gsi/libsys/config.h>

#include <gsi/libsys/types.h>
#include <gsi/libsys/debug.h>
#include <gsi/libsys/error.h>
#include <gsi/libsys/assert.h>
#include <gsi/libsys/endian.h>
#include <gsi/libsys/log.h>
#include <gsi/libsys/test.h>
#include <gsi/libsys/pool.h>

extern void gsi_libsys_exit(void);
extern int gsi_exit_status;

#define GSI_HOSTNAME_MAX_LEN	32

extern const char *gsi_progname;
extern uint gsi_progpid;
extern char gsi_hostname[];

#include <gsi/libsys/atomic.h>
#include <gsi/libsys/bits.h>
#include <gsi/libsys/debug_buffer.h>
#include <gsi/libsys/mem.h>
#include <gsi/libsys/hash.h>
#include <gsi/libsys/list.h>
#include <gsi/libsys/buf.h>
#include <gsi/libsys/getopt.h>
#include <gsi/libsys/rand.h>
#include <gsi/libsys/thread.h>
#include <gsi/libsys/io.h>
#include <gsi/libsys/perf.h>

extern gsi_status_t gsi_libsys_init(const char *argv0, bool log_to_screen);

#include <gsi/libsys/csv.h>
#include <gsi/libsys/histogram.h>
#include <gsi/libsys/float.h>
#include <gsi/libsys/dl.h>

#endif /* GSI_LIBSYS_X86_64_H */
