/*
 * Copyright (C) 2016, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */
#ifndef GSI_HOST_VTABLE_H
#define GSI_HOST_VTABLE_H

#include <stdarg.h>
#include <stddef.h>

#include <gsi/libsys/log.h>

#ifndef __SSIZE_T_TYPE
typedef long ssize_t;
#endif

/* In SW simulation, explicitly steal io & traps from the host
 * environment */
struct gsi_host_vtable {
	int (*vprintf)(const char *format, va_list ap);
	int (*vsnprintf)(char *str, size_t size, const char *format, va_list ap);
	int (*mprotect)(void *addr, size_t len, int prot);
	void __attribute__((noreturn))(*exit)(int status);
	void __attribute__((noreturn))(*abort)(void);
	gsi_log_writer_t *log_write;
} __attribute__((aligned(8)));

#endif /* GSI_HOST_VTABLE_H */
