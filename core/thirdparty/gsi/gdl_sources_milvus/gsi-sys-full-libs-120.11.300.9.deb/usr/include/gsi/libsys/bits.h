/*
 * Copyright (C) 2016, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */
#ifndef GSI_BITS_H
#define GSI_BITS_H

#include <gsi/libsys/config.h>

#ifdef _BUILD_OS_GNU_LINUX
//#include <asm/bitsperlong.h>
#endif

#ifdef GSI_LIBSYS_NOSTDLIB

#include <gsi/libsys/libc.h>

#else

#include <string.h>

#endif

#include "types.h"
#include "assert.h"
#include <gsi/libsys/atomic.h>

#if defined(GSI_LIBSYS_AARCH64) || defined(GSI_LIBSYS_X86_64) || defined(GSI_LIBSYS_X86_32)
#include "mem.h"
#endif

typedef gsi_atomic_uint64_t gsi_bits_t;
#define GSI_BITS_PER_WORD	((int)(sizeof(gsi_bits_t) * GSI_BITS_PER_BYTE))

#define GSI_BITS_DECLARE(_name_, _nbits_) \
	gsi_bits_t _name_[_DIV_ROUND_UP_NUM(_nbits_, GSI_BITS_PER_WORD)]

#define GSI_BITS_DECLARE2(_name_, _nrows_, _ncols_) \
	gsi_bits_t _name_[_nrows_][_DIV_ROUND_UP_NUM(_ncols_, GSI_BITS_PER_WORD)]

#define GSI_BITS_DECLARE3(_name_, _nbanks_, _nrows_, _ncols_) \
	gsi_bits_t _name_[_nbanks_][_nrows_][_DIV_ROUND_UP_NUM(_ncols_, GSI_BITS_PER_WORD)]

#define GSI_BITS_DECLARE4(_name_, _nbanks_, _nsides_, _nrows_, _ncols_) \
	gsi_bits_t _name_[_nbanks_][_nsides_][_nrows_][_DIV_ROUND_UP_NUM(_ncols_, GSI_BITS_PER_WORD)]

static inline size_t gsi_bits_size(size_t nbits)
{
	return _DIV_ROUND_UP_NUM(nbits, GSI_BITS_PER_WORD) * sizeof(gsi_bits_t);
}

#if defined(GSI_LIBSYS_AARCH64) || defined(GSI_LIBSYS_X86_64) || defined(GSI_LIBSYS_X86_32)
static inline gsi_bits_t *gsi_bits_aligned_alloc(size_t alignment, size_t nbits)
{
	return (gsi_bits_t *)gsi_aligned_zalloc(alignment, gsi_bits_size(nbits));
}

static inline gsi_bits_t *gsi_bits_alloc(size_t nbits)
{
	return (gsi_bits_t *)gsi_bits_aligned_alloc(sizeof(gsi_bits_t), nbits);
}

static inline void gsi_bits_free(gsi_bits_t *bf)
{
	gsi_free_any(bf);
}

gsi_bits_t **gsi_bits_aligned_alloc2(size_t alignment, gsi_bits_t **bp, uint nrows, size_t nbits);

static inline gsi_bits_t **gsi_bits_alloc2(gsi_bits_t **bp, uint nrows, size_t nbits)
{
	return gsi_bits_aligned_alloc2(sizeof(gsi_bits_t), bp, nrows, nbits);
}

static inline void gsi_bits_free2(gsi_bits_t **a)
{
	if (!GSI_IS_ERR_PTR_OR_NULL(a)) {
		gsi_free(a[0]);
		gsi_free(a);
	}
}
#endif

static inline gsi_atomic_int64_t gsi_bits_get_val(const gsi_bits_t *bf)
{
	return *bf;
}

static inline gsi_atomic_int64_t gsi_bits_atomic_get_val(const gsi_bits_t *bf)
{
	return gsi_atomic64_get((const gsi_atomic64_t *)bf);
}

static inline bool gsi_bits_is_set_mask(const gsi_bits_t *bf, gsi_atomic_int64_t bit_mask)
{
	return bf[0] & bit_mask;
}

static inline bool gsi_bits_is_set(const gsi_bits_t *bf, size_t nbit)
{
	size_t word_offs = nbit / GSI_BITS_PER_WORD;
	int bit_offs = (int)(nbit & (GSI_BITS_PER_WORD - 1));
	gsi_atomic_int64_t bit_mask = 1ULL << bit_offs;
	return gsi_bits_is_set_mask(&bf[word_offs], bit_mask);
}

#define gsi_bits_is_set2(bf, nrow, nbit) \
	gsi_bits_is_set(&(bf)[nrow][0], nbit)

#define gsi_bits_is_set3(bf, nbank, nrow, nbit) \
	gsi_bits_is_set(&(bf)[nbank][nrow][0], nbit)

#define gsi_bits_is_set4(bf, nbank, nside, nrow, nbit) \
	gsi_bits_is_set(&(bf)[nbank][nside][nrow][0], nbit)

static inline bool gsi_bits_atomic_is_set_mask(const gsi_bits_t *bf, gsi_atomic_int64_t bit_mask)
{
	return gsi_atomic64_get((const gsi_atomic64_t *)bf) & bit_mask;
}

static inline bool gsi_bits_atomic_is_set(const gsi_bits_t *bf, size_t nbit)
{
	size_t word_offs = nbit / GSI_BITS_PER_WORD;
	int bit_offs = (int)(nbit & (GSI_BITS_PER_WORD - 1));
	gsi_atomic_int64_t bit_mask = 1ULL << bit_offs;
	return gsi_bits_atomic_is_set_mask(&bf[word_offs], bit_mask);
}

#define gsi_bits_atomic_is_set2(bf, nrow, nbit) \
	gsi_bits_atomic_is_set(&(bf)[nrow][0], nbit)

#define gsi_bits_atomic_is_set3(bf, nbank, nrow, nbit) \
	gsi_bits_atomic_is_set(&(bf)[nbank][nrow][0], nbit)

#define gsi_bits_atomic_is_set4(bf, nbank, nside, nrow, nbit) \
	gsi_bits_atomic_is_set(&(bf)[nbank][nside][nrow][0], nbit)

static inline bool gsi_bits_is_clear(const gsi_bits_t *bf, size_t nbit)
{
	return !gsi_bits_is_set(bf, nbit);
}

#define gsi_bits_is_clear2(bf, nrow, nbit) \
	gsi_bits_is_clear(&(bf)[nrow][0], nbit)

#define gsi_bits_is_clear3(bf, nbank, nrow, nbit) \
	gsi_bits_is_clear(&(bf)[nbank][nrow][0], nbit)

#define gsi_bits_is_clear4(bf, nbank, nside, nrow, nbit) \
	gsi_bits_is_clear(&(bf)[nbank][nside][nrow][0], nbit)

static inline bool gsi_bits_atomic_is_clear(const gsi_bits_t *bf, size_t nbit)
{
	return !gsi_bits_atomic_is_set(bf, nbit);
}

#define gsi_bits_atomic_is_clear2(bf, nrow, nbit) \
	gsi_bits_atomic_is_clear(&(bf)[nrow][0], nbit)

#define gsi_bits_atomic_is_clear3(bf, nbank, nrow, nbit) \
	gsi_bits_atomic_is_clear(&(bf)[nbank][nrow][0], nbit)

#define gsi_bits_atomic_is_clear4(bf, nbank, nside, nrow, nbit) \
	gsi_bits_atomic_is_clear(&(bf)[nbank][nside][nrow][0], nbit)

static inline void gsi_bits_set_val(gsi_bits_t *bf, gsi_atomic_int64_t val)
{
	*bf = val;
}

static inline void gsi_bits_atomic_set_val(gsi_bits_t *bf, gsi_atomic_int64_t val)
{
	gsi_atomic64_set((gsi_atomic64_t *)bf, val);
}

/* Set a bit and return the previous value */
static inline bool gsi_bits_set(gsi_bits_t *bf, size_t nbit)
{
	size_t word_offs = nbit / GSI_BITS_PER_WORD;
	int bit_offs = (int)(nbit & (GSI_BITS_PER_WORD - 1));
	gsi_atomic_int64_t bit_mask = 1ULL << bit_offs;
	gsi_atomic_int64_t prev = bf[word_offs];
	bf[word_offs] |= bit_mask;
	return prev & bit_mask;
}

#define gsi_bits_set2(bf, nrow, nbit) \
	gsi_bits_set(&(bf)[nrow][0], nbit)

#define gsi_bits_set3(bf, nbank, nrow, nbit) \
	gsi_bits_set(&(bf)[nbank][nrow][0], nbit)

#define gsi_bits_set4(bf, nbank, nside, nrow, nbit) \
	gsi_bits_set(&(bf)[nbank][nside][nrow][0], nbit)

static inline bool gsi_bits_atomic_set(gsi_bits_t *bf, size_t nbit)
{
	size_t word_offs = nbit / GSI_BITS_PER_WORD;
	int bit_offs = (int)(nbit & (GSI_BITS_PER_WORD - 1));
	gsi_atomic_int64_t bit_mask = 1ULL << bit_offs;
	gsi_atomic_int64_t prev = gsi_atomic64_fetch_and_or((gsi_atomic64_t *)&bf[word_offs], bit_mask);
	return prev & bit_mask;
}

#define gsi_bits_atomic_set2(bf, nrow, nbit) \
	gsi_bits_atomic_set(&(bf)[nrow][0], nbit)

#define gsi_bits_atomic_set3(bf, nbank, nrow, nbit) \
	gsi_bits_atomic_set(&(bf)[nbank][nrow][0], nbit)

#define gsi_bits_atomic_set4(bf, nbank, nside, nrow, nbit) \
	gsi_bits_atomic_set(&(bf)[nbank][nside][nrow][0], nbit)

static inline void gsi_bits_set_bits(gsi_bits_t *bf, size_t nbits)
{
	size_t word_offs = nbits / GSI_BITS_PER_WORD;
	int bit_offs = (int)(nbits & (GSI_BITS_PER_WORD - 1));

	if (word_offs) {
		memset(bf, ~0, word_offs * sizeof(*bf));
		bf += word_offs;
	}

	if (bit_offs) {
		gsi_atomic_int64_t bit_mask = (1ULL << bit_offs) - 1;
		*bf |= bit_mask;
	}
}

static inline void gsi_bits_atomic_set_bits(gsi_bits_t *bf, size_t nbits)
{
	size_t word_offs = nbits / GSI_BITS_PER_WORD;
	int bit_offs = (int)(nbits & (GSI_BITS_PER_WORD - 1));

	if (word_offs) {
		memset(bf, ~0, word_offs * sizeof(*bf));
		bf += word_offs;
	}

	if (bit_offs) {
		gsi_atomic_int64_t bit_mask = (1ULL << bit_offs) - 1;
		gsi_atomic64_or((gsi_atomic64_t *)bf, bit_mask);
	}
}

/* Clear a bit and return the previous value */
static inline bool gsi_bits_clear(gsi_bits_t *bf, size_t nbit)
{
	size_t word_offs = nbit / GSI_BITS_PER_WORD;
	int bit_offs = (int)(nbit & (GSI_BITS_PER_WORD - 1));
	gsi_atomic_int64_t bit_mask = 1ULL << bit_offs;
	gsi_atomic_int64_t prev = bf[word_offs];
	bf[word_offs] &= ~bit_mask;
	return prev & bit_mask;
}

#define gsi_bits_clear2(bf, nrow, nbit) \
	gsi_bits_clear(&(bf)[nrow][0], nbit)

#define gsi_bits_clear3(bf, nbank, nrow, nbit) \
	gsi_bits_clear(&(bf)[nbank][nrow][0], nbit)

#define gsi_bits_clear4(bf, nbank, nside, nrow, nbit) \
	gsi_bits_clear(&(bf)[nbank][nside][nrow][0], nbit)

static inline bool gsi_bits_atomic_clear(gsi_bits_t *bf, size_t nbit)
{
	size_t word_offs = nbit / GSI_BITS_PER_WORD;
	int bit_offs = (int)(nbit & (GSI_BITS_PER_WORD - 1));
	gsi_atomic_int64_t bit_mask = 1ULL << bit_offs;
	gsi_atomic_int64_t prev = gsi_atomic64_fetch_and_and((gsi_atomic64_t *)&bf[word_offs], ~bit_mask);
	return prev & bit_mask;
}

#define gsi_bits_atomic_clear2(bf, nrow, nbit) \
	gsi_bits_atomic_clear(&(bf)[nrow][0], nbit)

#define gsi_bits_atomic_clear3(bf, nbank, nrow, nbit) \
	gsi_bits_atomic_clear(&(bf)[nbank][nrow][0], nbit)

#define gsi_bits_atomic_clear4(bf, nbank, nside, nrow, nbit) \
	gsi_bits_atomic_clear(&(bf)[nbank][nside][nrow][0], nbit)

static inline void gsi_bits_clear_bits(gsi_bits_t *bf, size_t nbits)
{
	size_t word_offs = nbits / GSI_BITS_PER_WORD;
	int bit_offs = (int)(nbits & (GSI_BITS_PER_WORD - 1));

	if (word_offs) {
		memset(bf, 0, word_offs * sizeof(*bf));
		bf += word_offs;
	}

	if (bit_offs) {
		gsi_atomic_int64_t bit_mask = (1ULL << bit_offs) - 1;
		*bf &= ~bit_mask;
	}
}

static inline void gsi_bits_atomic_clear_bits(gsi_bits_t *bf, size_t nbits)
{
	size_t word_offs = nbits / GSI_BITS_PER_WORD;
	int bit_offs = (int)(nbits & (GSI_BITS_PER_WORD - 1));

	if (word_offs) {
		memset(bf, 0, word_offs * sizeof(*bf));
		bf += word_offs;
	}

	if (bit_offs) {
		gsi_atomic_int64_t bit_mask = (1ULL << bit_offs) - 1;
		gsi_atomic64_and((gsi_atomic64_t *)bf, ~bit_mask);
	}
}

/* Flip a bit and return the previous value */
static inline bool gsi_bits_flip(gsi_bits_t *bf, size_t nbit)
{
	size_t word_offs = nbit / GSI_BITS_PER_WORD;
	int bit_offs = (int)(nbit & (GSI_BITS_PER_WORD - 1));
	gsi_atomic_int64_t bit_mask = 1ULL << bit_offs;
	gsi_atomic_int64_t prev = bf[word_offs];
	bf[word_offs] ^= bit_mask;
	return prev & bit_mask;
}

#define gsi_bits_flip2(bf, nrow, nbit) \
	gsi_bits_flip(&(bf)[nrow][0], nbit)

#define gsi_bits_flip3(bf, nbank, nrow, nbit) \
	gsi_bits_flip(&(bf)[nbank][nrow][0], nbit)

#define gsi_bits_flip4(bf, nbank, nside, nrow, nbit) \
	gsi_bits_flip(&(bf)[nbank][nside][nrow][0], nbit)

static inline bool gsi_bits_atomic_flip(gsi_bits_t *bf, size_t nbit)
{
	size_t word_offs = nbit / GSI_BITS_PER_WORD;
	int bit_offs = (int)(nbit & (GSI_BITS_PER_WORD - 1));
	gsi_atomic_int64_t bit_mask = 1ULL << bit_offs;
	gsi_atomic_int64_t prev = gsi_atomic64_fetch_and_xor((gsi_atomic64_t *)&bf[word_offs], bit_mask);
	return prev & bit_mask;
}

#define gsi_bits_atomic_flip2(bf, nrow, nbit) \
	gsi_bits_atomic_flip(&(bf)[nrow][0], nbit)

#define gsi_bits_atomic_flip3(bf, nbank, nrow, nbit) \
	gsi_bits_atomic_flip(&(bf)[nbank][nrow][0], nbit)

#define gsi_bits_atomic_flip4(bf, nbank, nside, nrow, nbit) \
	gsi_bits_atomic_flip(&(bf)[nbank][nside][nrow][0], nbit)

/* Set a bit and return the previous value */
static inline bool gsi_bits_assign(gsi_bits_t *bf, size_t nbit, bool val)
{
	size_t word_offs = nbit / GSI_BITS_PER_WORD;
	int bit_offs = (int)(nbit & (GSI_BITS_PER_WORD - 1));
	gsi_atomic_int64_t bit_mask = 1ULL << bit_offs;
	gsi_atomic_int64_t prev = bf[word_offs];
	bf[word_offs] = val ? (prev | bit_mask) : (prev & ~bit_mask);
	return prev & bit_mask;
}

#define gsi_bits_assign2(bf, nrow, nbit, val) \
	gsi_bits_assign(&(bf)[nrow][0], nbit, val)

#define gsi_bits_assign3(bf, nbank, nrow, nbit, val) \
	gsi_bits_assign(&(bf)[nbank][nrow][0], nbit, val)

#define gsi_bits_assign4(bf, nbank, nside, nrow, nbit, val) \
	gsi_bits_assign(&(bf)[nbank][nside][nrow][0], nbit, val)

static inline void gsi_bits_assign_bits1(gsi_bits_t *bf, size_t nbit, int nbits, gsi_atomic_int64_t val)
{
	gsi_atomic_int64_t bit_mask;

	GSI_ASSERT(nbit + nbits <= GSI_BITS_PER_WORD);
	bit_mask = (~0ULL >> (GSI_BITS_PER_WORD - nbits)) << nbit;
	val = (val << nbit) & bit_mask;
	*bf = (*bf & ~bit_mask) | val;
}

static inline void gsi_bits_assign_bits(gsi_bits_t *bf, size_t nbit, int nbits, gsi_atomic_int64_t val)
{
	if (nbit >= GSI_BITS_PER_WORD) {
		bf += nbit / GSI_BITS_PER_WORD;
		nbit %= GSI_BITS_PER_WORD;
	}
	if (nbit + nbits > GSI_BITS_PER_WORD) {
		int nbits_ls = GSI_BITS_PER_WORD - (int)nbit;
		gsi_bits_assign_bits1(bf, nbit, nbits_ls, val);
		nbit = 0;
		nbits -= nbits_ls;
		val >>= nbits_ls;
		bf++;
	}
	gsi_bits_assign_bits1(bf, nbit, nbits, val);
}

static inline bool gsi_bits_atomic_assign(gsi_bits_t *bf, size_t nbit, bool val)
{
	size_t word_offs = nbit / GSI_BITS_PER_WORD;
	int bit_offs = (int)(nbit & (GSI_BITS_PER_WORD - 1));
	gsi_atomic_int64_t bit_mask = 1ULL << bit_offs;
	gsi_atomic_int64_t prev = val ?
	                          gsi_atomic64_fetch_and_or((gsi_atomic64_t *)&bf[word_offs], bit_mask) :
	                          gsi_atomic64_fetch_and_and((gsi_atomic64_t *)&bf[word_offs], ~bit_mask);
	return prev & bit_mask;
}

#define gsi_bits_atomic_assign2(bf, nrow, nbit, val) \
	gsi_bits_atomic_assign(&(bf)[nrow][0], nbit, val)

#define gsi_bits_atomic_assign3(bf, nbank, nrow, nbit, val) \
	gsi_bits_atomic_assign(&(bf)[nbank][nrow][0], nbit, val)

#define gsi_bits_atomic_assign4(bf, nbank, nside, nrow, nbit, val) \
	gsi_bits_atomic_assign(&(bf)[nbank][nside][nrow][0], nbit, val)

static inline void gsi_bits_atomic_assign_bits1(gsi_bits_t *bf, size_t nbit, int nbits, gsi_atomic_int64_t val)
{
	gsi_atomic_int64_t bit_mask;
	gsi_atomic_int64_t oldval, newval;

	GSI_ASSERT(nbit + nbits <= GSI_BITS_PER_WORD);
	bit_mask = (~0ULL >> (GSI_BITS_PER_WORD - nbits)) << nbit;
	val = (val << nbit) & bit_mask;
	do {
		oldval = gsi_bits_get_val(bf);
		newval = (oldval & ~bit_mask) | val;
	} while (gsi_atomic64_cmp_and_swap((gsi_atomic64_t *)bf, oldval, newval) != oldval);
}

static inline void gsi_bits_atomic_assign_bits(gsi_bits_t *bf, size_t nbit, int nbits, gsi_atomic_int64_t val)
{
	if (nbit >= GSI_BITS_PER_WORD) {
		bf += nbit / GSI_BITS_PER_WORD;
		nbit %= GSI_BITS_PER_WORD;
	}
	if (nbit + nbits > GSI_BITS_PER_WORD) {
		int nbits_ls = GSI_BITS_PER_WORD - (int)nbit;
		gsi_bits_atomic_assign_bits1(bf, nbit, nbits_ls, val);
		nbit = 0;
		nbits -= nbits_ls;
		val >>= nbits_ls;
		bf++;
	}
	gsi_bits_atomic_assign_bits1(bf, nbit, nbits, val);
}

static inline gsi_atomic_int64_t gsi_bits_get_bits1(const gsi_bits_t *bf, size_t nbit, int nbits)
{
	gsi_atomic_int64_t bit_mask;

	GSI_ASSERT(nbit + nbits <= GSI_BITS_PER_WORD);
	if (nbits == GSI_BITS_PER_WORD)
		return *bf;
	bit_mask = ((1ULL << nbits) - 1) << nbit;
	return (*bf & bit_mask) >> nbit;
}

static inline gsi_atomic_int64_t gsi_bits_get_bits(const gsi_bits_t *bf, size_t nbit, int nbits)
{
	gsi_atomic_int64_t bit_mask;
	gsi_atomic_int64_t ret;

	bf += nbit / GSI_BITS_PER_WORD;
	nbit %= GSI_BITS_PER_WORD;

	if (nbit + nbits <= GSI_BITS_PER_WORD)
		return gsi_bits_get_bits1(bf, nbit, nbits);

	GSI_ASSERT(nbits <= GSI_BITS_PER_WORD);
	if (nbits == GSI_BITS_PER_WORD)
		bit_mask = ~0ULL << nbit;
	else
		bit_mask = ((1ULL << nbits) - 1) << nbit;
	ret = (*bf++ & bit_mask) >> nbit;
	nbit = GSI_BITS_PER_WORD - nbit;	// remainder
	nbits -= (int)nbit;
	bit_mask = (1ULL << nbits) - 1;
	ret |= (*bf & bit_mask) << nbit;
	return ret;
}

static inline gsi_atomic_int64_t gsi_bits_atomic_get_bits1(const gsi_bits_t *bf, size_t nbit, int nbits)
{
	gsi_atomic_int64_t bit_mask;

	GSI_ASSERT(nbit + nbits <= GSI_BITS_PER_WORD);
	if (nbits == GSI_BITS_PER_WORD)
		return gsi_atomic64_get((gsi_atomic64_t *)bf);
	bit_mask = ((1ULL << nbits) - 1) << nbit;
	return (gsi_atomic64_get((gsi_atomic64_t *)bf) & bit_mask) >> nbit;
}

/*
 * Note: atomicity of return value ensured only when accessing a single word, i.e.
 * nbit + nbits <= GSI_BITS_PER_WORD
 */
static inline gsi_atomic_int64_t gsi_bits_atomic_get_bits(const gsi_bits_t *bf, size_t nbit, int nbits)
{
	gsi_atomic_int64_t bit_mask;
	gsi_atomic_int64_t ret;

	bf += nbit / GSI_BITS_PER_WORD;
	nbit %= GSI_BITS_PER_WORD;

	if (nbit + nbits <= GSI_BITS_PER_WORD)
		return gsi_bits_atomic_get_bits1(bf, nbit, nbits);

	GSI_ASSERT(nbits <= GSI_BITS_PER_WORD);
	if (nbits == GSI_BITS_PER_WORD)
		bit_mask = ~0ULL << nbit;
	else
		bit_mask = ((1ULL << nbits) - 1) << nbit;
	ret = (gsi_atomic64_get((gsi_atomic64_t *)bf++) & bit_mask) >> nbit;
	nbit = GSI_BITS_PER_WORD - nbit;	// remainder
	nbits -= (int)nbit;
	bit_mask = (1ULL << nbits) - 1;
	ret |= (gsi_atomic64_get((gsi_atomic64_t *)bf) & bit_mask) << nbit;
	return ret;
}

static inline void gsi_bits_copy_words(gsi_bits_t *dest_bf, const gsi_bits_t *src_bf, size_t nwords)
{
	memcpy(dest_bf, src_bf, nwords * sizeof(*dest_bf));
}

static inline void gsi_bits_atomic_copy_words(gsi_bits_t *dest_bf, const gsi_bits_t *src_bf, size_t nwords)
{
	size_t i;

	for (i = 0; i < nwords; i++)
		gsi_atomic64_set((gsi_atomic64_t *)dest_bf++, gsi_atomic64_get((gsi_atomic64_t *)src_bf++));
}

static inline void gsi_bits_copy_bits_mask(gsi_bits_t *dest_bf, const gsi_bits_t *src_bf, gsi_atomic_int64_t bit_mask)
{
	*dest_bf = (*dest_bf & ~bit_mask) | (*src_bf & bit_mask);
}

static inline void gsi_bits_copy_bits(gsi_bits_t *dest_bf, const gsi_bits_t *src_bf, size_t nbits)
{
	size_t nwords = nbits / GSI_BITS_PER_WORD;
	nbits %= GSI_BITS_PER_WORD;

	gsi_bits_copy_words(dest_bf, src_bf, nwords);
	dest_bf += nwords;
	src_bf += nwords;

	if (nbits)
		gsi_bits_copy_bits_mask(dest_bf, src_bf, ~0ULL >> (GSI_BITS_PER_WORD - nbits));
}

static inline void gsi_bits_atomic_copy_bits_mask(gsi_bits_t *dest_bf, const gsi_bits_t *src_bf, gsi_atomic_int64_t bit_mask)
{
	gsi_atomic_int64_t oldval, newval;
	do {
		oldval = gsi_bits_get_val(dest_bf);
		newval = (oldval & ~bit_mask) | (gsi_bits_get_val(src_bf) & bit_mask);
	} while (gsi_atomic64_cmp_and_swap((gsi_atomic64_t *)dest_bf, oldval, newval) != oldval);
}

static inline void gsi_bits_atomic_copy_bits(gsi_bits_t *dest_bf, const gsi_bits_t *src_bf, size_t nbits)
{
	size_t nwords = nbits / GSI_BITS_PER_WORD;
	nbits %= GSI_BITS_PER_WORD;

	gsi_bits_atomic_copy_words(dest_bf, src_bf, nwords);
	dest_bf += nwords;
	src_bf += nwords;

	if (nbits)
		gsi_bits_atomic_copy_bits_mask(dest_bf, src_bf, ~0ULL >> (GSI_BITS_PER_WORD - nbits));
}

extern void gsi_bits_copy_bits_ext(gsi_bits_t *dst_bf, const gsi_bits_t *src_bf, size_t dst_bit, size_t src_bit, int nbits);

static inline void gsi_bits_shr_bits(gsi_bits_t *bf, size_t nbits, int nshift)
{
	gsi_bits_t carry, next;
	gsi_bits_t bit_mask, shift_mask;
	size_t nwords = nbits / GSI_BITS_PER_WORD;
	nbits %= GSI_BITS_PER_WORD;

	GSI_ASSERT(nshift > 0 && nshift < GSI_BITS_PER_WORD);	// for now

	shift_mask = (1ULL << nshift) - 1;
	bf += nwords;
	if (nbits) {
		bit_mask = (1ULL << nbits) - 1;
		carry = *bf & bit_mask & shift_mask;
		next = (*bf & bit_mask) >> nshift;
		*bf = (*bf & ~bit_mask) | next;
	} else
		carry = 0;

	for (bf--; nwords; bf--, nwords--) {
		next = *bf & shift_mask;
		*bf = (*bf >> nshift) | (carry << (GSI_BITS_PER_WORD - nshift));
		carry = next;
	}
}

static inline void gsi_bits_shl_bits(gsi_bits_t *bf, size_t nbits, int nshift)
{
	gsi_bits_t carry, next;
	gsi_bits_t bit_mask;
	size_t nwords = nbits / GSI_BITS_PER_WORD;
	nbits %= GSI_BITS_PER_WORD;

	GSI_ASSERT(nshift > 0 && nshift < GSI_BITS_PER_WORD);	// for now

	for (carry = 0; nwords; bf++, nwords--) {
		next = (*bf >> (GSI_BITS_PER_WORD - nshift));
		*bf = (*bf << nshift) | carry;
		carry = next;
	}

	if (nbits) {
		bit_mask = (1ULL << nbits) - 1;
		next = (*bf << nshift) | carry;
		*bf = (*bf & ~bit_mask) | (next & bit_mask);
	}
}

/*
 * Return the position of the first bit set in bf, starting from nbit to nbit+nbits,
 * or -1 if none are set.
 * The least-significant bit is position 0
 */
static inline ssize_t gsi_bits_ffs(const gsi_bits_t *bf, size_t nbit, int nbits)
{
	return (ssize_t)nbit + ffsll(gsi_bits_get_bits(bf, nbit, nbits)) - 1;
}

static inline ssize_t gsi_bits_atomic_ffs(const gsi_bits_t *bf, size_t nbit, int nbits)
{
	return (ssize_t)nbit + ffsll(gsi_bits_atomic_get_bits(bf, nbit, nbits)) - 1;
}

/*
 * Return the position of the first bit clear in bf, starting from nbit to nbit+nbits,
 * or -1 if none are set.
 * The least-significant bit is position 0
 */
static inline ssize_t gsi_bits_ffc(const gsi_bits_t *bf, size_t nbit, int nbits)
{
	return (ssize_t)nbit + ffsll(~gsi_bits_get_bits(bf, nbit, nbits)) - 1;
}

static inline ssize_t gsi_bits_atomic_ffc(const gsi_bits_t *bf, size_t nbit, int nbits)
{
	return (ssize_t)nbit + ffsll(~gsi_bits_atomic_get_bits(bf, nbit, nbits)) - 1;
}

/*
 * Return the number of set bits in bf out of nbits,
 * or 0 if none are set.
 */
extern int gsi_bits_count_set(const gsi_bits_t *bf, int nbits);

/*
 * Return the number of clear bits in bf out of nbits,
 * or 0 if none are clear.
 */
static inline int gsi_bits_count_clear(const gsi_bits_t *bf, int nbits)
{
	return nbits - gsi_bits_count_set(bf, nbits);
}

#define DEFINE_GSI_BITS_OP(_opname_, _op_) \
static inline void gsi_bits_ ## _opname_ ## _val(gsi_bits_t *res, gsi_atomic_int64_t val) \
{ \
	*res = _op_(*res, val); \
} \
 \
static inline void gsi_bits_ ## _opname_(gsi_bits_t *res, const gsi_bits_t *src, int nbits) \
{ \
	int num_words = nbits / GSI_BITS_PER_WORD; \
	int remainder = nbits & (GSI_BITS_PER_WORD - 1); \
	int i; \
 \
	for (i = 0; i < num_words; i++) \
		res[i] = _op_(res[i], src[i]); \
 \
	if (remainder) { \
		gsi_atomic_int64_t bit_mask = (1ULL << remainder) - 1; \
		gsi_atomic_int64_t cur = res[i]; \
		res[i] = (cur & ~bit_mask) | (_op_(cur, src[i]) & bit_mask); \
	} \
}

#define DEFINE_GSI_BITS_ATOMIC_OP(_opname_, _op_) \
static inline void gsi_bits_atomic_ ## _opname_ ## _val(gsi_bits_t *res, gsi_atomic_int64_t val) \
{ \
	gsi_atomic64_ ## _opname_((gsi_atomic64_t *)res, val); \
} \
 \
static inline void gsi_bits_atomic_ ## _opname_(gsi_bits_t *res, const gsi_bits_t *src, int nbits) \
{ \
	int num_words = nbits / GSI_BITS_PER_WORD; \
	int remainder = nbits & (GSI_BITS_PER_WORD - 1); \
	int i; \
 \
	for (i = 0; i < num_words; i++) \
		gsi_atomic64_ ## _opname_((gsi_atomic64_t *)res++, gsi_atomic64_get((gsi_atomic64_t *)src++)); \
 \
	if (remainder) { \
		gsi_atomic_int64_t bit_mask = (1ULL << remainder) - 1; \
		gsi_atomic64_ ## _opname_((gsi_atomic64_t *)res, gsi_atomic64_get((gsi_atomic64_t *)src) & bit_mask); \
	} \
}

#define _gsi_bit_op_or(a, b) ((a) | (b))
DEFINE_GSI_BITS_OP( or, _gsi_bit_op_or)
DEFINE_GSI_BITS_ATOMIC_OP( or, gsi_atomic64_or)

#define _gsi_bit_op_and(a, b) ((a) & (b))
DEFINE_GSI_BITS_OP( and, _gsi_bit_op_and)
DEFINE_GSI_BITS_ATOMIC_OP( and, gsi_atomic64_and)

#define _gsi_bit_op_xor(a, b) ((a) ^ (b))
DEFINE_GSI_BITS_OP(xor, _gsi_bit_op_xor)
DEFINE_GSI_BITS_ATOMIC_OP(xor, gsi_atomic64_xor)

/*
 * Helpers to make printing of `gsi_bits_t' values less messy (just use %llx)
 */
static inline unsigned long long PBITS(gsi_bits_t x)
{
	return (unsigned long long)x;
}

#endif /* GSI_BITS_H */
