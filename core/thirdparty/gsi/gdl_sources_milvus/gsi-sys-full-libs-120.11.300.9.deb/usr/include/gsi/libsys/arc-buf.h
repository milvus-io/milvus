/*
 * Copyright (C) 2019, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */

#ifndef ARC_BUF_H_
#define ARC_BUF_H_
#if defined(GSI_LIBSYS_ARCHS36)

#define GARC_CACHE_LINE_SIZE 32
#define DC_FLDL		0x004c /* Flush data line */
#define DC_CTRL		0x0048 /* Control register */
#define DC_IVDL              0x004a
#define DC_CTRL_FS_MASK (1 << 8)
#define DC_CTRL_SB_MASK (1 << 2)
#define buf_garc_common_aux_wr(aux, val)        _sr(val, aux)
#define buf_garc_common_aux_rd(aux)              _lr(aux)

static inline u32 buf_garc_common_cpu_lock_save(void)
{
	return _clri();
}

static inline void buf_garc_common_cpu_unlock_restore(const u32 status)
{
	_seti(status);
}

static inline int buf_garc_cache_dcache_invalidate_mlines(u32 start_addr, u32 size)
{
	u32 end_addr;
	u32 status;

	end_addr = start_addr + size - 1;
	start_addr &= (u32)(~(u32)(GARC_CACHE_LINE_SIZE - 1));

	status = buf_garc_common_cpu_lock_save();
	do {
		buf_garc_common_aux_wr(DC_CTRL, 0);
		buf_garc_common_aux_wr(DC_IVDL, start_addr);
		__asm__ volatile("nop_s");
		__asm__ volatile("nop_s");
		__asm__ volatile("nop_s");
		/* wait for invalidate completion */
//		while (!(_garc_common_aux_rd(DC_CTRL) & DC_CTRL_SB_MASK));
		start_addr += GARC_CACHE_LINE_SIZE;
	} while (start_addr <= end_addr);
	buf_garc_common_cpu_unlock_restore(status);

	return 0;
}

static inline int buf_garc_cache_dcache_flush_mlines(u32 start_addr, u32 size)
{
	u32 end_addr;
	u32 status;

	end_addr = start_addr + size - 1;
	start_addr &= (u32)(~(u32)(GARC_CACHE_LINE_SIZE - 1));

	status = buf_garc_common_cpu_lock_save();
	do {
		buf_garc_common_aux_wr(DC_FLDL, start_addr);
		__asm__ volatile("nop_s");
		__asm__ volatile("nop_s");
		__asm__ volatile("nop_s");
		/* wait for flush completion */
// 		while (_garc_common_aux_rd(DC_CTRL) & DC_CTRL_SB_MASK);
		start_addr += GARC_CACHE_LINE_SIZE;
	} while (start_addr <= end_addr);
	buf_garc_common_cpu_unlock_restore(status);

	return 0;
}


static inline void buf_garc_cache_dcache_flush_line(u32 address)
{
	u32 status;

	status = buf_garc_common_cpu_lock_save();
	buf_garc_common_aux_wr(DC_FLDL, address);
	/* wait for flush completion */
	while (!(buf_garc_common_aux_rd(DC_CTRL) & DC_CTRL_SB_MASK));
	buf_garc_common_cpu_unlock_restore(status);
}



#endif /*GSI_LIBSYS_ARCHS36*/
#endif /* ARC_BUF_H_ */
