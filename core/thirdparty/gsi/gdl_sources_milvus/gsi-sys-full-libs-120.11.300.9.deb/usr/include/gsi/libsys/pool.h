/*
 * Copyright (C) 2017, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */

#ifndef GSI_POOL_H
#define GSI_POOL_H

struct gsi_pool;

struct gsi_pool *gsi_pool_create(void *region, size_t region_size);
void *gsi_pool_alloc(struct gsi_pool *pool, size_t bytes);
void gsi_pool_free(struct gsi_pool *pool, void *mem);

void gsi_pool_destroy(struct gsi_pool *av);
void gsi_pool_info(struct gsi_pool *av);

#endif /* GSI_POOL_H */
