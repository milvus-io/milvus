/*
 * GSI Device Library for Host code running User Tasks remotely on GSI's APU System
 *
 * Copyright (C) 2019, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */

#ifndef GSI_SEU_INST_H_
#define GSI_SEU_INST_H_

#include <gsi/apl_defs.h>

enum seu_inst_type {
	SEU_INST_NOOP	= 0,
	SEU_INST_RD	= 1,
	SEU_INST_WR	= 2,
	SEU_INST_R2W1	= 3,
	SEU_INST_RWM	= 4,
	SEU_INST_DBG	= 5,
	SEU_INST_RVD	= 6,
	SEU_INST_GLW	= 7,
};

// *INDENT-OFF*
typedef unsigned int uint;
typedef unsigned int u32;

struct seu_inst_nop {
	uint	fsel : 1;

	uint	unused : 28;

	uint	inst_type : VALU_INST_TYPE_BITS;
} __attribute__ ((packed));

struct seu_inst_rd {
	uint	rownum_reg_2 : VALU_ROWNUM_REGS_BITS;
	uint	rownum_reg_1 : VALU_ROWNUM_REGS_BITS;
	uint	rownum_reg_0 : VALU_ROWNUM_REGS_BITS;

	uint	rdlogic_reg : VALU_RDLOGIC_REGS_BITS;

	uint	winv : 1;
	uint	wmux_ctl : VALU_WMUX_CTL_BITS;

	uint	smap_invert : 1;
	uint	smap_shift : VALU_SMAP_SHIFT_BITS;
	uint	smap_reg : VALU_SMAP_REGS_BITS;

	uint	inst_type : VALU_INST_TYPE_BITS;
} __attribute__ ((packed));

struct seu_inst_wr {
	uint	rownum_reg_2 : VALU_ROWNUM_REGS_BITS;
	uint	rownum_reg_1 : VALU_ROWNUM_REGS_BITS;
	uint	rownum_reg_0 : VALU_ROWNUM_REGS_BITS;

	uint	unused : 3;

	uint	wifval : 1;
	uint	winv : 1;
	uint	wmux_ctl : VALU_WMUX_CTL_BITS;

	uint	smap_invert : 1;
	uint	smap_shift : VALU_SMAP_SHIFT_BITS;
	uint	smap_reg : VALU_SMAP_REGS_BITS;

	uint	inst_type : VALU_INST_TYPE_BITS;
} __attribute__ ((packed));

struct seu_inst_r2w1 {
	uint	rownum_reg_2 : VALU_ROWNUM_REGS_BITS;
	uint	rownum_reg_1 : VALU_ROWNUM_REGS_BITS;
	uint	rownum_reg_0 : VALU_ROWNUM_REGS_BITS;

	uint	rdlogic_reg : VALU_RDLOGIC_REGS_BITS;

	uint	winv : 1;
	uint	wmux_ctl : VALU_WMUX_CTL_BITS;

	uint	smap_invert : 1;
	uint	smap_shift : VALU_SMAP_SHIFT_BITS;
	uint	smap_reg : VALU_SMAP_REGS_BITS;

	uint	inst_type : VALU_INST_TYPE_BITS;
} __attribute__ ((packed));

struct seu_inst_rwm {
	uint	row_mask_invert : 1;
	uint	row_mask_shift : VALU_ROWMASK_SHIFT_BITS;

	uint	ewe_reg : VALU_ROWMASK_REGS_BITS;
	uint	ewe_en : 1;

	uint	re_reg : VALU_ROWMASK_REGS_BITS;
	uint	re_en : 1;

	uint	rdlogic_reg : VALU_RDLOGIC_REGS_BITS;

	uint	wifval : 1;
	uint	winv : 1;
	uint	wmux_ctl : VALU_WMUX_CTL_BITS;

	uint	smap_invert : 1;
	uint	smap_shift : VALU_SMAP_SHIFT_BITS;
	uint	smap_reg : VALU_SMAP_REGS_BITS;

	uint	inst_type : VALU_INST_TYPE_BITS;
} __attribute__ ((packed));

struct seu_inst_rvd {
	uint	unused : 17;

	uint	rsp16 : 1;

	uint	rvd16 : 1;
	uint	rvd4 : 1;

	uint	smap_invert : 1;
	uint	smap_shift : VALU_SMAP_SHIFT_BITS;
	uint	smap_reg : VALU_SMAP_REGS_BITS;

	uint	inst_type : VALU_INST_TYPE_BITS;
} __attribute__ ((packed));

struct seu_inst_glw {
	uint	l1_reg : 2;
	uint	l2_end : 1;
	uint	l1_l2_mode : 1;
	uint	l2_row_offs : 7;
	uint	l2_gwe : 1;
	uint	l2_gre : 1;

	uint	l1_row_offs : 4;
	uint	l1_grp_offs : 2;
	uint	l1_bank_offs : 2;
	uint	l1_gwe : 1;
	uint	l1_gre : 1;

	uint	rspEND : 1;
	uint	rspStartRet : 1;
	uint	rsp32Ksel : 1;
	uint	rsp2Ksel : 1;
	uint	rsp256sel : 1;

	uint	reserved : 1;
	uint	inst_type : VALU_INST_TYPE_BITS;
} __attribute__ ((packed));

struct seu_inst_common {
	uint	pad : 29;

	uint	inst_type : VALU_INST_TYPE_BITS;
} __attribute__ ((packed));

//structure for debug instruction sub cmd0.
struct seu_inst_debug_cmd_sub_cmd0 {

	uint	rownum_reg_2 : VALU_ROWNUM_REGS_BITS;	//4 bit
	uint	rownum_reg_1 : VALU_ROWNUM_REGS_BITS;	//4 bit
	uint	rownum_reg_0 : VALU_ROWNUM_REGS_BITS; 	//4 bit
	uint	pad:16;
	uint	sub_cmd : 1;
	uint	inst_type : VALU_INST_TYPE_BITS;	//3 bit

} __attribute__ ((packed));

//structure for debug instruction sub cmd1.
struct seu_inst_debug_cmd_sub_cmd1 {

	uint	mask : 24;
	uint	pad:4;
	uint	sub_cmd : 1;
	uint	inst_type : VALU_INST_TYPE_BITS;	//3 bit

} __attribute__ ((packed));

//union for debug cmd, has two bitfields structure options.
union seu_inst_debug_cmd {
	struct seu_inst_debug_cmd_sub_cmd0 sub_cmd0;
	struct seu_inst_debug_cmd_sub_cmd1 sub_cmd1;
} __attribute__ ((packed));


struct seu_inst_dbg_prnt {

	uint	rownum_reg_2 : VALU_ROWNUM_REGS_BITS;
	uint	rownum_reg_1 : VALU_ROWNUM_REGS_BITS;
	uint	rownum_reg_0 : VALU_ROWNUM_REGS_BITS;

	uint	unused : 17;

	uint	inst_type : VALU_INST_TYPE_BITS;

} __attribute__ ((packed));



union seu_inst {
	struct seu_inst_common	common;
	struct seu_inst_nop	nop;
	struct seu_inst_rd	read_rows;
	struct seu_inst_wr	write_rows;
	struct seu_inst_r2w1	rdwr_rows;
	struct seu_inst_rwm	rdwr_by_mask;
	struct seu_inst_rvd	rvd;
	struct seu_inst_glw	global_io;

	//debug command
	struct seu_inst_dbg_prnt	dbg_prnt;
	struct seu_inst_debug_cmd_sub_cmd0 sub_cmd0;
	struct seu_inst_debug_cmd_sub_cmd1 sub_cmd1;
	u32	val;

} __attribute__((packed));


// *INDENT-ON*

GSI_BUILD_ASSERT_SIZE(struct, seu_inst_nop, 4)
GSI_BUILD_ASSERT_SIZE(struct, seu_inst_dbg_prnt, 4)
GSI_BUILD_ASSERT_SIZE(struct, seu_inst_rd, 4)
GSI_BUILD_ASSERT_SIZE(struct, seu_inst_wr, 4)
GSI_BUILD_ASSERT_SIZE(struct, seu_inst_r2w1, 4)
GSI_BUILD_ASSERT_SIZE(struct, seu_inst_rwm, 4)
GSI_BUILD_ASSERT_SIZE(struct, seu_inst_rvd, 4)
GSI_BUILD_ASSERT_SIZE(struct, seu_inst_glw, 4)
GSI_BUILD_ASSERT_SIZE(struct, seu_inst_common, 4)
GSI_BUILD_ASSERT_SIZE(union, seu_inst, 4)

#endif /*GSI_SEU_INST_H_ */
