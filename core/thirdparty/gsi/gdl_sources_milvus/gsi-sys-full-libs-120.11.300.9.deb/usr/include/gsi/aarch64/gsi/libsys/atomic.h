/*
 * Copyright (C) 2016, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */
#ifndef GSI_ATOMIC_H
#define GSI_ATOMIC_H

// #include "config.h"

#include <gsi/libsys/types.h>

#ifndef __GNUC__
#error unsupported compiler
#endif

typedef          long		gsi_atomic_int_t;
typedef unsigned long		gsi_atomic_uint_t;
typedef          int		gsi_atomic_int32_t;
typedef unsigned int		gsi_atomic_uint32_t;
typedef          long long	gsi_atomic_int64_t;
typedef unsigned long long	gsi_atomic_uint64_t;

/*
 * GCC Memory model synchronization modes
 * https://gcc.gnu.org/wiki/Atomic/GCCMM/AtomicSync
 */

#define DEF_ATOMIC_STRUCT(_sz_) \
	typedef struct { \
		volatile gsi_atomic_int##_sz_##_t __attribute__((aligned(sizeof(gsi_atomic_int##_sz_##_t))))	val; \
	} __attribute__ ((packed)) gsi_atomic##_sz_##_t;

#define DEF_ATOMIC_GET(_sz_) \
	static inline gsi_atomic_int##_sz_##_t gsi_atomic##_sz_##_get(const gsi_atomic##_sz_##_t *p) \
	{ \
		return __atomic_load_n(&p->val, __ATOMIC_ACQUIRE); \
	}

#define DEF_ATOMIC_SET(_sz_) \
	static inline gsi_atomic_int##_sz_##_t gsi_atomic##_sz_##_set(gsi_atomic##_sz_##_t *p, gsi_atomic_int##_sz_##_t new_val) \
	{ \
		__atomic_store_n(&p->val, new_val, __ATOMIC_RELEASE); \
		return new_val; \
	}

#define __DEF_ATOMIC_OP(_sz_, _op_) \
	static inline gsi_atomic_int##_sz_##_t gsi_atomic##_sz_##_##_op_(gsi_atomic##_sz_##_t *p, gsi_atomic_int##_sz_##_t val) \
	{ \
		return __atomic_##_op_##_fetch(&p->val, val, __ATOMIC_ACQ_REL); \
	}

#define __DEF_ATOMIC_FETCH_AND_OP(_sz_, _op_) \
	static inline gsi_atomic_int##_sz_##_t gsi_atomic##_sz_##_fetch_and_##_op_(gsi_atomic##_sz_##_t *p, gsi_atomic_int##_sz_##_t val) \
	{ \
		return __atomic_fetch_##_op_(&p->val, val, __ATOMIC_ACQ_REL); \
	}

#define DEF_ATOMIC_ADD(_sz_)		__DEF_ATOMIC_OP(_sz_, add)
#define DEF_ATOMIC_SUB(_sz_)		__DEF_ATOMIC_OP(_sz_, sub)
#define DEF_ATOMIC_OR(_sz_)		__DEF_ATOMIC_OP(_sz_, or)
#define DEF_ATOMIC_AND(_sz_)		__DEF_ATOMIC_OP(_sz_, and)
#define DEF_ATOMIC_XOR(_sz_)		__DEF_ATOMIC_OP(_sz_, xor)
#define DEF_ATOMIC_NAND(_sz_)		__DEF_ATOMIC_OP(_sz_, nand)

#define DEF_ATOMIC_FETCH_AND_ADD(_sz_)	__DEF_ATOMIC_FETCH_AND_OP(_sz_, add)
#define DEF_ATOMIC_FETCH_AND_SUB(_sz_)	__DEF_ATOMIC_FETCH_AND_OP(_sz_, sub)
#define DEF_ATOMIC_FETCH_AND_OR(_sz_)	__DEF_ATOMIC_FETCH_AND_OP(_sz_, or)
#define DEF_ATOMIC_FETCH_AND_AND(_sz_)	__DEF_ATOMIC_FETCH_AND_OP(_sz_, and)
#define DEF_ATOMIC_FETCH_AND_XOR(_sz_)	__DEF_ATOMIC_FETCH_AND_OP(_sz_, xor)
#define DEF_ATOMIC_FETCH_AND_NAND(_sz_)	__DEF_ATOMIC_FETCH_AND_OP(_sz_, nand)

#define DEF_ATOMIC_INC(_sz_) \
	static inline gsi_atomic_int##_sz_##_t gsi_atomic##_sz_##_inc(gsi_atomic##_sz_##_t *p) \
	{ \
		return gsi_atomic##_sz_##_add(p, 1); \
	}

#define DEF_ATOMIC_DEC(_sz_) \
	static inline gsi_atomic_int##_sz_##_t gsi_atomic##_sz_##_dec(gsi_atomic##_sz_##_t *p) \
	{ \
		return gsi_atomic##_sz_##_sub(p, 1); \
	}

/*
 * Returns @p->val before the operation
 * Caller should test if returned value equals old_val to determine whether the value was swapped with @new_val.
 */
#define DEF_ATOMIC_CMP_AND_SWAP(_sz_) \
	static inline gsi_atomic_int##_sz_##_t gsi_atomic##_sz_##_cmp_and_swap(gsi_atomic##_sz_##_t *p, gsi_atomic_int##_sz_##_t old_val, gsi_atomic_int##_sz_##_t new_val) \
	{ \
		__atomic_compare_exchange_n(&p->val, &old_val, new_val, false, __ATOMIC_ACQ_REL, __ATOMIC_ACQUIRE); \
		return old_val; \
	}

/*
 * Returns true if the comparison is successful and @new_val was written.
 */
#define DEF_ATOMIC_BOOL_CMP_AND_SWAP(_sz_) \
	static inline int gsi_atomic##_sz_##_bool_cmp_and_swap(gsi_atomic##_sz_##_t *p, gsi_atomic_int##_sz_##_t old_val, gsi_atomic_int##_sz_##_t new_val) \
	{ \
		return __atomic_compare_exchange_n(&p->val, &old_val, new_val, false, __ATOMIC_ACQ_REL, __ATOMIC_ACQUIRE); \
	}

#define DEF_ATOMIC_SWAP(_sz_) \
	static inline gsi_atomic_int##_sz_##_t gsi_atomic##_sz_##_swap(gsi_atomic##_sz_##_t *p, gsi_atomic_int##_sz_##_t new_val) \
	{ \
		return __atomic_exchange_n(&p->val, new_val, __ATOMIC_ACQUIRE); \
	}

#define DEF_ATOMIC_IS_LOCKED(_sz_) \
	static inline bool gsi_atomic##_sz_##_is_locked(gsi_atomic##_sz_##_t *p) \
	{ \
		return __atomic_load_n((bool *)(&p->val), __ATOMIC_ACQUIRE) != 0; \
	}

/* Returns true iff lock was successfully acquired */
#define DEF_ATOMIC_TRYLOCK(_sz_) \
	static inline bool gsi_atomic##_sz_##_trylock(gsi_atomic##_sz_##_t *p) \
	{ \
		return !__atomic_test_and_set((bool *)(&p->val), __ATOMIC_ACQ_REL); \
	}

#define DEF_ATOMIC_SPINLOCK(_sz_) \
	static inline void gsi_atomic##_sz_##_spinlock(gsi_atomic##_sz_##_t *p) \
	{ \
		while (!gsi_atomic##_sz_##_trylock(p)) { \
		} \
	}

#define DEF_ATOMIC_UNLOCK(_sz_) \
	static inline void gsi_atomic##_sz_##_unlock(gsi_atomic##_sz_##_t *p) \
	{ \
		return __atomic_clear((bool *)(&p->val), __ATOMIC_RELEASE); \
	}

DEF_ATOMIC_STRUCT(32)
DEF_ATOMIC_GET(32)
DEF_ATOMIC_SET(32)
DEF_ATOMIC_ADD(32)
DEF_ATOMIC_SUB(32)
DEF_ATOMIC_OR(32)
DEF_ATOMIC_AND(32)
DEF_ATOMIC_XOR(32)
DEF_ATOMIC_NAND(32)
DEF_ATOMIC_FETCH_AND_ADD(32)
DEF_ATOMIC_FETCH_AND_SUB(32)
DEF_ATOMIC_FETCH_AND_OR(32)
DEF_ATOMIC_FETCH_AND_AND(32)
DEF_ATOMIC_FETCH_AND_XOR(32)
DEF_ATOMIC_FETCH_AND_NAND(32)
DEF_ATOMIC_INC(32)
DEF_ATOMIC_DEC(32)
DEF_ATOMIC_CMP_AND_SWAP(32)
DEF_ATOMIC_BOOL_CMP_AND_SWAP(32)
DEF_ATOMIC_SWAP(32)
DEF_ATOMIC_IS_LOCKED(32)
DEF_ATOMIC_TRYLOCK(32)
DEF_ATOMIC_SPINLOCK(32)
DEF_ATOMIC_UNLOCK(32)

DEF_ATOMIC_STRUCT(64)
DEF_ATOMIC_GET(64)
DEF_ATOMIC_SET(64)
DEF_ATOMIC_ADD(64)
DEF_ATOMIC_SUB(64)
DEF_ATOMIC_OR(64)
DEF_ATOMIC_AND(64)
DEF_ATOMIC_XOR(64)
DEF_ATOMIC_NAND(64)
DEF_ATOMIC_FETCH_AND_ADD(64)
DEF_ATOMIC_FETCH_AND_SUB(64)
DEF_ATOMIC_FETCH_AND_OR(64)
DEF_ATOMIC_FETCH_AND_AND(64)
DEF_ATOMIC_FETCH_AND_XOR(64)
DEF_ATOMIC_FETCH_AND_NAND(64)
DEF_ATOMIC_INC(64)
DEF_ATOMIC_DEC(64)
DEF_ATOMIC_CMP_AND_SWAP(64)
DEF_ATOMIC_BOOL_CMP_AND_SWAP(64)
DEF_ATOMIC_SWAP(64)
DEF_ATOMIC_IS_LOCKED(64)
DEF_ATOMIC_TRYLOCK(64)
DEF_ATOMIC_SPINLOCK(64)
DEF_ATOMIC_UNLOCK(64)

DEF_ATOMIC_STRUCT()
DEF_ATOMIC_GET()
DEF_ATOMIC_SET()
DEF_ATOMIC_ADD()
DEF_ATOMIC_SUB()
DEF_ATOMIC_OR()
DEF_ATOMIC_AND()
DEF_ATOMIC_XOR()
DEF_ATOMIC_NAND()
DEF_ATOMIC_FETCH_AND_ADD()
DEF_ATOMIC_FETCH_AND_SUB()
DEF_ATOMIC_FETCH_AND_OR()
DEF_ATOMIC_FETCH_AND_AND()
DEF_ATOMIC_FETCH_AND_XOR()
DEF_ATOMIC_FETCH_AND_NAND()
DEF_ATOMIC_INC()
DEF_ATOMIC_DEC()
DEF_ATOMIC_CMP_AND_SWAP()
DEF_ATOMIC_BOOL_CMP_AND_SWAP()
DEF_ATOMIC_SWAP()
DEF_ATOMIC_IS_LOCKED()
DEF_ATOMIC_TRYLOCK()
DEF_ATOMIC_SPINLOCK()
DEF_ATOMIC_UNLOCK()

/*
 * Reference count
 */
typedef gsi_atomic_t gsi_ref_t;

static inline void gsi_ref_init(gsi_ref_t *ref)
{
	gsi_atomic_set(ref, 1);
}

static inline int gsi_ref_get(gsi_ref_t *ref)
{
	return (int)gsi_atomic_inc(ref);
}

static inline int gsi_ref_put(gsi_ref_t *ref, void (*release)(gsi_ref_t *refp))
{
	int refs = (int)gsi_atomic_dec(ref);
	if (refs <= 0) {
		GSI_ASSERT(refs == 0);
		if (release)
			release(ref);
	}
	return refs;
}

#endif /* GSI_ATOMIC_H */
