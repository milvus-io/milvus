/*
 * Copyright (C) 2016, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */
#ifndef GSI_ERROR_H
#define GSI_ERROR_H

#include <gsi/libsys/config.h>

#ifdef GSI_LIBSYS_NOSTDLIB

#include <gsi/libsys/libc.h>

#else

#ifdef _BUILD_OS_GNU_LINUX
#include <sys/user.h>
#endif

#include <errno.h>

#endif

#include "types.h"
#include "assert.h"

GSI_BUILD_ASSERT_CONST(GSI_ERR_PTR_SZ, sizeof(void *) == sizeof(intptr_t))

#define __gsi_is_err(_type_, _status_)		((_type_)(_status_) < 0)
#define __gsi_is_err_ptr(_type_, _status_)	(__gsi_is_err(_type_, _status_) && ((_type_)(_status_) > (_type_)(-PAGE_SIZE)))

/*
 * Encode a negative error in a pointer return value
 * Note that NULL is not considered an error, use PTR_ERR(-ENOMEM) for
 * allocation failures, NULL may be validly returned for e.g. search misses.
 */
static inline void *GSI_ERR_TO_PTR(gsi_status_t err)
{
	GSI_DEBUG_ASSERT(__gsi_is_err_ptr(gsi_status_t, err));
	return (void *)(intptr_t)err;
}

#ifndef PAGE_SIZE
#define PAGE_SIZE (4096)
#endif

extern const char *gsi_status_errorstr(gsi_status_t status);

#ifdef GSI_LIBSYS_NOSTDLIB

#define GSI_0                0      /* Success */
#define GSI_EPERM            1      /* Operation not permitted */
#define GSI_ENOENT           2      /* No such file or directory */
#define GSI_ESRCH            3      /* No such process */
#define GSI_EINTR            4      /* Interrupted system call */
#define GSI_EIO              5      /* I/O error */
#define GSI_ENXIO            6      /* No such device or address */
#define GSI_E2BIG            7      /* Argument list too long */
#define GSI_ENOEXEC          8      /* Exec format error */
#define GSI_EBADF            9      /* Bad file number */
#define GSI_ECHILD          10      /* No child processes */
#define GSI_EAGAIN          11      /* Try again */
#define GSI_ENOMEM          12      /* Out of memory */
#define GSI_EACCES          13      /* Permission denied */
#define GSI_EFAULT          14      /* Bad address */
#define GSI_ENOTBLK         15      /* Block device required */
#define GSI_EBUSY           16      /* Device or resource busy */
#define GSI_EEXIST          17      /* File exists */
#define GSI_EXDEV           18      /* Cross-device link */
#define GSI_ENODEV          19      /* No such device */
#define GSI_ENOTDIR         20      /* Not a directory */
#define GSI_EISDIR          21      /* Is a directory */
#define GSI_EINVAL          22      /* Invalid argument */
#define GSI_ENFILE          23      /* File table overflow */
#define GSI_EMFILE          24      /* Too many open files */
#define GSI_ENOTTY          25      /* Not a typewriter */
#define GSI_ETXTBSY         26      /* Text file busy */
#define GSI_EFBIG           27      /* File too large */
#define GSI_ENOSPC          28      /* No space left on device */
#define GSI_ESPIPE          29      /* Illegal seek */
#define GSI_EROFS           30      /* Read-only file system */
#define GSI_EMLINK          31      /* Too many links */
#define GSI_EPIPE           32      /* Broken pipe */
#define GSI_EDOM            33      /* Math argument out of domain of func */
#define GSI_ERANGE          34      /* Math result not representable */

#define GSI_EDEADLK         35      /* Resource deadlock would occur */
#define GSI_ENAMETOOLONG    36      /* File name too long */
#define GSI_ENOLCK          37      /* No record locks available */

#define GSI_ENOSYS          38      /* Invalid system call number */

#define GSI_ENOTEMPTY       39      /* Directory not empty */
#define GSI_ELOOP           40      /* Too many symbolic links encountered */



#define gsi_status(err) (-GSI_ ## err)
#else
static inline gsi_status_t gsi_status(int sys_err)
{
	gsi_status_t ret = -sys_err;
	GSI_DEBUG_ASSERT(ret == 0 || __gsi_is_err(gsi_status_t, ret));
	return ret;
}
#endif

static inline bool GSI_IS_ERR(gsi_status_t e)
{
	return __gsi_is_err(gsi_status_t, e);
}

static inline bool GSI_IS_ERR_PTR(const void *ptr)
{
	return __gsi_is_err_ptr(intptr_t, ptr);
}

static inline bool GSI_IS_ERR_PTR_OR_NULL(const void *ptr)
{
	return (ptr == NULL) || GSI_IS_ERR_PTR(ptr);
}

static inline gsi_status_t GSI_PTR_TO_ERR(const void *ptr)
{
	GSI_EXTRA_DEBUG_ASSERT(GSI_IS_ERR_PTR(ptr));
	gsi_status_t ret = (gsi_status_t)(intptr_t)ptr;
	GSI_EXTRA_DEBUG_ASSERT(GSI_IS_ERR(ret));
	return ret;
}

enum gsi_error_defs {
	GSI_SUCCESS = 0,
	GSI_SYSERR_FAILURE = 1,
	GSI_SYSERR_USAGE = 2,
	GSI_SYSERR_FATAL = 255,
};

extern void gsi_backtrace(int fd);
extern void gsi_exit(int exit_status);

extern void gsi_abort(void);
extern void gsi_fatal_exit(void);
extern gsi_status_t gsi_get_sys_error(void);

extern void _gsi_sys_error_log(const char *file, int line, const char *func, enum gsi_log_level level, const char *action, const char *name);

#define __gsi_sys_error_log(_level_, _action_, _name_) \
	_gsi_sys_error_log(__FILE__, __LINE__, __func__, (_level_), (_action_), (_name_))

#define gsi_sys_warning(_action_, _name_)	__gsi_sys_error_log(GSI_LOG_WARNING, (_action_), (_name_))
#define gsi_sys_error(_action_, _name_)		__gsi_sys_error_log(GSI_LOG_ERROR, (_action_), (_name_))
#define gsi_sys_fatal(_action_, _name_)		__gsi_sys_error_log(GSI_LOG_FATAL, (_action_), (_name_))

#define gsi_sys_exit gsi_sys_fatal

#endif /* GSI_ERROR_H */
