/*
 * Common API for Host code and User Tasks running on GSI's APU System
 *
 * Copyright (C) 2016, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */
#ifndef GSI_COMMON_API_H
#define GSI_COMMON_API_H

#ifdef	__cplusplus
extern "C" {
#endif

#ifndef __GNUC__
#error unsupported compiler
#endif

#if __STDC_HOSTED__ != 0
#include <errno.h>
#else
#include <gsi/libsys/libc.h>
#endif

struct gsi_api_version {
	unsigned short major;
	unsigned short minor;
} __attribute__((packed));

enum {
	GSI_API_VERSION_MAJOR = 0U,
	GSI_API_VERSION_MINOR = 0U,
};

typedef   signed int		gsi_prod_int_t;
typedef unsigned int		gsi_prod_uint_t;

typedef gsi_prod_int_t		gsi_prod_status_t;

typedef   signed char		gsi_prod_int8_t;
typedef unsigned char		gsi_prod_uint8_t;
typedef   signed short		gsi_prod_int16_t;
typedef unsigned short		gsi_prod_uint16_t;
typedef   signed int		gsi_prod_int32_t;
typedef unsigned int		gsi_prod_uint32_t;
typedef   signed long long	gsi_prod_int64_t;
typedef unsigned long long	gsi_prod_uint64_t;

typedef gsi_prod_uint16_t	gsi_prod_fp16_t;
typedef gsi_prod_uint32_t	gsi_prod_fp32_t;
typedef gsi_prod_fp32_t		gsi_prod_float_t;
typedef gsi_prod_uint64_t	gsi_prod_fp64_t;
typedef gsi_prod_fp64_t		gsi_prod_double_t;

typedef gsi_prod_uint8_t	gsi_prod_byte_t;
typedef gsi_prod_uint16_t	gsi_prod_hword_t;
typedef gsi_prod_uint32_t	gsi_prod_word_t;
typedef gsi_prod_uint64_t	gsi_prod_dword_t;

// on all architechture gsi_prod_prt_t is the same size
// in case of APU controller change reavaluate.
typedef gsi_prod_uint32_t	gsi_prod_ptr_t;

#ifdef __x86_64
#define API_HOST_PTR_TYPE(t) t *
#define API_DEV_PTR_TYPE(t) gsi_prod_ptr_t
#else
#define API_HOST_PTR_TYPE(t) gsi_prod_uint64_t
#define API_DEV_PTR_TYPE(t) t *
#endif

typedef gsi_prod_uint32_t	gsi_prod_size_t;
typedef gsi_prod_int32_t	gsi_prod_ssize_t;

#define gsi_prod_sizeof	(gsi_prod_size_t)sizeof

#define GSI_PROD_NULL	(gsi_prod_ptr_t)(0)

typedef gsi_prod_uint8_t	gsi_prod_io_t;

#define GSI_TASK_IO_ADDR_ALIGNMENT sizeof(uint64_t)

enum {
	GSI_DRV_MAX_BOARDS                    = 16,

	GSI_SYS_MAX_CONTEXTS_PER_BOARD        = 8,
	GSI_SYS_MAX_STREAMS_PER_CONTEXT       = 32,

	GSI_MAX_APUCS_PER_APU                 = 4,

	GSI_MAX_APU_COUNT                     = 1,
	GSI_MAX_APUC_COUNT                    = GSI_MAX_APU_COUNT * GSI_MAX_APUCS_PER_APU,
	GSI_TASK_QUEUE_PER_APUC               = 8,
	GSI_TASK_QUEUE_COUNT                  = GSI_MAX_APUC_COUNT * GSI_TASK_QUEUE_PER_APUC,
	GSI_TASK_DESC_POOL_COUNT              = GSI_MAX_APUC_COUNT * GSI_TASK_QUEUE_PER_APUC * 2,

	GSI_MAX_APU_COUNT_SIM                 = 8,
	GSI_MAX_APUC_COUNT_SIM                = GSI_MAX_APU_COUNT_SIM * GSI_MAX_APUCS_PER_APU,
	GSI_TASK_QUEUE_COUNT_SIM              = GSI_MAX_APUC_COUNT_SIM * GSI_TASK_QUEUE_PER_APUC,
};

enum gsi_task_state {
	GSI_TASK_FREE = 0,
	GSI_TASK_READY,				/* task descriptor ready */
	GSI_TASK_PENDING_BARRIER,		/* task queued in stream barrier queue */
	GSI_TASK_PENDING,			/* task queued in system queue */
	GSI_TASK_WAIT_DEP,			/* task waiting on dependencies */
	GSI_TASK_WAIT_APC,			/* task waiting on APC (no dependencies left) */
	GSI_TASK_RUNNING,			/* task running on APC */
	GSI_TASK_COMPLETE,			/* task completed successfully, see tc_ret_code for return value */

	/* order represents severity */
	GSI_TASK_ABORTED,			/* task execution aborted, see tc_ret_code for system error codes */
	GSI_TASK_WATCHDOG,			/* task aborted due to watchdog timer */
	GSI_TASK_ERROR,				/* task completed with error, see tc_ret_code for return value */
};

enum gsi_task_error_code {
	GSI_TASK_FAULT_NONE,			/* no fault */

	GSI_TASK_ERROR_INVALID_DESC,		/* invalid task descriptor */

	GSI_TASK_FAULT_INVALID_INST,		/* invalid instruction */
	GSI_TASK_FAULT_INVALID_INST_ADDR,	/* invalid instruction address */
	GSI_TASK_FAULT_NULL,			/* null pointer dereference */
	GSI_TASK_FAULT_INVALID_DATA_ADDR,	/* invalid data address */
	GSI_TASK_FAULT_MEM_BUS,			/* Memory bus fault */
	GSI_TASK_FAULT_MEM_UNIT,		/* Memory unit fault */
};

#define GSI_SYS_TASK_MAX_DEPENDENCIES		16
#define GSI_TASK_DYNAMIC_TABLE_NUM_ENTRIES 	15
#define GSI_UNUSED_ENTRY                        255

enum {
	GSI_TASK_NOTIFY_COMPLETION	= 1 << 0,
	GSI_TASK_IS_BARRIER			= 1 << 1,
	GSI_TASK_IS_INITIAL			= 1 << 2,
	GSI_TASK_NEED_MAPPING   	= 1 << 3,
};

enum gsi_task_type {
	GSI_SYS_TASK =		0,
	GSI_USR_TASK =		1
};

struct gsi_task_comp_desc {
	gsi_prod_uint8_t context_id;
	gsi_prod_uint8_t stream_id;
	gsi_prod_uint8_t apu_id;
	gsi_prod_uint8_t apuc_id;
	gsi_prod_uint8_t flags;	/* apply only to user tasks */
	gsi_prod_uint8_t unused[2];
	gsi_prod_uint32_t task_id;

	/* Completion data */
	enum gsi_task_state state;
	gsi_prod_status_t ret_code;
	gsi_prod_uint64_t backptr;
} __attribute__((packed, aligned(8)));

struct gsi_task_desc {
	enum gsi_task_type type;
	union {
		gsi_prod_uint32_t sys_proc_id;
		gsi_prod_ptr_t usr_proc_ptr;			// APUC address
	};
	gsi_prod_ptr_t input_ptr;				// APUC address
	gsi_prod_ptr_t output_ptr;				// APUC address
	gsi_prod_uint32_t num_dependencies;				// if greater then GSI_SYS_TASK_MAX_DEPENDENCIES, task will wait for termination of all tasks scheduled before it
	gsi_prod_uint32_t dependencies[12];
	gsi_prod_uint8_t dynamic_mapping_table[GSI_TASK_DYNAMIC_TABLE_NUM_ENTRIES];
        char pad;
	struct gsi_task_comp_desc comp;
} __attribute__((packed, aligned(8)));

#define GSI_TASK_SUCCESS			0
#define GSI_TASK_WRONG_PARAM			-1

typedef gsi_prod_int_t (gsi_task_main_func)(gsi_prod_ptr_t in, gsi_prod_ptr_t out);

static inline int gsi_task_is_successful(struct gsi_task_comp_desc *comp)
{
	return ((comp->state == GSI_TASK_COMPLETE) && (comp->ret_code >= 0)) ||
	       comp->state == GSI_TASK_FREE;
}

static inline gsi_prod_status_t gsi_task_comp_status(struct gsi_task_comp_desc *comp)
{
	gsi_prod_status_t ret;

	switch (comp->state) {
	case GSI_TASK_COMPLETE:
		ret = comp->ret_code;
		break;
	case GSI_TASK_ABORTED:
		ret = -EINTR;
		break;
	case GSI_TASK_WATCHDOG:
		ret = -ETIMEDOUT;
		break;
	case GSI_TASK_ERROR:
		ret = -EFAULT;
		break;
	default:
		ret = -EINVAL;
		break;
	}

	return ret;
}

#ifdef	__cplusplus
}
#endif

#endif /* GSI_COMMON_API_H */
