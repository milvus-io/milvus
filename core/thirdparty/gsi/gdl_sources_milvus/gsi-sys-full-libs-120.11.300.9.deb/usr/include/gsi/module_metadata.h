/*
 * Copyright (C) 2017, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */
#ifndef GSI_MODULE_METADATA_H
#define GSI_MODULE_METADATA_H

#include <stdint.h>
#include <gsi/common_api.h>

struct gsi_module_loader_metadata {
	struct gsi_api_version api_version;

	/* pre-digested general values for the loader */
	uint32_t phdr_size;		/* phdr is absent in binary dumps but is part of code segment vm-wise.
					 * (actually this is the offset we need to take in order to align the code
					 * properly) */
	uint32_t load_fixup;            /* p_addr of the code segment, truncated to page boundary */
	uint32_t mem_size;		/* vm footprint of the module */
	uint32_t real_data_seg_addr;	/* after relro, if any */

	/* segments */
	uint32_t data_seg_addr;
	uint32_t relro_seg_addr;

	uint32_t valufrag_addr;
	uint32_t valufrag_size;

	/* some segment addresses, for debugging */
	uint32_t text_addr;
	uint32_t rodata_addr;
	uint32_t data_relro_addr;
	uint32_t data_addr;
	uint32_t bss_addr;

	/* constructors */
	uint32_t init_addr;
	uint32_t init_array_addr;
	uint32_t init_array_size;

	/* relocations */
	uint32_t rel;
	uint32_t relent;
	uint32_t relsz;

	/* entry point (for kernel & bootloader) */
	uint32_t entry_point;
} __attribute__((packed));

#define GSI_MODULE_STRUCT_DEFINE(name, mdptr_t, charptr_t, ucharptr_t)       \
	struct name { \
		mdptr_t md; \
		charptr_t path; \
		ucharptr_t dump_start; \
		ucharptr_t dump_end; \
	}
#if UINTPTR_MAX != 0xffffffff
/* 64-bit */
GSI_MODULE_STRUCT_DEFINE(gsi_module_32, uint32_t, uint32_t, uint32_t);
#endif
GSI_MODULE_STRUCT_DEFINE(gsi_module, const struct gsi_module_loader_metadata *, const char *, const unsigned char *);

#endif /* GSI_MODULE_METADATA_H */
