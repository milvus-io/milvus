#include <gsi/libsys/debug.h>

#undef GSI_DEBUG_MODULE_DECL
#undef GSI_DEBUG_MODULE_DECL_STR
#undef _gsi_debug_module_decl_pass2
#undef _gsi_debug_module_cookie_pass2
#undef gsi_debug_module_cookie

#ifdef GSI_DEBUG_MODULE
#define _gsi_debug_module_decl_pass2(_name) _gsi_debug_module_decl(_name, _name)
_gsi_debug_module_decl_pass2(GSI_DEBUG_MODULE);
#define _gsi_debug_module_cookie_pass2(_name) _gsi_debug_module_cookie(_name)
#define gsi_debug_module_cookie() _gsi_debug_module_cookie_pass2(GSI_DEBUG_MODULE)
#else
#define GSI_DEBUG_MODULE_DECL_STR(_module_str) _gsi_debug_module_decl_str(default, _module_str)
#define GSI_DEBUG_MODULE_DECL(_module) GSI_DEBUG_MODULE_DECL_STR(#_module)
#define gsi_debug_module_cookie() _gsi_debug_module_cookie(default)
#endif
