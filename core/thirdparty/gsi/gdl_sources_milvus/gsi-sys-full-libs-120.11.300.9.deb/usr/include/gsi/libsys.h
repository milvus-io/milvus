/*
 * Copyright (C) 2016, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */
#ifndef GSI_LIBSYS_H
#define GSI_LIBSYS_H

#if defined(GSI_LIBSYS_X86_64)
#include <gsi/libsys_x86_64.h>
#elif defined(GSI_LIBSYS_X86_32)
#include <gsi/libsys_x86_32.h>
#elif defined(GSI_LIBSYS_X86_32_NOSTDLIB)
#include <gsi/libsys_x86_32_nostdlib.h>
#elif defined(GSI_LIBSYS_AARCH64)
#include <gsi/libsys_aarch64.h>
#elif defined(GSI_LIBSYS_ARCHS36)
#include <gsi/libsys_archs36.h>
#else
#error "The architecture you are trying to compile to is not yet supported by libgsisys"
#endif

#endif /* GSI_LIBSYS_H */
