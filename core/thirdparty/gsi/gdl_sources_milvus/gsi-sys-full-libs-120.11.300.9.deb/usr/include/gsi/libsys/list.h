/*
 * Copyright (C) 2016, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */
#include "config.h"

#ifndef GSI_LIST_H
#define GSI_LIST_H

#include "types.h"
#include "assert.h"

#define gsi_list_entry(p, type, member) \
	container_of(p, type, member)

#define gsi_list_entry_or_null(p, type, member) \
	((p) ? gsi_list_entry(p, type, member) : NULL)

/*
 * Singly-Linked List definitions
 */
struct gsi_slist {
	struct gsi_slist *sl_next;
};

#define GSI_SLIST_HEAD(x)	struct gsi_slist (x) = { NULL }

static inline void
gsi_slist_init(struct gsi_slist *head)
{
	head->sl_next = NULL;
}

static inline bool
gsi_slist_is_empty(struct gsi_slist *head)
{
	return head->sl_next == NULL;
}

static inline void
gsi_slist_add_after(struct gsi_slist *ent, struct gsi_slist *newent)
{
	newent->sl_next = ent->sl_next;
	ent->sl_next = newent;
}

static inline struct gsi_slist *
gsi_slist_del_next(struct gsi_slist *head)
{
	struct gsi_slist *ent = head->sl_next;

	if (ent)
		head->sl_next = ent->sl_next;

	return ent;
}

#define gsi_slist_next_entry(iter, member) \
	gsi_list_entry_or_null((iter)->member.sl_next, typeof(*(iter)), member)

/*
 * FIFO queue
 */
struct gsi_fifo {
	struct gsi_slist *fi_head;
	struct gsi_slist *fi_tail;
};

static inline void
gsi_fifo_init(struct gsi_fifo *fifo)
{
	fifo->fi_head = fifo->fi_tail = NULL;
}

static inline bool
gsi_fifo_is_empty(struct gsi_fifo *fifo)
{
#ifdef DEBUG_BUILD
	GSI_ASSERT((fifo->fi_head != NULL) == (fifo->fi_tail != NULL));
#endif
	return fifo->fi_head == NULL;
}

static inline void
gsi_fifo_enqueue(struct gsi_fifo *fifo, struct gsi_slist *ent)
{
	struct gsi_slist *tail = fifo->fi_tail;
	ent->sl_next = NULL;
	if (tail) {
		tail->sl_next = ent;
	} else
		fifo->fi_head = ent;
	fifo->fi_tail = ent;
}

static inline struct gsi_slist *
gsi_fifo_dequeue(struct gsi_fifo *fifo)
{
	struct gsi_slist *ent = fifo->fi_head;
	if (ent && ((fifo->fi_head = ent->sl_next) == NULL))
		fifo->fi_tail = NULL;
	return ent;
}

#define gsi_fifo_enqueue_entry(fifo, ent, member) \
	gsi_fifo_enqueue(fifo, &((ent)->member))

#define gsi_fifo_dequeue_entry(fifo, type, member) \
	(!gsi_fifo_is_empty(fifo) ? gsi_list_entry(gsi_fifo_dequeue(fifo), type, member) : NULL)

#define gsi_fifo_first_entry(fifo, type, member) \
	gsi_list_entry_or_null((fifo)->fi_head, type, member)

#define gsi_fifo_last_entry(fifo, type, member) \
	gsi_list_entry_or_null((fifo)->fi_tail, type, member)

#define gsi_fifo_foreach(fifo, iter) \
	for ((iter) = (fifo)->fi_head; \
	     (iter); \
	     (iter) = (iter)->sl_next)

#define gsi_fifo_foreach_safe(fifo, iter, next) \
	for ((iter) = (fifo)->fi_head, (next) = (iter)->sl_next; \
	     (iter); \
	     (iter) = (next), (next) = (iter)->sl_next)

#define gsi_fifo_foreach_entry(fifo, iter, member) \
	for ((iter) = gsi_fifo_first_entry(fifo, typeof(*iter), member); \
	     (iter); \
	     (iter) = gsi_slist_next_entry(iter, member))

#define gsi_fifo_foreach_entry_safe(fifo, iter, next, member) \
	for ((iter) = gsi_fifo_first_entry(fifo, typeof(*iter), member), (next) = gsi_slist_next_entry(iter, member); \
	     (iter); \
	     (iter) = (next), (next) = gsi_slist_next_entry(iter, member))

/*
 * Doubly-Linked List definitions
 */
struct gsi_dlist {
	struct gsi_dlist *dl_next;
	struct gsi_dlist *dl_prev;
};

#define GSI_DLIST_HEAD(x)	struct gsi_dlist (x) = { &(x), &(x) }

#define GSI_DLIST_POISON_1	((struct gsi_dlist *)0xd1d1d1d1)
#define GSI_DLIST_POISON_2	((struct gsi_dlist *)0xd2d2d2d2)

static inline struct gsi_dlist *
gsi_dlist_init(struct gsi_dlist *head)
{
	head->dl_next = head;
	head->dl_prev = head;
	return head;
}

static inline bool
gsi_dlist_is_empty(struct gsi_dlist *head)
{
	if (head->dl_next == head) {
		GSI_ASSERT(head->dl_prev == head);
		return true;
	}

	GSI_ASSERT(head->dl_prev != head);
	return false;
}

static inline void
_gsi_dlist_link_after(struct gsi_dlist *head, struct gsi_dlist *ent)
{
	ent->dl_prev = head;
	head->dl_next = ent;
}

static inline void
_gsi_dlist_link_before(struct gsi_dlist *head, struct gsi_dlist *ent)
{
	ent->dl_next = head;
	head->dl_prev = ent;
}

/*
 * Add @ent after @head
 */
static inline void
gsi_dlist_add_after(struct gsi_dlist *head, struct gsi_dlist *ent)
{
	_gsi_dlist_link_before(head->dl_next, ent);
	_gsi_dlist_link_after(head, ent);
}

/*
 * Add @ent before @head
 */
static inline void
gsi_dlist_add_before(struct gsi_dlist *head, struct gsi_dlist *ent)
{
	_gsi_dlist_link_after(head->dl_prev, ent);
	_gsi_dlist_link_before(head, ent);
}

static inline void
gsi_dlist_add_first(struct gsi_dlist *head, struct gsi_dlist *newent)
{
	gsi_dlist_add_before(head->dl_next, newent);
}

static inline void
gsi_dlist_add_last(struct gsi_dlist *head, struct gsi_dlist *newent)
{
	gsi_dlist_add_after(head->dl_prev, newent);
}

static inline void
_gsi_dlist_del(struct gsi_dlist *ent)
{
	ent->dl_prev->dl_next = ent->dl_next;
	ent->dl_next->dl_prev = ent->dl_prev;
}

static inline struct gsi_dlist *
gsi_dlist_del(struct gsi_dlist *ent)
{
	_gsi_dlist_del(ent);
	ent->dl_next = GSI_DLIST_POISON_1;
	ent->dl_prev = GSI_DLIST_POISON_2;
	return ent;
}

static inline struct gsi_dlist *
gsi_dlist_del_init(struct gsi_dlist *ent)
{
	_gsi_dlist_del(ent);
	return gsi_dlist_init(ent);
}

/*
 * Move @ent after @head
 */
static inline void
gsi_dlist_move_after(struct gsi_dlist *head, struct gsi_dlist *ent)
{
	gsi_dlist_del_init(ent);
	gsi_dlist_add_after(head, ent);
}

/*
 * Move @ent before @head
 */
static inline void
gsi_dlist_move_before(struct gsi_dlist *head, struct gsi_dlist *ent)
{
	gsi_dlist_del_init(ent);
	gsi_dlist_add_before(head, ent);
}

/*
 * Merge @list after @head
 */
static inline void
gsi_dlist_splice_after(struct gsi_dlist *head, struct gsi_dlist *list)
{
	if (unlikely(gsi_dlist_is_empty(list)))
		return;

	_gsi_dlist_link_before(head->dl_next, list->dl_prev);
	_gsi_dlist_link_after(head, list->dl_next);
	gsi_dlist_init(list);
}

/*
 * merge @list before @head
 */
static inline void
gsi_dlist_splice_before(struct gsi_dlist *head, struct gsi_dlist *list)
{
	if (unlikely(gsi_dlist_is_empty(list)))
		return;

	_gsi_dlist_link_after(head->dl_prev, list->dl_next);
	_gsi_dlist_link_before(head, list->dl_prev);
	gsi_dlist_init(list);
}

#define gsi_dlist_first_entry(head, type, member) \
	gsi_list_entry((head)->dl_next, type, member)

#define gsi_dlist_first_entry_or_null(head, type, member) \
	(!gsi_dlist_is_empty(head) ? gsi_dlist_first_entry(head, type, member) : NULL)

#define gsi_dlist_last_entry(head, type, member) \
	gsi_list_entry((head)->dl_prev, type, member)

#define gsi_dlist_last_entry_or_null(head, type, member) \
	(!gsi_dlist_is_empty(head) ? gsi_dlist_last_entry(head, type, member) : NULL)

#define gsi_dlist_next_entry(iter, member) \
	gsi_list_entry((iter)->member.dl_next, typeof(*(iter)), member)

#define gsi_dlist_next_entry_or_null(head, iter, member) \
	(((iter)->member.dl_next != (head)) ? gsi_dlist_next_entry(iter, member) : NULL)

#define gsi_dlist_prev_entry(iter, member) \
	gsi_list_entry((iter)->member.dl_prev, typeof(*(iter)), member)

#define gsi_dlist_prev_entry_or_null(head, iter, member) \
	(((iter)->member.dl_prev != (head)) ? gsi_dlist_prev_entry(iter, member) : NULL)

#define gsi_dlist_foreach(head, iter) \
	for ((iter) = (head)->dl_next; \
	     (iter) != (head); \
	     (iter) = (iter)->dl_next)

#define gsi_dlist_foreach_safe(head, iter, next) \
	for ((iter) = (head)->dl_next, (next) = (iter)->dl_next; \
	     (iter) != (head); \
	     (iter) = (next), (next) = (iter)->dl_next)

#define gsi_dlist_foreach_entry(head, iter, member) \
	for ((iter) = gsi_dlist_first_entry(head, typeof(*iter), member); \
	     &(iter)->member != (head); \
	     (iter) = gsi_dlist_next_entry(iter, member))

#define gsi_dlist_foreach_entry_from_reverse(pos, head, member)		\
	for ((iter) = gsi_dlist_last_entry(head, typeof(*iter), member); \
	     &(iter)->member != (head); \
	     (iter) = gsi_dlist_prev_entry(iter, member))

#define gsi_dlist_foreach_entry_safe(head, iter, next, member) \
	for ((iter) = gsi_dlist_first_entry(head, typeof(*iter), member), (next) = gsi_dlist_next_entry(iter, member); \
	     &(iter)->member != (head); \
	     (iter) = (next), (next) = gsi_dlist_next_entry(iter, member))

static inline int gsi_dlist_count(struct gsi_dlist *head)
{
	int count = 0;
	struct gsi_dlist *p;

	gsi_dlist_foreach(head, p) {
		count++;
	}

	return count;
}

#endif /* GSI_LIST_H */
