/*
 * Copyright (C) 2016, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */
#ifndef GSI_BUF_H
#define GSI_BUF_H

//#if defined(GSI_LIBSYS_AARCH64) || defined(GSI_LIBSYS_X86_64) || defined(GSI_LIBSYS_X86_32)
#if defined(GSI_LIBSYS_AARCH64)
#include <unistd.h>
#include <time.h>
#endif

#include "assert.h"
#include "error.h"
#include "arc-buf.h"

union gsi_fifo_rwcounters {
	struct {
		gsi_atomic32_t wr, rd;
	};
	gsi_atomic64_t rw;
};

struct gsi_fifo_buf {
	union gsi_fifo_rwcounters counters;
	u32 size_mask; // must be power of 2
	u32 rec_size;
	volatile byte *buf;
};

static inline u32 _gsi_fifo_get_tail_idx(struct gsi_fifo_buf *fb)
{
	return (gsi_atomic32_get(&fb->counters.wr) & fb->size_mask);
}

static inline u32 _gsi_fifo_get_tail_offset(struct gsi_fifo_buf *fb)
{
	return (_gsi_fifo_get_tail_idx(fb) * fb->rec_size);
}

static inline u32 _gsi_fifo_get_head_idx(struct gsi_fifo_buf *fb)
{
	return (gsi_atomic32_get(&fb->counters.rd) & fb->size_mask);
}

static inline u32 _gsi_fifo_get_head_offset(struct gsi_fifo_buf *fb)
{
	return (_gsi_fifo_get_head_idx(fb) * fb->rec_size);
}

static inline u32  gsi_fifo_buf_size(struct gsi_fifo_buf *fb)
{
	return (fb->size_mask + 1);
}

static inline u32 gsi_fifo_buf_count(struct gsi_fifo_buf *fb)
{
	union gsi_fifo_rwcounters rwcount;
	rwcount.rw.val = gsi_atomic64_get(&fb->counters.rw);
	u32 count = rwcount.wr.val - rwcount.rd.val;
#ifndef GSI_LIBSYS_ARCHS36
	GSI_ASSERT(count <= gsi_fifo_buf_size(fb));
#endif
	return count;
}

static inline uint gsi_fifo_buf_avail(struct gsi_fifo_buf *fb)
{
	return (gsi_fifo_buf_size(fb) - gsi_fifo_buf_count(fb));
}

static inline bool gsi_fifo_buf_is_empty(struct gsi_fifo_buf *fb)
{
	return gsi_fifo_buf_count(fb) == 0;
}

static inline bool gsi_fifo_buf_is_full(struct gsi_fifo_buf *fb)
{
	return gsi_fifo_buf_count(fb) > fb->size_mask;
}

static inline void *gsi_fifo_buf_tail(struct gsi_fifo_buf *fb)
{
	return (byte *)(!gsi_fifo_buf_is_full(fb) ? (byte *)&fb->buf[_gsi_fifo_get_tail_offset(fb)] : NULL);
}

static inline void *gsi_fifo_buf_head(struct gsi_fifo_buf *fb)
{
	return (byte *)(!gsi_fifo_buf_is_empty(fb) ? &fb->buf[ _gsi_fifo_get_head_offset(fb) ] : NULL);
}

/*
 * Initialize @fb
 *
 * @max_count is the maximum number of records to allocate in buffer
 * @rec_size is a fixed record size
 * @buf is a buffer holding @max_count records of @rec_size each
 */
extern gsi_status_t gsi_fifo_buf_init(struct gsi_fifo_buf *fb, uint max_count, u32 rec_size, void *data);
extern gsi_status_t gsi_fifo_buf_init_and_alloc_data(struct gsi_fifo_buf *fb, uint max_count, u32 rec_size);
extern void gsi_fifo_buf_free_data(struct gsi_fifo_buf *fb);

/*
 * Enqueue a record into @fb
 *
 * If @rec is not null, copy record into @fb->tail
 * Advance @fb->tail
 *
 * Return error if @fb is full
 * Otherwise return next @fb->tail address or NULL is fifo filled up
 */
extern void *gsi_fifo_buf_enqueue(struct gsi_fifo_buf *fb, void *rec);

/*
 * Dequeue a record from @fb
 *
 * If @rec is not null, copy @fb->head into @rec
 * Advance @fb->head
 *
 * Return error if @fb is empty
 * Otherwise return next @fb->head address or NULL is fifo emptied out
 */
extern void *gsi_fifo_buf_dequeue(struct gsi_fifo_buf *fb, void *rec);

extern int gsi_fifo_buf_enqueue_n(struct gsi_fifo_buf *fifo, void *data, unsigned int num_elements);
extern int gsi_fifo_buf_dequeue_n(struct gsi_fifo_buf *fifo, void *data, unsigned int num_elements);

int gsi_fifo_buf_to_buf_n(struct gsi_fifo_buf *fifo_dest, struct gsi_fifo_buf *fifo_src, unsigned int num_elements);

// Remote Proxy managed fifo - a single control block managed an external array
// the control block is not public and it accessable via a proxy structure
//
//
//     Consumer
//   +----------+
//   | Proxy CB +---+
//   +----------+   |
//                  |
//              +------+  +-----+----+-----+-----+-----+-----+-----+-----+-----+
//              | CB   +->|     |    |     Array of Elements |     |     |     |
//              +------+  +-----+----+-----+-----+-----+-----+-----+-----+-----+
//                  |
//     Producer     |
//   +----------+   |
//   | Proxy CB +---+
//   +----------+
//
//

struct gsi_fifo_dev {
	volatile u32 *rmt_wcount; // remote in (real value)
	volatile u32 *rmt_rcount; // remote out (real value)
	struct gsi_fifo_buf fb;
};

extern gsi_status_t gsi_fifo_dev_init(struct gsi_fifo_dev *fdev, uint max_count, u32 rec_size, void *buf, volatile u32 *rmt_wcount, volatile u32 *rmt_rcount);

static inline void gsi_fifo_dev_producer_update_remote(struct gsi_fifo_dev *fdev)
{
	*fdev->rmt_wcount = gsi_atomic32_get(&fdev->fb.counters.wr);
}

static inline void gsi_fifo_dev_remote_update_producer(struct gsi_fifo_dev *fdev)
{
	gsi_atomic32_set(&fdev->fb.counters.rd, *fdev->rmt_rcount);
}

static inline void gsi_fifo_dev_consumer_update_remote(struct gsi_fifo_dev *fdev)

{
	*fdev->rmt_rcount = gsi_atomic32_get(&fdev->fb.counters.rd);
}

static inline void gsi_fifo_dev_remote_update_consumer(struct gsi_fifo_dev *fdev)
{
	gsi_atomic32_set(&fdev->fb.counters.wr, *fdev->rmt_wcount);
}

static inline uint gsi_fifo_dev_count(struct gsi_fifo_dev *fdev)
{
	return gsi_fifo_buf_count(&fdev->fb);
}

static inline bool gsi_fifo_dev_is_full(struct gsi_fifo_dev *fdev)
{
	/*
	 * is_full is used by the producer
	 * if the local producer control block don't about a free space,
	 * it reads the common remote reader counter to update its own,
	 * till that point there is no need to update the reader counter
	 * you may think of using event or procedure to wakeup/trigger the consumer
	 * but there no data integrity issue
	 */
	if (gsi_fifo_buf_is_full(&fdev->fb))
		gsi_fifo_dev_remote_update_producer(fdev);
	return gsi_fifo_buf_is_full(&fdev->fb);
}

static inline bool gsi_fifo_dev_is_empty(struct gsi_fifo_dev *fdev)
{
	/*
	 * is_full is used by the consumer
	 * if the local consumer control block is not aware of new data,
	 * it reads the common remote writer counter to update its own,
	 * till that point there is no need to update the reader counter
	 * you may think of using event or procedure to wakeup/trigger the consumer
	 * but there no data integrity issue
	 */
	if (gsi_fifo_buf_is_empty(&fdev->fb))
		gsi_fifo_dev_remote_update_consumer(fdev);
	return gsi_fifo_buf_is_empty(&fdev->fb);
}

static inline void *gsi_fifo_dev_dequeue(struct gsi_fifo_dev *fdev, void *rec)
{
	void *ret = NULL;
	if (GSI_IS_ERR_PTR(ret = gsi_fifo_buf_dequeue(&fdev->fb, rec))) {
		gsi_fifo_dev_remote_update_consumer(fdev);
		ret = gsi_fifo_buf_dequeue(&fdev->fb, rec);
	}

	gsi_fifo_dev_consumer_update_remote(fdev);

	return ret;
}

static inline void *gsi_fifo_dev_enqueue(struct gsi_fifo_dev *fdev, void *rec)

{
	void *ret = NULL;;
	if (GSI_IS_ERR_PTR(ret = gsi_fifo_buf_enqueue(&fdev->fb, rec))) {
		gsi_fifo_dev_remote_update_producer(fdev);
		ret = gsi_fifo_buf_enqueue(&fdev->fb, rec);
	}
	gsi_fifo_dev_producer_update_remote(fdev);

	return ret;
}

static inline int gsi_fifo_dev_enqueue_n(struct gsi_fifo_dev *fdev, void *data, unsigned int num_elements)
{
	int n = gsi_fifo_buf_enqueue_n(&fdev->fb, data, num_elements);
	if (!n)
		gsi_fifo_dev_remote_update_producer(fdev);
	else
		gsi_fifo_dev_producer_update_remote(fdev);
	return n;
}

static inline int gsi_fifo_dev_dequeue_n(struct gsi_fifo_dev *fdev, void *data, unsigned int num_elements)
{
	int n = gsi_fifo_buf_dequeue_n(&fdev->fb, data, num_elements);
	if (!n)
		gsi_fifo_dev_remote_update_consumer(fdev);
	else
		gsi_fifo_dev_consumer_update_remote(fdev);
	return n;
}

#if defined(GSI_LIBSYS_AARCH64)
/*
 *  gsi_fifo_dev_dequeue_n_to_file - dequeue n elements from the buffer to a file descriptor.
 *
 *  Input:
 *  	@struct gsi_fifo_dev *fdev - proxy buffer control block.
 *  	@int fd - file descriptor.
 *  	@unsigned int max_num_elements - number of total elements in the buffer(the number that the buffer was initialized)
 *
 *  output:
 *  	@struct gsi_fifo_dev *fdev - proxy buffer control block.
 *
 *  return value:
 *  	@if write to stderr - 0
 *  	@if write to log file - number of dequeue elements and the length of the time stamp string
 *
 */
static inline int gsi_fifo_dev_dequeue_n_to_file(struct gsi_fifo_dev *fdev, int fd, unsigned int max_num_elements)
{
	struct gsi_fifo_buf *fifo = &fdev->fb;
	u32 num_of_elements = gsi_fifo_buf_count(fifo); //number of elements to read from the buffer
	u32 out_idx, first, second;

	num_of_elements = ((num_of_elements > max_num_elements) ? max_num_elements : num_of_elements);
	if (!num_of_elements) {
		gsi_fifo_dev_remote_update_consumer(fdev); //get update from the proxy buffer if there is byte to write in the next call to gsi_fifo_dev_dequeue_n_to_file() function
		return 0;
	}

	struct timespec ts;
	char time_buff[100];

	timespec_get(&ts, TIME_UTC);
	strftime(time_buff, sizeof(time_buff), "%D %T", gmtime(&ts.tv_sec));
	int time_len = dprintf(fd, "\nTIME STAMP: %s.%09ld UTC\n", time_buff, ts.tv_nsec);

	/*
	 * out_idx - index of the first index to read
	 * first - number of elemnets to copy from the buffer if not wrap around
	 * second - number of elemnets to copy from the buffer if wrap around
	*/
	out_idx = _gsi_fifo_get_head_idx(fifo);
	first = gsi_fifo_buf_size(fifo) - out_idx;
	second = num_of_elements;
	if (second < first) { // if no wrap around at the end of the buffer
		first = second;
		second = 0;
	} else { // if wrap around at the end of the buffer
		second = num_of_elements - first;
	}

	/*
	 * if write data to directly to stderr return 0.
	 * there is no need to accumulate the bytes was written when the write is to stderr
	 * add the written bytes to the buffer counter
	 * update the proxy buffer with the written bytes
	 */
	if (fd == STDERR_FILENO) {
		write(fd, (u8 *)&fifo->buf[fifo->rec_size * out_idx], fifo->rec_size * first);
		if (second) //wrap around has occured
			write(fd, (void *)fifo->buf, fifo->rec_size * second);

		gsi_atomic32_add(&fifo->counters.rd, num_of_elements);
		gsi_fifo_dev_consumer_update_remote(fdev);

		return 0;

	/*
	 * write the data to allocated buffer and then write the buffer to the log file (there was a problem write directly to file).
	 * add the written bytes to the buffer counter.
	 * update the proxy buffer with the written bytes.
	 */
	} else {
		void *log_buff = malloc(num_of_elements); //MAX 128KB
		if (log_buff == 0)
			return 0;

		if (num_of_elements > (100 * 1024)) {
			write(fd, "Alloc > 100KB\n",13);
		}

		memcpy(log_buff, (u8 *)&fifo->buf[fifo->rec_size * out_idx], fifo->rec_size * first);
		if (second) //wrap around has occured
			memcpy(log_buff, (void *)fifo->buf, fifo->rec_size * second);

		write(fd, log_buff, num_of_elements);

		free(log_buff);

		gsi_atomic32_add(&fifo->counters.rd, num_of_elements);
		gsi_fifo_dev_consumer_update_remote(fdev);

		return (int)num_of_elements + time_len;
	}
}

#endif /* defined(GSI_LIBSYS_AARCH64) */
//#endif /* supprter ARCH's */

#endif /* GSI_BUF_H */
