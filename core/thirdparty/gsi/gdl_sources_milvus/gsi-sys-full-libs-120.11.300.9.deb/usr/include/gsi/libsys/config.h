/*
 * Copyright (C) 2016, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */
#ifndef GSI_LIBSYS_CONFIG_H
#define GSI_LIBSYS_CONFIG_H

#ifndef PAGE_SIZE
#define PAGE_SIZE (4096)
#endif

#if defined(GSI_LIBSYS_X86_32_NOSTDLIB) || defined(GSI_LIBSYS_ARCHS36)
#define GSI_LIBSYS_NOSTDLIB
#endif

#ifndef CACHE_LINE_SIZE
#define CACHE_LINE_SIZE (32)
#endif

#endif /* GSI_LIBSYS_CONFIG_H */
