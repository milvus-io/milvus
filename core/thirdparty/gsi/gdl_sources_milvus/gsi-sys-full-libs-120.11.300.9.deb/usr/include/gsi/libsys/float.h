/*
 * Copyright (C) 2016, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */
#include <gsi/libsys/config.h>

#ifndef GSI_FLOAT_H
#define GSI_FLOAT_H

#include <gsi/common_api.h>
#include <stdbool.h>

bool gsi_is_inf_float(float fl);
bool gsi_is_nan_float(float fl);

gsi_prod_fp16_t gsi_float_2_gfloat16(float fl);
float gsi_gfloat16_2_float(gsi_prod_fp16_t fl);

gsi_prod_fp16_t gsi_float_2_float16(float fl);
float gsi_float16_2_float(gsi_prod_fp16_t fl);
gsi_prod_fp16_t gsi_float16_2_gfloat16(gsi_prod_fp16_t fl);
gsi_prod_fp16_t gsi_gfloat16_2_float16(gsi_prod_fp16_t fl);

gsi_prod_fp16_t gsi_float16_mul(gsi_prod_fp16_t src0, gsi_prod_fp16_t src1);
gsi_prod_fp16_t gsi_float16_add(gsi_prod_fp16_t src0, gsi_prod_fp16_t src1);
gsi_prod_fp16_t gsi_float16_sub(gsi_prod_fp16_t src0, gsi_prod_fp16_t src1);

gsi_prod_fp16_t gsi_gfloat16_mul(gsi_prod_fp16_t src0, gsi_prod_fp16_t src1);
gsi_prod_fp16_t gsi_gfloat16_add(gsi_prod_fp16_t src0, gsi_prod_fp16_t src1);
gsi_prod_fp16_t gsi_gfloat16_add_debug(gsi_prod_fp16_t src0, gsi_prod_fp16_t src1);
gsi_prod_fp16_t gsi_gfloat16_sub(gsi_prod_fp16_t src0, gsi_prod_fp16_t src1);
gsi_prod_fp16_t gsi_gfloat16_sub_debug(gsi_prod_fp16_t src0, gsi_prod_fp16_t src1);
gsi_prod_fp16_t gsi_rand16_2_gfloat16(u16 random_16);
bool gsi_gfloat16_is_valid(gsi_prod_fp16_t gfl);

static inline gsi_prod_fp32_t gsi_float_2_float32(float fl)
{
	return (gsi_prod_fp32_t)fl;
}

static inline double gsi_float64_2_double(gsi_prod_fp64_t fl)
{
	return (double)fl;
}

static inline gsi_prod_fp64_t gsi_double_2_float64(double fl)
{
	return (gsi_prod_fp64_t)fl;
}

static inline float gsi_float32_2_float(gsi_prod_fp32_t fl)
{
	return (float)fl;
}

static inline float gsi_prod_float32_2_float(gsi_prod_fp32_t *fl)
{
	return (*(float *)(fl));
}

static inline gsi_prod_fp32_t gsi_float_2_prod_float32(float *fl)
{
	return (*(gsi_prod_fp32_t *)(fl));
}

static inline double gsi_prod_float64_2_float(gsi_prod_fp64_t *fl)
{
	return (*(double *)(fl));
}

static inline gsi_prod_fp64_t gsi_float_2_prod_float64(double *fl)
{
	return (*(gsi_prod_fp64_t *)(fl));
}

static inline bool gsi_is_nan_float16(gsi_prod_fp16_t fl)
{
	return (((fl & 0x7C00) == 0x7C00) && !!(fl & 0x3FF));
}

static inline bool gsi_is_nan_gfloat16(gsi_prod_fp16_t fl)
{
	return ((fl & 0x7FFF) == 0x7FFF);
}

static inline gsi_prod_uint16_t gsi_monotonic_transformation_nan2max_float16_2_u16(gsi_prod_fp16_t fl)
{
	u16 u = (fl & 0x8000) ? (fl ^ 0xffff) : (fl ^ 0x8000);
	u = gsi_is_nan_float16(fl) ? 0xffff : u;
	return u;
}

static inline gsi_prod_uint16_t gsi_monotonic_transformation_nan2zero_float16_2_u16(gsi_prod_fp16_t fl)
{
	u16 u = (fl & 0x8000) ? (fl ^ 0xffff) : (fl ^ 0x8000);
	u = gsi_is_nan_float16(fl) ? 0 : u;
	return u;
}

static inline gsi_prod_fp16_t gsi_inv_monotonic_transformation_float16_2_u16(gsi_prod_uint16_t u)
{
	return u & 0x8000 ? u ^ 0x8000 : u ^ 0xffff;
}

static inline bool gsi_is_gfloat16_zero(gsi_prod_fp16_t fl)
{
	return 0 == (fl & 0x7E00);
}

static inline gsi_prod_uint16_t gsi_monotonic_transformation_nan2max_gfloat16_2_u16(gsi_prod_fp16_t fl)
{
	fl = gsi_is_gfloat16_zero(fl) ? 0 : fl;
	u16 u = (fl & 0x8000) ? (fl ^ 0xffff) : (fl ^ 0x8000);
	u = gsi_is_nan_gfloat16(fl) ? 0xffff : u;
	return u;
}

static inline gsi_prod_uint16_t gsi_monotonic_transformation_nan2zero_gfloat16_2_u16(gsi_prod_fp16_t fl)
{
	fl = gsi_is_gfloat16_zero(fl) ? 0 : fl;
	u16 u = (fl & 0x8000) ? (fl ^ 0xffff) : (fl ^ 0x8000);
	u = gsi_is_nan_gfloat16(fl) ? 0 : u;
	return u;
}

static inline gsi_prod_fp16_t gsi_inv_monotonic_transformation_gfloat16_2_u16(gsi_prod_uint16_t u)
{
	return gsi_inv_monotonic_transformation_float16_2_u16(u);
}

#endif /* GSI_FLOAT_H */
