/*
 * Copyright (C) 2016, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */

#ifndef GSI_TYPES_H
#define GSI_TYPES_H

#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>

#if !defined(__ssize_t_defined) && !defined(__SSIZE_T_TYPE) && !defined(_SSIZE_T_DEFINED)
typedef long ssize_t;
#define __ssize_t_defined
#endif

/*
 * use the following generic types:
 *
 * bool | bit
 * char, uchar | unsigned char | byte (prefer u8 for numeric bytes)
 * short, ushort | unsigned short
 * int, uint | unsigned
 * long, ulong | unsigned long (OK to assume that pointer size is sizeof(ulong))
 * long long, unsigned long long
 * float | double
 *
 * strings type are char *, use const where appropriate
 */

/*
 * use the following bit-length types:
 *
 * s8 | u8
 * s16 | u16
 * s32 | u32
 * s64 | u64
 */

#ifndef __cplusplus
#define bool _Bool
#endif
typedef bool bit;
typedef uint8_t byte;
typedef  int8_t s8;
typedef uint8_t u8;
typedef  int16_t s16;
typedef uint16_t u16;
typedef  int32_t s32;
typedef uint32_t u32;
typedef  int64_t s64;
typedef uint64_t u64;

typedef unsigned int uint;

typedef int gsi_status_t;

#define GSI_BITS_PER_BYTE	8

#define ARRAY_SIZE(x)	(sizeof(x) / sizeof(x[0]))

#define _DIV_ROUND_DOWN_NUM(x, n)	((x) / (n))
#define _DIV_ROUND_UP_NUM(x, n)		_DIV_ROUND_DOWN_NUM((x) + (n) - 1, (n))

#ifdef DEBUG_BUILD
#define DIV_ROUND_DOWN_NUM(x, n)	(GSI_ASSERT_ERROR((n) > 0) ? _DIV_ROUND_DOWN_NUM(x, n) : (gsi_assert_failed(), 0))
#else
#define DIV_ROUND_DOWN_NUM(x, n)	_DIV_ROUND_DOWN_NUM(x, n)
#endif
#define DIV_ROUND_UP_NUM(x, n)		DIV_ROUND_DOWN_NUM((x) + (n) - 1, (n))

#define ALIGN_NUM(x, n)		((n) * DIV_ROUND_UP_NUM((x), (n)))
#define ALIGN_DOWN_MASK(x, m)	((x) & ~(m))
#define ALIGN_DOWN_POW2(x, n)	ALIGN_DOWN_MASK(x, (n) - 1)
#define ALIGN_MASK(x, m)	ALIGN_DOWN_MASK((x) + (m), (m))
#define ALIGN_POW2(x, n)	ALIGN_MASK(x, (n) - 1)

#ifndef MAX
#define MAX(a, b)		((a) >= (b) ? (a) : (b))
#define MIN(a, b)		((a) <= (b) ? (a) : (b))
#endif

static inline bool gsi_is_pow2(u32 val)
{
	return (val != 0 && (val & (val - 1)) == 0);
}

#ifdef __GNUC__

#ifndef likely
#define likely(x)       __builtin_expect((x),true)
#define unlikely(x)     __builtin_expect((x),false)
#endif

#define GSI_UNUSED(_param_)	_param_ __attribute__((unused))

#ifdef DEBUG_BUILD
#define GSI_RELEASE_UNUSED(_param_)	_param_
#else
#define GSI_RELEASE_UNUSED(_param_)	GSI_UNUSED(_param_)
#endif

#ifndef offsetof
#define offsetof(type, member)  __builtin_offsetof (type, member)
#endif

#define GSI_PACKED	__attribute__ ((packed))

#define GSI_ALIGNED(_nbytes_)	__attribute__ ((aligned (_nbytes_)))

#else  /* _GNU_SOURCE */

#ifndef likely
#define likely(x)       (x)
#define unlikely(x)     (x)
#endif

#define GSI_UNUSED(_param_)	/* _param_ */

#define GSI_PACKED	/* not implemented yet */

#ifndef ALIGNED
#define GSI_ALIGNED(n)	/* not implemented yet */
#endif

#endif /* _GNU_SOURCE */

#define container_of(ptr, type, member) ({ \
	const typeof( ((type *)0)->member ) *__mptr = (ptr); \
	(type *)(void *)( (char *)__mptr - offsetof(type,member) );})

#ifndef NULL
#define NULL	((void *)0)
#endif

#endif /* GSI_TYPES_H */
