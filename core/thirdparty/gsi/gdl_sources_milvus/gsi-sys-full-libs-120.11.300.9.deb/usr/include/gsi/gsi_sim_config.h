/*
 * Copyright (C) 2019, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */

#ifndef GSI_SIM_CONFIG_H
#define GSI_SIM_CONFIG_H

#ifdef __cplusplus
extern "C" {
#endif

enum {
	GSI_SIM_MAX_SIM_CONTEXTS = 4,
	GSI_SIM_MAX_SIM_APUS = 8,
	GSI_SIM_MAX_SIM_APUCS_PER_APU = 4,
};

struct gsi_sim_contexts {
	unsigned long long mem_size;
	unsigned int apu_count;
	unsigned int apucs_per_apu;
};

/*
 * gsi_sim_create_simulator -  initialize the gsi simulator
 *
 * Input:
 *   @num_ctxs - number of contexts to be created for the current simulation
 *   @gsi_sim_contexts - a struct describing the contexts properties for the current simulation
 *
 *
 * Return value:
 * 	  = 0 - OK.
 *   != 0 - error code
 *
 * Comments:
 *	incase the function is called when running on hardware the error code ENOSYS will be returned
 */
int gsi_sim_create_simulator(unsigned int num_ctxs, struct gsi_sim_contexts *ctxs);

/*
 * gsi_sim_destroy_simulator -  shuts down the current gsi simulator
 *
 *
 * Return value:
 * 	  = 0 - OK.
 *   != 0 - error code
 *
 * Comments:
 *	incase the function is called when running on hardware the error code ENOSYS will be returned
 */
int gsi_sim_destroy_simulator(void);

/*
 * gsi_sim_is_simulator -  check whether the application is in simulator or hardware
 *
 * Return value:
 * 	 = 1 - true
 *   = 0 - false
 *
 * Comments:
 *	incase the function is called when running on hardware the error code ENOSYS will be returned
 */
unsigned int gsi_sim_is_simulator(void);

/*
 * gsi_sim_get_default_mem -  get the default system memory size for simulator
 *
 * Return value:
 * 	the default memory size for simulator
 *
 */
long gsi_sim_get_default_mem_size(void);

#ifdef __cplusplus
}
#endif

#endif /* GSI_SIM_CONFIG_H */
