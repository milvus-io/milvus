/*
 * Copyright (C) 2016, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */
#ifdef	__cplusplus
extern "C" {
#endif

#ifndef GSI_MEM_H
#define GSI_MEM_H

// #include "config.h"

#if defined(GSI_LIBSYS_AARCH64) || defined(GSI_LIBSYS_X86_64) || defined(GSI_LIBSYS_X86_32)

#ifdef _BUILD_OS_GNU_LINUX
#include <sys/user.h>
#endif

#include <stdlib.h>
#include <string.h>

#include "error.h"

static inline void *gsi_alloc_ret_ptr(void *p)
{
	if (likely(p != NULL)) {
#ifdef DEBUG_BUILD
		if (GSI_IS_ERR_PTR(p))
			gsi_fatal("p=%p: is an error ptr", p);
#endif
		return p;
	} else
		return GSI_ERR_TO_PTR(-ENOMEM);
}

static inline void *gsi_malloc(size_t size)
{
	return gsi_alloc_ret_ptr(malloc(size));
}

static inline void *gsi_calloc(size_t nelem, size_t elem_size)
{
	return gsi_alloc_ret_ptr(calloc(nelem, elem_size));
}

static inline void *gsi_zalloc(size_t size)
{
	return gsi_calloc(1, size);
}

static inline void *gsi_aligned_alloc(size_t alignment, size_t size)
{
	return alignment ? gsi_alloc_ret_ptr(aligned_alloc(alignment, size)) : gsi_malloc(size);
}

static inline void *gsi_aligned_zalloc(size_t alignment, size_t size)
{
	void *p;

	if (!alignment)
		return gsi_zalloc(size);

	p = aligned_alloc(alignment, size);
	if (unlikely(p == NULL))
		return GSI_ERR_TO_PTR(-ENOMEM);

	return memset(p, 0, size);
}

static inline void *gsi_realloc(void *old, size_t new_size)
{
	return gsi_alloc_ret_ptr(realloc(old, new_size));
}

static inline void *gsi_zrealloc(void *old, size_t old_size, size_t new_size)
{
	void *p;

	if (!old)
		return gsi_zalloc(new_size);

	if (new_size <= old_size)
		return gsi_realloc(old, new_size);

	p = realloc(old, new_size);
	if (unlikely(p == NULL)) {
		return GSI_ERR_TO_PTR(-ENOMEM);
	}

	memset((char *)p + old_size, 0, new_size - old_size);
	return p;
}

static inline void gsi_free(const void *p)
{
	if (p != NULL) {
		GSI_ASSERT(!GSI_IS_ERR_PTR(p));
		free((void *)p);
	}
}

static inline void gsi_free_any(const void *p)
{
	if (!GSI_IS_ERR_PTR_OR_NULL(p))
		gsi_free(p);
}

static inline void *gsi_memdup(const void *s, size_t size)
{
	char *ret;

	if (unlikely(s == NULL))
		return NULL;

	ret = (char *)gsi_malloc(size);
	if (!GSI_IS_ERR_PTR_OR_NULL(ret))
		memcpy(ret, s, size);
	return ret;
}

static inline char *gsi_strdup(const char *s)
{
	if (unlikely(s == NULL))
		return NULL;

	return (char *)gsi_memdup(s, strlen(s) + 1);
}

struct gsi_rpool;

struct gsi_rpool *gsi_rpool_create(void *region, size_t region_size);
int gsi_rpool_destroy(struct gsi_rpool *pool, bool check_leak);
int gsi_rpool_check_leak(struct gsi_rpool *pool, bool fatal_leak);
void *_gsi_rpool_alloc(struct gsi_rpool *pool, size_t bytes);
void _gsi_rpool_free(struct gsi_rpool *pool, void *mem);

#ifndef DEBUG_BUILD

#define gsi_rpool_alloc _gsi_rpool_alloc
#define gsi_rpool_free _gsi_rpool_free

#else  /* !DEBUG_BUILD */

void *_gsi_rpool_alloc_debug(struct gsi_rpool *pool, size_t bytes, const char *file, int line);
void _gsi_rpool_free_debug(struct gsi_rpool *pool, void *mem, const char *file, int line);

#define gsi_rpool_alloc(_pool_, _bytes_)	_gsi_rpool_alloc_debug(_pool_, _bytes_, __FILE__, __LINE__)
#define gsi_rpool_free(_pool_, _mem_)		_gsi_rpool_free_debug(_pool_, _mem_, __FILE__, __LINE__)
#endif /* !DEBUG_BUILD */

/*
 * mem_cache
 *
 * Optimize fixed-size record allocation
 */
struct gsi_mem_cache;

extern struct gsi_mem_cache *gsi_mem_cache_create(size_t rec_size, size_t num_init_recs, bool allow_overflow);
extern void gsi_mem_cache_destroy(struct gsi_mem_cache *mc);
extern void *gsi_mem_cache_alloc(struct gsi_mem_cache *mc);
extern void *gsi_mem_cache_zalloc(struct gsi_mem_cache *mc);
extern void gsi_mem_cache_free(struct gsi_mem_cache *mc, void *rec);
extern void gsi_mem_cache_pack(struct gsi_mem_cache *mc);
extern void *gsi_mem_cache_alloc_wait(struct gsi_mem_cache *mc, void *cond, bool do_zero);
extern void gsi_mem_cache_free_signal(struct gsi_mem_cache *mc, void *rec, void *cond, bool broadcast);

void gsi_libsys_mem_cache_init(void);
void gsi_libsys_mem_cache_exit(void);

#endif /* defined(GSI_LIBSYS_AARCH64) || defined(GSI_LIBSYS_X86_64) || defined(GSI_LIBSYS_X86_32) */

#endif /* GSI_MEM_H */

#ifdef	__cplusplus
}
#endif
