/*
 * Copyright (C) 2016, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */
#include "config.h"

#if defined(GSI_LIBSYS_X86_64) || defined(GSI_LIBSYS_X86_32)

#ifndef GSI_HISTOGRAM_H
#define GSI_HISTOGRAM_H

#include <stdio.h>

#include "hash.h"

struct gsi_histogram_tally {
	uintptr_t key;
	uintptr_t count;
};

struct gsi_histogram {
	struct gsi_hash_table htab;
	size_t total_count;
};

static inline void gsi_histogram_init(struct gsi_histogram *hist)
{
	gsi_ikvhash_init(&hist->htab);
	hist->total_count = 0;
}

static inline void gsi_histogram_destroy(struct gsi_histogram *hist)
{
	gsi_ikvhash_destroy(&hist->htab);
}

static inline size_t gsi_histogram_num_items(struct gsi_histogram *hist)
{
	return gsi_ikvhash_num_items(&hist->htab);
}

static inline size_t gsi_histogram_total_count(struct gsi_histogram *hist)
{
	return hist->total_count;
}

static inline size_t gsi_histogram_foreach(struct gsi_histogram *hist, gsi_ikvhash_iter_func *iter_func, void *priv)
{
	return gsi_ikvhash_foreach(&hist->htab, iter_func, priv);
}

uintptr_t gsi_histogram_count_key(struct gsi_histogram *hist, uintptr_t key);

size_t gsi_histogram_to_array(struct gsi_histogram *hist, struct gsi_histogram_tally *a, size_t max_count);

enum {
	GSI_HISTOGRAM_SORT_BY_MASK =	(1 << 1),
	GSI_HISTOGRAM_SORT_BY_COUNT =	0,
	GSI_HISTOGRAM_SORT_BY_KEY =	GSI_HISTOGRAM_SORT_BY_MASK,

	GSI_HISTOGRAM_SORT_ORDER_MASK =	(1 << 2),
	GSI_HISTOGRAM_SORT_DESCENDING =	0,
	GSI_HISTOGRAM_SORT_ASCENDING =	GSI_HISTOGRAM_SORT_ORDER_MASK,
};

size_t gsi_histogram_to_array_sorted(struct gsi_histogram *hist, struct gsi_histogram_tally *a, size_t max_count, ulong flags);

gsi_status_t gsi_histogram_dump(FILE *, struct gsi_histogram *hist, const char *name, ulong sort_flags, const char *key_fmt);

#endif /* GSI_HISTOGRAM_H */

#endif /* defined(GSI_LIBSYS_X86_64) || defined(GSI_LIBSYS_X86_32) */
