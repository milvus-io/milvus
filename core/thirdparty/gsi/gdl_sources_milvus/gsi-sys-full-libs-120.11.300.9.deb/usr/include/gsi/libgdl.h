/*
 *
 * The GSI Device Library (GDL) API provides a host interface to enable the building 
 * and running user tasks on the APU board. This API allows communication 
 * between the host (the server where the APU is installed) and the device (the APU board). 
 * 
 * Copyright (C) 2019, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 * 
 * 
 */

#ifndef GSI_LIBGDL_H
#define GSI_LIBGDL_H

#ifdef __cplusplus
extern "C" {
#endif

#include <gsi/common_api.h>
#include <stdint.h>

#define GDL_TEMPORARY_DEFAULT_CTX_ID 0
#define GDL_TEMPORARY_DEFAULT_MEM_BUF NULL
#define GDL_TEMPORARY_DEFAULT_MEM_BUF_SIZE 0
#define GDL_TEMPORARY_DEFAULT_CORE_INDEX 0
#define GDL_MAX_NUM_CONTEXTS GSI_DRV_MAX_BOARDS
#define GDL_MAX_DEVICE_NAME_LENGTH 64
#define GDL_DMA_CPY_OPTIMIZED_ALIGNMENT PAGE_SIZE

typedef uintptr_t gdl_context_handle_t;
typedef uintptr_t gdl_mem_handle_t;

typedef enum {
	GDL_USER_MAPPING,
}gdl_mapping_type;

typedef enum {
	GDL_TASK_GENERAL_ERROR,
	GDL_TASK_COMPLETED,
	GDL_TASK_TIMEDOUT,
	GDL_TASK_DMA_ERROR,
	GDL_TASK_BUS_ERROR,
	GDL_TASK_KFAULT_ERROR,
	GDL_TASK_TEMPERATURE_ERROR,
	GDL_TASK_UBUS_ERROR,
}gdl_task_comp_status;

typedef enum {
	GDL_CONTEXT_READY,
	GDL_CONTEXT_BUSY,
	GDL_CONTEXT_INVALID,
}gdl_context_status_t;

typedef enum {
	GDL_CONTEXT_MEM_SIZE,
	GDL_CONTEXT_NUM_APUCS,
	GDL_CONTEXT_STATUS,
	GDL_CONTEXT_NUM_APUS,
	GDL_CONTEXT_HW_GENERAL_INFO,
}gdl_context_property_t;

typedef enum {
	GDL_CONST_MAPPED_POOL,
	GDL_DYNAMIC_MAPPED_POOL,
}gdl_mem_pools;

typedef enum {
	GDL_ALIGN_16 = 3,
	GDL_ALIGN_32,
	GDL_ALIGN_64,
	GDL_ALIGN_128,
	GDL_ALIGN_256,
	GDL_ALIGN_512,
	GDL_ALIGN_1024,
	GDL_ALIGN_2048,
	GDL_ALIGN_4096,
	GDL_ALIGN_8192,
	GDL_ALIGN_16384,
	GDL_ALIGN_32768,
}gdl_alloc_alignment;

typedef enum {
	GDL_HW_INFO_FREQUENCY_BITS 				= 0,
	GDL_HW_INFO_INDIRECT_READ_BIT  			= 5,
	GDL_HW_INFO_INDIRECT_WRITE_BIT			= 6,
}gdl_hw_general_info_bits;

typedef enum {
	GDL_HW_INFO_FREQUENCY_MASK				= 0x7,
	GDL_HW_INFO_INDIRECT_READ_MASK 			= 1 << GDL_HW_INFO_INDIRECT_READ_BIT,
	GDL_HW_INFO_INDIRECT_WRITE_MASK 		= 1 << GDL_HW_INFO_INDIRECT_WRITE_BIT,
}gdl_hw_general_info_masks;

struct gdl_mem_buffer {
	gdl_mem_handle_t ptr;
	unsigned int size;
};

struct gdl_context_desc {
	char parent_device_name[GDL_MAX_DEVICE_NAME_LENGTH];
	gdl_context_handle_t ctx_id;
	unsigned int num_apucs;
	unsigned int num_apus;
	gdl_context_status_t status;
	unsigned long long  mem_size;
	unsigned int hw_general_info;				/* HW General Info Bits - 
													Bit[3:0] Freq:						(2:200 Mhz/3:300 Mhz /4:400 Mhz)
													Bit[5] Indirect Read: 				(0:Disabled/1:Enabled)
													Bit[6] Indirect Write:				(0:Disabled/1:Enabled)
												*/
};

/*
 * gdl_init - initializes the GSI device library.
 *
 * Return value:
 *   = 0 - OK.
 *   != 0 - error code
 *
 * Comments:
 *  gdl_init only needs to be called once, prior to using any GDL functions. However, if you
 *  call gdl_exit, call gdl_init again.
 *
 */
int gdl_init(void);


/*
 * gdl_exit - exits the GSI device library
 *
 * Return value:
 *   = 0 - OK.
 *   != 0 - error code
 *
 */
int gdl_exit(void);


/*
 * gdl_context_count_get - get the number of hardware contexts installed on the host. 
 *
 * Output:
 *   count - the number of contexts on the host.
 *
 * Return value:
 *   = 0 - OK.
 *   != 0 - error code
 *
 * 
 */
int gdl_context_count_get(unsigned int *count);


/*
 * gdl_context_desc_get - get information on the requested number of hardware contexts as specified by count.
 *
 * Input:
 *   @count - the number of contexts to receive information of.
 *
 * Output:
 *   ctx_desc - an array of the requested contexts descriptors.
 *
 * Return value:
 *   = 0 - OK.
 *   != 0 - error code
 */
int gdl_context_desc_get(struct gdl_context_desc *ctx_desc, unsigned int count);


/*
 * gdl_context_property_get - retrieves a specific property of a hardware context.
 *
 * Input:
 *   @ctx_handler - the requested hardware context id as specified in the gdl_context_desc structure.
 *   @property - the desired property to get from the hardware context. (according to -  gdl_context_property_t).
 *
 * Output:
 *   value - the value of the requested property of the hardware context.
 *
 * Return value:
 *   = 0 - OK.
 *   != 0 - error code
 */
int gdl_context_property_get(gdl_context_handle_t ctx_handler, gdl_context_property_t property, long *value);


/*
 *  gdl_context_alloc - allocates a specific hardware context to be used by the host.
 *
 * Input:
 *   @ctx_handler - the requested hardware context id as specified in the gdl_context_desc structure.
 *   @const_mapped_size_req - the requested size of the context constantly mapped memory region.
 *
 * Output:
 *   @const_mapped_size_recv - the actual given size of the context constantly mapped memory region
 * 	 @dynamic_mapped_size_recv - the actual given size of the context dynamically mapped memory region 
 * 
 * Return value:
 *   = 0 - OK.
 *   != 0 - error code
 *
 * Comments:
 * 					HW Context L4 Memory Overview:
 * 	     __________________________________________________________________________________________
 *		|           |                            |                                                 |
 *		|			|     min size - max size    |        min size  -            max size          |
 *		|			|  <--- ~220MB - ~3.75GB --->|		<---  0     - (total_L4_size - const_size) |
 *		| System	|                            |                                                 |
 *		|			|  Constantly Mapped	     |			dynamically Mapped 				       |
 *		| Reserved  |  Memory Region             |			Memory Region						   |
 *		|			| 		                     |												   |
 *		|			| 	                         |												   |
 *		|___________|____________________________|_________________________________________________|
 *
 * 	The HW context L4 Memory can be accessed by both the host and the apu, each individual task that runs on the hw context can view up to 3.75GB of the
 *  L4 Memory using an AT Table. The L4 is divided into two regions , the constantly mapped and the dynamically mapped.
 *  The constantly mapped memory region is the memory area that will be mapped for every task that runs on the specific hw context.
 *  The dynamically mapped memory region is mapped per task and can set the AT table to view different area's of the L4 ( see gdl_schedule_task & gdl_schedule_batch)
 *  
 *  The dynamic memory region size is calculated based on the requested size of the constantly mapped memory region.
 * 
 * Memory Allocation Overview:
 *	 MAX const memory size upto (~3.75GB) ( every size larger than this will be truncated)
 *   MIN const size  is ~220MB (every size smaller then 256MB than this will be aligned to ~220MB)
 *  
 *   In case const_mapped_size_recv or dynamic_mapped_size_recv is NULL then the default mapping for the context sets the constantly mapped region to ~3.75GB
 *   and the dynamically mapped region to 0.
 * 
 * If there is an unkown error with the requested context the fuction will timeout after 4 seconds of trying to allocate it.
 * in that case the returned error code will be -EAGAIN and the context will reset itself, afterwards the user can try and allocate the context again.
 * 
 * Only in the event of -EAGAIN the context will reset itself, any other error code should be handled by the user. 
 */

int gdl_context_alloc(gdl_context_handle_t ctx_handler,
						const unsigned long long const_mapped_size_req, 
						unsigned long long *const_mapped_size_recv, 
						unsigned long long *dynamic_mapped_size_recv);

/*
 * gdl_context_find_and_alloc - allocate the first available context that meets the required number of APUCs and a specific memory size. 
 *
 * Input:
 *   @apuc_count - the requested number of apuc.
 *	 @mem_size - the total memory size requested.
 *   @const_mapped_size_req - the requested size of the context constantly mapped memory region.
 * 
 * Output:
 *   handle - the id of the context that was allocated to host.
 *   @const_mapped_size_recv - the actual given size of the context constantly mapped memory region
 * 	 @dynamic_mapped_size_recv - the actual given size of the context dynamically mapped memory region 
 * 
 * Return value:
 *   = 0 - OK.
 *   != 0 - error code
 *
 * Comments:
 * 					HW Context L4 Memory Overview:
 * 	     __________________________________________________________________________________________
 *		|           |                            |                                                 |
 *		|			|     min size - max size    |        min size  -            max size          |
 *		|			|  <--- ~220MB - ~3.75GB --->|		<---  0     - (total_L4_size - const_size) |
 *		| System	|                            |                                                 |
 *		|			|  Constantly Mapped	     |			dynamically Mapped 				       |
 *		| Reserved  |  Memory Region             |			Memory Region						   |
 *		|			| 		                     |												   |
 *		|			| 	                         |												   |
 *		|___________|____________________________|_________________________________________________|
 *
 * 	The HW context L4 Memory can be accessed by both the host and the apu, each individual task that runs on the hw context can view up to 3.75GB of the
 *  L4 Memory using an AT Table. The L4 is divided into two regions , the constantly mapped and the dynamically mapped.
 *  The constantly mapped memory region is the memory area that will be mapped for every task that runs on the specific hw context.
 *  The dynamically mapped memory region is mapped per task and can set the AT table to view different area's of the L4 ( see gdl_schedule_task & gdl_schedule_batch)
 *  
 *  The dynamic memory region size is calculated based on the requested size of the constantly mapped memory region.
 * 
 * Memory Allocation Overview:
 *	 MAX const memory size upto (~3.75GB) ( every size larger than this will be truncated)
 *   MIN const size  is ~220MB (every size smaller then 256MB than this will be aligned to ~220MB)
 *  
 *   In case const_mapped_size_recv or dynamic_mapped_size_recv is NULL then the default mapping for the context sets the constantly mapped region to ~3.75GB
 *   and the dynamically mapped region to 0.
 * 
 * If there is an unkown error with the requested context the fuction will timeout after 4 seconds of trying to allocate it.
 * in that case the returned error code will be -EAGAIN and the context will reset itself, afterwards the user can try and allocate the context again.
 * 
 * Only in the event of -EAGAIN the context will reset itself, any other error code should be handled by the user. 
 */
int gdl_context_find_and_alloc(const unsigned int num_apucs,
								const unsigned long long mem_size, 
								const unsigned long long const_mapped_size_req, 
								unsigned long long *const_mapped_size_recv, 
								unsigned long long *dynamic_mapped_size_recv, 
								gdl_context_handle_t *handle);


/*
 * gdl_context_free - free an allocated context.
 *
 * Input:
 *   @ctx_handler - the ID of the context previously allocated
 *
 *
 * Return value:
 *   = 0 - OK.
 *   != 0 - error code
 *
 */
int gdl_context_free(gdl_context_handle_t ctx_handler);


/*
 * gdl_context_free_and_reset - free an allocated context and reset the device.
 *
 * Input:
 *   @ctx_handler - the ID of the context previously allocated
 *
 *
 * Return value:
 *   = 0 - OK.
 *   != 0 - error code
 *
 * Comments:
 *  After calling this function the context will reset itself. 
 *  The function will return to the user after the context has finished resetting itself (may take approximately 4 seconds).
 *  In case the function returns successfully the user can try and allocate the context again.
 * 
 *  When calling this function there is no need to call "gdl_context_free(...)"
 * 	
 */
int gdl_context_free_and_reset(gdl_context_handle_t ctx_handler);

/*
 * gdl_mem_alloc_aligned - allocates number of bytes whose alignment is specified by alignment, in the given memory pool of the context, 
 *
 * Input:
 *   @ctx_handler - the requested hw context to allocate from.
 *   @size - number of bytes to allocate in the memory region. ( size is aligned up to a multiply of 16)
 *   @alignment - specifies the alignment as shown in gdl_alloc_alignment enum.
 *	 @pool - the requested memory pool to allocate the memory on.
 *
 * Return value:
 *   a handle to the given context memory
 *
 * Comments:
 *   handle returned as null if failed to allocate memory.
 */

#define gdl_mem_alloc_aligned(ctx_handler, size, pool, alignment)			_gdl_mem_alloc_aligned(ctx_handler, size, pool, alignment, __FILE__, __LINE__)
gdl_mem_handle_t _gdl_mem_alloc_aligned(gdl_context_handle_t ctx_handler, unsigned long long size, gdl_mem_pools pool, gdl_alloc_alignment alignment, const char *file, int line);

/*
 * gdl_mem_alloc - allocate a number of bytes requested in the given memory pool of the specified context.
 *
 * Input:
 *   @ctx_handler - the requested hw context to allocate from.
 *   @size - number of bytes to allocate in the memory region. ( size is aligned up to a multiply of 16)
 *	 @pool - the requested memory pool to allocate the memory on.
 *
 * Return value:
 *   a handle to the given context memory
 *
 * Comments:
 *   handle returned as null if failed to allocate memory.
 */

#define gdl_mem_alloc(ctx_handler, size, pool)			_gdl_mem_alloc(ctx_handler, size, pool, __FILE__, __LINE__)
gdl_mem_handle_t _gdl_mem_alloc(gdl_context_handle_t ctx_handler, unsigned long long size, gdl_mem_pools pool, const char *file, int line);


/*
 * gdl_mem_alloc_nonull - allocate a number of bytes requested in the given memory pool of the specified context.
 *
 * Input:
 *   @ctx_handler - the requested hw context to allocate from.
 *   @size - number of bytes to allocate in the memory region . ( size is aligned up to a multiply of 16)
 *	 @pool - the requested memory pool to allocate the memory on.
 *
 * Return value:
 *   a handle to the given context memory
 *
 * Comments:
 *    handle returned only if successful. exits in case of failure to allocate.
 */
#define gdl_mem_alloc_nonull(ctx_handler, size, pool)	_gdl_mem_alloc_nonull(ctx_handler, size, pool, __FILE__, __LINE__)
gdl_mem_handle_t _gdl_mem_alloc_nonull(gdl_context_handle_t ctx_handler, unsigned long long size, gdl_mem_pools pool, const char *file, int line);


/*
 * gdl_mem_free - deallocate the allocated memory handle.
 *
 * Input:
 *   @buffer - handle to a previously allocated context memory handle
 *
 * Comments:
 *   in case a null handler is given the function simply returns
 */
#define gdl_mem_free(buffer)							_gdl_mem_free(buffer, __FILE__, __LINE__)
void _gdl_mem_free(gdl_mem_handle_t buffer, const char *file, int line);


/*
 * gdl_mem_handle_to_host_ptr - converts the memory handle to a pointer in the host memory region.
 *
 * Input:
 *   @handle - a memory handle previously allocated
 *
 * Return value:
 * 	 a pointer to the contexts l4 memory that the host can access
 *   in case of failure NULL pointer is returned
 * 
 *
 */
void *gdl_mem_handle_to_host_ptr(gdl_mem_handle_t handle);

/*
 * gdl_host_ptr_to_mem_handle - converts a host pointer to a memory handle in the specified context.
 *
 * Input:
 *   @ctx_handler - the id of the context
 *
 * Output:
 *   p -  the pointer previously allocated by the host
 *
 * Return value:
 * 	 memory handle to the requested context
 *   in case of failure NULL memory handle is returned
 *  
 *
 */
gdl_mem_handle_t gdl_host_ptr_to_mem_handle(gdl_context_handle_t ctx_handler, void *p);

/*
 * gdl_mem_handle_to_apu_ptr - converts the memory handle to a 32bit pointer the apu can access
 *
 * Input:
 *   @handle - a memory handle previously allocated
 *
 * Return value:
 * 	 an apu pointer (32bit) to the memory segment of the context
 *	 in case of failure NULL pointer is returned

 * Comments:
 *  only from constantly mapped memory pool
 * 	
 */
unsigned int gdl_mem_handle_to_apu_ptr(gdl_mem_handle_t handle);

/*
 * gdl_apu_ptr_to_mem_handle -  converts an apu pointer (32bit) to a memory handle in the specified context.
 *
 * Input:
 *   @ctx_handler - the id of the context
 *
 * Output:
 *   p -  the apu pointer previously allocated by the host
 *
 * Return value:
 * 	 memory handle to the requested context
 *   in case of failure NULL memory handle is returned
 *
 * Comments:
 *  only from constantly mapped memory pool
 *  
 *
 */
gdl_mem_handle_t gdl_apu_ptr_to_mem_handle(gdl_context_handle_t ctx_handler, unsigned int p);

/*
 * gdl_task_desc_init - initializes a requested user task
 *
 * Input:
 * 	 @ctx_handler - the id of an hardware context previously allocated
 *   @code_offset - the code offset of the function that the task should execute
 *   @inp - input memory handle
 *   @outp - output memory handle
 *   @comp_flags - completion flags for task
 *    								        (	GSI_TASK_NOTIFY_COMPLETION,
												GSI_TASK_IS_BARRIER,
												GSI_TASK_IS_INITIAL,
												GSI_TASK_NEED_MAPPING,
 *    										)
 *   @apuc_idx - the index of the apuc that the task should run on
 *
 * Output:
 *  @task_desc - a previously allocated user task to be initiated.
 *
 * Return value:
 *   a pointer to an initialized user task
 *   in case of failure NULL pointer is returned
 *
 */
struct gsi_task_desc *gdl_task_desc_init(gdl_context_handle_t ctx_handler, 
										struct gsi_task_desc *task_desc,
										unsigned int code_offset,
										gdl_mem_handle_t inp, 
										gdl_mem_handle_t outp, 
										unsigned char comp_flags, 
										unsigned int apuc_idx);

/*
 * gdl_task_desc_create - allocates a new user task and initializes it.
 *
 * Input:
 *   @ctx_handler - the id of an hardware context previously allocated
 *   @code_offset - the code offset of the function that the task should execute
 *   @inp - input memory handle
 *   @outp - output memory handle
 *   @apuc_idx - the index of the apuc that the task should run on
 *
 * Return value:
 *   a pointer to a newly created and initialized user task
 *   in case of failure NULL pointer is returned
 *
 */
struct gsi_task_desc *gdl_task_desc_create(gdl_context_handle_t ctx_handler, unsigned int code_offset, gdl_mem_handle_t inp, gdl_mem_handle_t outp, unsigned int apuc_idx);

/*
 * gdl_task_desc_destroy - frees a previously allocated user task.
 *
 * Input:
 *   @task_desc - the task to be freed
 *
 */
void gdl_task_desc_destroy(struct gsi_task_desc *task_desc);

/*
 * gsi_task_desc_mem_free_and_destroy - frees a previously allocated user task including the input and output memory handles if they were given.
 *
 * Input:
 *   @task_desc - the task to be freed
 *
 */
void gdl_task_desc_mem_free_and_destroy(struct gsi_task_desc *task_desc);

/*
 * gdl_schedule_task_timeout - synchronously execute a user task with a timeout
 *
 * Input:
 * 	 @task - a previously initialized user task
 * 	 @mem_buf - an array of previously allocated memory handles and their size to set the dynamic memory region accordingly
 * 	 @buf_size - the length of the mem_buf array
 *	 @ms_timeout - the time in mili seconds a task should wait for completion before aborting ( 0 indicates waiting indefinitely )
 *	 @map_type - determine the mapping type for the specific task
 * 
 * Output:
 * 	 @comp - if task was successfully scheduled, and @comp is provided, the task completion status,
 * 			 or any error is returned in comp.
 * 
 * Return value:
 *   = 0 - OK.
 *   != 0 - error code
 *
 * Comments:
 *  The dynamically mapped memory region for the task is determined according to @mem_buf
 *  The comp paramater is optional and mainly for situations when the given timeout of the task has ended and the functions return code is a timeout error,
 *  if comp is given more information can be returned regarding the reason the task has timedout.
 *  In case comp is NULL then the general status will only be returned by the function, with no specific information.
 * 
 *  Currently comp will only return GDL_TASK_TIMEDOUT.
 * 
 *  GDL_USER_MAPPING - option determines that the task uses the normal user mapping of the AT table.
 *   
 */
int gdl_schedule_task_timeout(struct gsi_task_desc *task, 
							struct gdl_mem_buffer *mem_buf, 
							unsigned int buf_size,
							gdl_task_comp_status *comp,
							unsigned int ms_timeout,
							gdl_mapping_type map_type);

/*
 * gdl_schedule_batch_timeout - synchronously execute a batch of user tasks with a timeout.
 *
 * Input:
 * 	 @task - a previously initialized user tasks.
 * 	 @count - the number of tasks to be executed.
 * 	 @mem_buf - an array of previously allocated memory handles and their sizes
 * 	 @buf_size - the length of the mem_buf array
 *   @ms_timeout - the amount of time in mili seconds a task should wait for completion before aborting ( 0 indicates waiting indefinitely ) 
 *   @map_type - determine the mapping type for the specific task
 *
 * Output:
 * 	 @comp - if tasks were successfully scheduled, and @comp is provided, the batch of tasks completion status,
 * 			 or any error is returned in comp.
 *
 * Return value:
 *   = 0 - OK.
 *   != 0 - error code
 *
 * Comments:
 *  The dynamically mapped memory region for the entire batch of tasks is determined according to @mem_buf
 *  The comp paramater is optional and mainly for situations when the given timeout of the task has ended and the functions return code is a timeout error,
 *  if comp is given more information can be returned regarding the reason the task has timedout.
 *  In case comp is NULL then the general status will only be returned by the function, with no specific information. 
 *
 *  Currently comp will only return GDL_TASK_TIMEDOUT.
 *  
 *  GDL_USER_MAPPING - option determines that the task uses the normal user mapping of the AT table.
 */
int gdl_schedule_batch_timeout(struct gsi_task_desc *task, 
							  unsigned long count, 
							  struct gdl_mem_buffer *mem_buf, 
							  unsigned int buf_size,
							  gdl_task_comp_status *comp,
							  unsigned int ms_timeout,
							  gdl_mapping_type map_type);


/*
 * gdl_run_task_timeout - creates, initializes and runs a task synchronously.
 *
 * Input:
 *   @ctx_handler - the id of an hardware context previously allocated
 *   @code_offset - the code offset of the function that the task should execute
 *   @inp - input memory handle
 *   @outp - output memory handle
 * 	 @mem_buf - an array of previously allocated memory handles and their sizes
 * 	 @buf_size - the length of the mem_buf array
 * 	 @apuc_idx - the apuc that the task should be executed on
 *   @ms_timeout - the time in mili seconds a task should wait for completion before aborting ( 0 indicates waiting indefinitely ) 
 *   @map_type - determine the mapping type for the specific task
 *
 * Output:
 * 	 @comp - if task was successfully scheduled, and @comp is provided, the task completion status,
 * 			 or any error is returned in comp.
 * 
 * Return value:
 *   = 0 - OK.
 *   != 0 - error code
 * 
 * Comments:
 *  The dynamically mapped memory region for the task is determined according to @mem_buf
 *  The comp paramater is optional and mainly for situations when the given timeout of the task has ended and the functions return code is a timeout error,
 *  if comp is given more information can be returned regarding the reason the task has timedout.
 *  In case comp is NULL then the general status will only be returned by the function, with no specific information. 
 * 
 *  Currently comp will only return GDL_TASK_TIMEDOUT.
 *  
 *  GDL_USER_MAPPING - option determines that the task uses the normal user mapping of the AT table.
 * 
 */
int gdl_run_task_timeout(gdl_context_handle_t ctx_handler, 
						unsigned int code_offset, 
						gdl_mem_handle_t inp, 
						gdl_mem_handle_t outp, 
						struct gdl_mem_buffer *mem_buf, 
						unsigned int buf_size, 
						unsigned int apuc_idx,
						gdl_task_comp_status *comp,
						unsigned int ms_timeout,
						gdl_mapping_type map_type);


/*
 * gdl_mem_cpy_to_dev - copy from the host to the devices L4 memory.
 *
 * Input:
 *   @dst - memory handle to the devices memory where the content is to be copied
 * 	 @src - source address to copy from
 *	 @size - number of bytes to copy
 * 
 * Return value:
 *   = 0 - OK.
 *   != 0 - error code
 * 
 * Comments:
 *  The functions uses the hosts DMA in order to copy the data, in case there is no host DMA
 *  or for some reason using the DMA is not possible , normal memcpy is used to copy.
 *  For optimized performance the addresses should be aligned to GDL_MEM_CPY_OPTIMIZED_ALIGNMENT 
 * 
 */
int gdl_mem_cpy_to_dev(gdl_mem_handle_t dst, const void *src, unsigned long long size);

/*
 * gdl_mem_cpy_from_dev - copy from the device to the host memory.
 *
 * Input:
 *   @dst - destination address where the content is to be copied
 * 	 @src - memory handle to copy to copy from
 *	 @size - number of bytes to copy
 * 
 * Return value:
 *   = 0 - OK.
 *   != 0 - error code
 * 
 * Comments:
 *  The functions uses the hosts DMA in order to copy the data, in case there is no host DMA
 *  or for some reason using the DMA is not possible , normal memcpy is used to copy.
 *  For optimized performance the addresses should be aligned to GDL_MEM_CPY_OPTIMIZED_ALIGNMENT 
 */
int gdl_mem_cpy_from_dev(void *dst, gdl_mem_handle_t src, unsigned long long size);

/*
 * gdl_mem_set - sets the first num bytes of the devices L4 memory according to the given value 
 *
 * Input:
 * 	 @src - memory handle to the devices memory
 *	 @value - value to be set. The value is passed as an int, but the function fills the block of memory using the unsigned char conversion of this value.
 *   @num - number of bytes to be set to the value
 * 
 * Return value:
 *   = 0 - OK.
 *   != 0 - error code
 * 
 * Comments:
 */
int gdl_mem_set(gdl_mem_handle_t src, int value, unsigned int num);

/*
 * gdl_add_to_mem_handle - add additional offset to a memory handle
 *
 * Input:
 * 	 @inp - The memory handle to add the addition to
 *	 @addition - The size of the addition in bytes to add to the memory handle
 *
 * Output:
 * 	 @out - The output memory handle after the addition
 * 
 * Return value:
 *   = 0 - OK.
 *   != 0 - error code
 * 
 * Comments:
 */
int gdl_add_to_mem_handle(gdl_mem_handle_t *out, gdl_mem_handle_t inp, unsigned long long addition);

/* utility function for checking if a given memory handle is null */
int gdl_mem_handle_is_null(gdl_mem_handle_t handle);

#define GDL_TASK_DECLARE(name) extern const unsigned int * __attribute__((weak)) GSI_TASK_##name;

// Helper for GDL_TASK, do not call directly
unsigned int gdl_task_lookup(const unsigned int **pptr, const char *sym_name);
#define GDL_TASK_LOOKUP(ptr) (ptr ? *ptr : gdl_task_lookup(&ptr, #ptr))

/* utility macro for receiving the code offset of a given function to be used for gdl_run_task, gdl_task_desc_create and gdl_task_desc_init as tasks  */
#define GDL_TASK(name) GDL_TASK_LOOKUP(GSI_TASK_##name)

/* utility macro for declaring a null memory handle */
#define GDL_MEM_HANDLE_NULL ((const gdl_mem_handle_t){ 0 })

#ifdef __cplusplus
}
#endif

#endif /* GSI_LIBGDL_H */
