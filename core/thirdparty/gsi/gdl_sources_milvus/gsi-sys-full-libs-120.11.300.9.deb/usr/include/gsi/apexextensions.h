#ifndef _apexextensions_H_
#define _apexextensions_H_


// User extension aux register IDAR
#define AR_IDAR 0xfffffa00

// User extension aux register IDR0
#define AR_IDR0 0xfffffa01

// User extension aux register IDR1
#define AR_IDR1 0xfffffa02

// User extension aux register IDR2
#define AR_IDR2 0xfffffa03

// User extension aux register IDR3
#define AR_IDR3 0xfffffa04

// User extension aux register RSP2K_0
#define AR_RSP2K_0 0xfffffb00

// User extension aux register RSP2K_1
#define AR_RSP2K_1 0xfffffb01

// User extension aux register RSP2K_2
#define AR_RSP2K_2 0xfffffb02

// User extension aux register RSP2K_3
#define AR_RSP2K_3 0xfffffb03

// User extension aux register RSP32K
#define AR_RSP32K 0xfffffb04

// User extension aux register debugger_reset
#define AR_DEBUGGER_RESET 0xfffff800

// User extension instruction write_reg
extern unsigned int write_reg(unsigned int, unsigned int);

// User extension instruction md
extern unsigned int md(unsigned int);

// User extension instruction RSPrd
extern unsigned int RSPrd(unsigned int);

// User extension instruction test_barrier
extern unsigned int test_barrier(unsigned int);

// User extension instruction read_reg
extern unsigned int read_reg(unsigned int);

#endif
