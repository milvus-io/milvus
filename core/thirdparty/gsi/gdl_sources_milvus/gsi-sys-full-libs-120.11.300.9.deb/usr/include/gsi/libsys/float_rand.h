/*
 * Copyright (C) 2016, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */
#include <gsi/libsys/config.h>

#if defined(GSI_LIBSYS_X86_64) || defined(GSI_LIBSYS_X86_32)

#ifndef GSI_FLOAT_RAND_H
#define GSI_FLOAT_RAND_H

#include <gsi/common_api.h>

float gsi_random_float(float min, float max);
gsi_prod_fp16_t gsi_random_float16(float min, float max);
gsi_prod_fp16_t gsi_random_float16_v1(void);

#endif /* GSI_FLOAT_RAND_H */

#endif /* defined(GSI_LIBSYS_X86_64) || defined(GSI_LIBSYS_X86_32) */
