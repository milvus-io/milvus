/*
 * Copyright (C) 2016, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */
#ifndef GSI_TASK_API_H
#define GSI_TASK_API_H
//#include <string.h>

#ifndef __GNUC__
#error unsupported compiler
#endif

#include <gsi/common_api.h>

#include <stddef.h>
#include <stdint.h>

#define GSI_TASK_NAME_SECTION "GSI_task_ep_names"

/*
 * Register function NAME as a task entry point
 *
 * Note: See gsi_task_comp_desc.tc_ret_code for return code semantics.
 */
#define GSI_TASK_ENTRY_POINT(name, in, out)	  \
	static const char __attribute__((section(GSI_TASK_NAME_SECTION), used)) \
	name##__name[] = #name; \
	static gsi_prod_status_t __attribute__((used)) \
	name(void * in __attribute__((unused)), \
	     void *out __attribute__((unused)))

void *gsi_apuc_malloc(size_t size);
void gsi_apuc_free(const void *p);
void gsi_apuc_free_any(const void *p);
void *gsi_apuc_zalloc(size_t size);
void *gsi_apuc_calloc(size_t nelem, size_t elem_size);
void *gsi_apuc_memdup(const void *s, size_t size);
char *gsi_apuc_strdup(const char *s);

#endif /* GSI_TASK_API_H */
