/*
 * GSI Device Library for Host code running User Tasks remotely on GSI's APU System
 *
 * Copyright (C) 2019, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */

#ifndef GSI_LIBAPL_H_
#define GSI_LIBAPL_H_

#include <gsi/libgal.h>
#include <gsi/apl_defs.h>
#include <gsi/preproc_defs.h>
#include <gsi/apexextensions.h>

/*
 * ER programming
 */
#ifdef GSI_DEBUG_ASSERT
#define APL_DEBUG_ASSERT GSI_DEBUG_ASSERT
#else
#if defined(DEBUG_BUILD)
#define APL_DEBUG_ASSERT(e) { if (!(e)) gal_fatal(#e); }
#else
#define APL_DEBUG_ASSERT(a)
#endif

#endif

static inline void apl_set_bank_en_reg(u32 val)
{
	APL_DEBUG_ASSERT((val & ~0xff) == 0);
	write_reg(val, GSI_APUC_ER_BANK_EN_0);
}

static inline void apl_set_rdlogic_reg(uint reg_idx, u32 val)
{
	APL_DEBUG_ASSERT(reg_idx < VALU_RDLOGIC_NUM_REGS);
	APL_DEBUG_ASSERT(val < (1 << VALU_RDLOGIC_REG_WIDTH));
	write_reg(val, GSI_APUC_ER_RDLOGIC_0 + reg_idx);
}

static inline void apl_set_sm_reg(uint sm_reg, u32 val)
{
	APL_DEBUG_ASSERT(sm_reg < VALU_SMAP_NUM_REGS);
	write_reg(val, GSI_APUC_ER_SMAP_0 + sm_reg);
}

static inline void apl_set_rn_reg(uint rn_reg, u32 val)
{
	APL_DEBUG_ASSERT(rn_reg < VALU_ROWNUM_NUM_REGS);
	APL_DEBUG_ASSERT(val < GSI_BLSECT_NUM_ROWS);
	write_reg(val, GSI_APUC_ER_ROWNUM_0 + rn_reg);
}

static inline void apl_set_re_reg(uint re_reg, u32 val)
{
	APL_DEBUG_ASSERT(re_reg < VALU_ROWMASK_NUM_REGS);
	APL_DEBUG_ASSERT(val < (1 << VALU_RE_REG_WIDTH));
	write_reg(val, GSI_APUC_ER_RE_MASK_0 + re_reg);
}

static inline void apl_set_ewe_reg(uint ewe_reg, u32 val)
{
	APL_DEBUG_ASSERT(ewe_reg < VALU_ROWMASK_NUM_REGS);
	APL_DEBUG_ASSERT(val < (1 << VALU_EWE_REG_WIDTH));
	write_reg(val, GSI_APUC_ER_EWE_MASK_0 + ewe_reg);
}

static inline void apl_set_l1_reg(uint reg_idx, u32 val)
{
	APL_DEBUG_ASSERT(reg_idx < VALU_L1_ADDR_NUM_REGS);
	APL_DEBUG_ASSERT(val < (1 << VALU_L1_ADDR_REG_WIDTH));
	write_reg(val, GSI_APUC_ER_L1_ADDR_0 + reg_idx);
}

static inline void apl_set_l1_reg_ext(uint reg_idx, uint bank_id, uint grp_id, uint grp_row)
{
	APL_DEBUG_ASSERT(bank_id < GSI_L1_NUM_BANKS);
	APL_DEBUG_ASSERT(grp_id < GSI_L1_NUM_GRPS);
	APL_DEBUG_ASSERT(grp_row < GSI_L1_VA_NUM_ROWS);
	apl_set_l1_reg(reg_idx, (bank_id << (GSI_L1_CTL_GRP_ADDR_BITS + GSI_L1_CTL_ROW_ADDR_BITS)) |
	               (grp_id << GSI_L1_CTL_ROW_ADDR_BITS) |
	               grp_row);
}

static inline void apl_set_l2_reg(uint reg_idx, u32 val)
{
	APL_DEBUG_ASSERT(reg_idx < VALU_L2_ADDR_NUM_REGS);
	APL_DEBUG_ASSERT(val < (1 << VALU_L2_ADDR_REG_WIDTH));
	write_reg(val, GSI_APUC_ER_L2_ADDR_0 + reg_idx);
}

static inline void apl_set_ifin_reg(u32 val)
{
	APL_DEBUG_ASSERT(val < (1 << SEU_IFIN_REG_WIDTH));
	write_reg(val, GSI_APUC_ER_IFIN);
}

unsigned char apl_rd_rsp32k_reg(void);
void apl_rsp_rd(unsigned int apc_id);
unsigned int  apl_rd_rsp2k_reg(unsigned int  bank_id);

// #define AR_RSP32K 0xfffffb04
// static inline unsigned char apl_rd_rsp32k_reg(void)
// {
//     return _lr(AR_RSP32K);
// }
// #define apl_rsp_rd RSPrd
// unsigned int apl_rd_rsp2k_reg(unsigned int bank_id);


#endif /* GSI_LIBAPL_H_ */
