/*
 * Copyright (C) 2019, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */

#ifndef GAL_FAST_FUNCS_H_
#define GAL_FAST_FUNCS_H_

#include <gsi/libgal.h>
#include "gal-fast-funcs-dependence-funcs.h"

#define L2DMA_MIN_CHUNK_MULTIPLY(x) (x<<6)

struct gal_fast_l2dma_l4_l2_transaction {
	uint num_steps;
	uint step_size_num_512b_chunk; /* number of chunks - each chunk is 512 bytes */
	void *l4_addr;
	u8 l2_mode;
	u8 l2_col_group;        /* column groups in 64 l2 columns resolution (values 0 - 63) */
};

/*
 * gal_fast_l2dma_async_memcpy_init - Initilize APC # high register before call to gal_fast_l2dma_async_memcpy function.
 *
 * Input:
 *         @apc_id - L2-APC-# (0 - L2-APC 0/ 1 - L2-APC-1).
 */
static inline __attribute__((always_inline)) void gal_fast_l2dma_async_memcpy_init(u32 apc_id)
{
	if (GAL_L2DMA_APC_ID_0 == apc_id)
		apc0_l2dma_set_cmd_hi_reg_uc(0);
	else
		apc1_l2dma_set_cmd_hi_reg_uc(0);
}

/*
 * gal_fast_l2dma_async_memcpy_end - Wait until the last APC # L2DMA operation finish after call to gal_fast_l2dma_async_memcpy function.
 *
 * Input:
 *         @apc_id - L2-APC-# (0 - L2-APC 0/ 1 - L2-APC-1).
 */
static inline __attribute__((always_inline)) void gal_fast_l2dma_async_memcpy_end(u32 apc_id)
{
	if (GAL_L2DMA_APC_ID_0 == apc_id)
		apc0_l2dma_clean_queue();
	else
		apc1_l2dma_clean_queue();
}

/*
 * gal_fast_l2dma_l2_ready_rst_all - Change l2_ready state to GAL_L2DMA_L2_READY_RST on both L2-APC's
 * Comments:
 *         Call to this function only if l2_ready current state is GAL_L2DMA_L2_READY_SET.
 */
static inline __attribute__((always_inline)) void gal_fast_l2dma_l2_ready_rst_all()
{
#ifdef DMA_DIAGNOSIS
	uint32_t busy_loop_count = 0;
#endif
	u32 timeout = 0;

	/* wait for l2_ready set condition */
	while (!gal_fast_apuc_cond(GAL_FAST_APUC_COND_L2_READY_A)) {
		if (timeout++ > GAL_FAST_L2DMA_TIMEOUT)
			gsi_fatal("COND_L2_READY A timed out (make sure l2_ready is set before using gal_fast_l2dma_mem_to_l2_start)");
	}
	timeout = 0;
	while (!gal_fast_apuc_cond(GAL_FAST_APUC_COND_L2_READY_B)) {
		if (timeout++ > GAL_FAST_L2DMA_TIMEOUT)
			gsi_fatal("COND_L2_READY B timed out (make sure l2_ready is set before using gal_fast_l2dma_mem_to_l2_start)");
	}

	/* change l2_ready to rst */
	while (apc0_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
		BUSY_LOOP()
	}
	apc0_l2dma_queue_rst_l2_ready_cmd();
	while (apc1_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
		BUSY_LOOP()
	}
	apc1_l2dma_queue_rst_l2_ready_cmd();

	/* wait for l2_ready rst condition */
	timeout = 0;
	while (gal_fast_apuc_cond(GAL_FAST_APUC_COND_L2_READY_A)) {
		if (timeout++ > GAL_FAST_L2DMA_TIMEOUT)
			gsi_fatal("COND_L2_READY A timed out (fail to rst l2_ready)");
	}
	timeout = 0;
	while (gal_fast_apuc_cond(GAL_FAST_APUC_COND_L2_READY_B)) {
		if (timeout++ > GAL_FAST_L2DMA_TIMEOUT)
			gsi_fatal("COND_L2_READY B timed out (fail to rst l2_ready)");
	}
}

/*
 * gal_fast_l2dma_async_memcpy_no_cpu - Memcpy using APC # L2DMA.
 *
 * Input:
 *         @dst - L4/L3 destination address.
 *         @src - L4/L3 source address.
 *         @size - Number of bytes to copy.
 *         @apc_id - L2-APC-# (0 - L2-APC 0/ 1 - L2-APC-1).
 *         @flush_src - Flush source cache lines.
 *         @inval_dst - Invalidate destination cache lines.
 *         @flush_dst_edges - Flush destination edges cache lines.
 */
static inline __attribute__((always_inline)) void gal_fast_l2dma_async_memcpy_no_cpu(void *dst, void *src, int32_t size, int32_t apc_id, bool flush_src, bool inval_dst, bool flush_dst_edges)
{
	uint8_t *dst_u8 = (uint8_t *)dst;
	uint8_t *src_u8 = (uint8_t *)src;
	int32_t left = size;

	/* L3 address must be 8 byte aligned, in this case also the size must be 8 byte aligned */
	GSI_DEBUG_ASSERT((gal_is_l3_addr((u32)(uintptr_t)src_u8) == 0) || ((((u32)src_u8 & 7) == 0) && ((size & 7) == 0)));
	GSI_DEBUG_ASSERT((gal_is_l3_addr((u32)(uintptr_t)dst_u8) == 0) || ((((u32)dst_u8 & 7) == 0) && ((size & 7) == 0)));

	if (inval_dst && flush_dst_edges) {
		gal_fast_cache_dcache_flush_mlines((u32)dst_u8, 1);
		gal_fast_cache_dcache_flush_mlines((u32)(dst_u8 + size - 1), 1);
	}

	if (size >= 512) {
		if (flush_src)
			gal_fast_cache_dcache_flush_mlines((u32)src_u8, 512);
		if (inval_dst)
			gal_fast_cache_dcache_invalidate_mlines((u32)dst_u8, 512);
		gal_fast_l2dma_mem_to_mem_512(dst_u8, src_u8, apc_id);
		left -= 512;
		dst_u8 += 512;
		src_u8 += 512;
	} else {
		if (flush_src)
			gal_fast_cache_dcache_flush_mlines((u32)src_u8, 256);
		if (inval_dst)
			gal_fast_cache_dcache_invalidate_mlines((u32)dst_u8, 256);
		gal_fast_l2dma_mem_to_mem_256(dst_u8, src_u8, apc_id);
		left -= 256;
		dst_u8 += 256;
		src_u8 += 256;
	}
	while (left >= 512) {
		if (flush_src)
			gal_fast_cache_dcache_flush_mlines((u32)src_u8, 512);
		if (inval_dst)
			gal_fast_cache_dcache_invalidate_mlines((u32)dst_u8, 512);
		gal_fast_l2dma_mem_to_mem_512(dst_u8, src_u8, apc_id);
		left -= 512;
		dst_u8 += 512;
		src_u8 += 512;
	}
	if (left > 256) {
		if (flush_src)
			gal_fast_cache_dcache_flush_mlines((u32)src_u8, left);
		if (inval_dst)
			gal_fast_cache_dcache_invalidate_mlines((u32)dst_u8, left);
		gal_fast_l2dma_mem_to_mem_512(dst_u8 - (512 - left), src_u8 - (512 - left), apc_id);
	} else if (left > 0) {
		if (flush_src)
			gal_fast_cache_dcache_flush_mlines((u32)src_u8, left);
		if (inval_dst)
			gal_fast_cache_dcache_invalidate_mlines((u32)dst_u8, left);
		gal_fast_l2dma_mem_to_mem_256(dst_u8 - (256 - left), src_u8 - (256 - left), apc_id);
	}
}

/*
 * gal_fast_l2dma_async_memcpy - Memcpy using APC # L2DMA, if size is less then 256 bytes using APUC memcpy insted of L2DMA memcpy.
 *
 * Input:
 *         @dst - L4/L3 destination address.
 *         @src - L4/L3 source address.
 *         @size - Number of bytes to copy.
 *         @apc_id - L2-APC-# (0 - L2-APC 0/ 1 - L2-APC-1).
 *         @flush_src - Flush source cache lines.
 *         @inval_dst - Invalidate destination cache lines.
 *         @flush_dst_edges - Flush destination edges cache lines.
 *         @inval_dst_post_memcpy - Invalidate destination cache lines after the call to memcpy.
 *         @inval_src_post_memcpy - Invalidate source cache lines after the call to memcpy.
 */
static inline __attribute__((always_inline)) void gal_fast_l2dma_async_memcpy(void *dst, void *src, int32_t size, int32_t apc_id, bool flush_src, bool inval_dst, bool flush_dst_edges, bool inval_dst_post_memcpy, bool inval_src_post_memcpy)
{
        if (unlikely(size < 256)) {
                memcpy(dst, src, size);
                gal_fast_cache_dcache_flush_mlines((u32)dst, size);
                if (inval_dst_post_memcpy)
                        gal_fast_cache_dcache_invalidate_mlines((u32)dst, size);
                if (inval_src_post_memcpy)
                        gal_fast_cache_dcache_invalidate_mlines((u32)src, size);
                return;
        }

        gal_fast_l2dma_async_memcpy_no_cpu(dst, src, size, apc_id, flush_src, inval_dst, flush_dst_edges);
}

/*
 * gal_fast_l2dma_memset - Memset using APC # L2DMA.
 *
 * Input:
 *         @dst - L4/L3 destination address.
 *         @data - Data to be set.
 *         @size - Number of bytes to copy.
 *         @apc_id - L2-APC-# (0 - L2-APC 0/ 1 - L2-APC-1).
 *         @inval_dst - Invalidate destination cache lines.
 *         @l3_512_bytes_buffer - buffer from l3 memory with the size of 512 bytes
 */
static inline __attribute__((always_inline)) void gal_fast_l2dma_memset(u8 *dst, u8 data, u32 size, u32 apc_id, bool inval_dst, void *l3_512_bytes_buffer)
{
        u8 *src = (u8 *)l3_512_bytes_buffer;
        u32 left = size;

        if (unlikely(size < 256)) {
                memset(dst, data, size);
                return;
        }

        /* L3 address must be 8 byte aligned, in this case also the size must be 8 byte aligned */
        GSI_DEBUG_ASSERT(!gal_is_l3_addr((u32)(uintptr_t)src) || ((((u32)src & 7) == 0) && ((size & 7) == 0)));
        GSI_DEBUG_ASSERT(!gal_is_l3_addr((u32)(uintptr_t)dst) || ((((u32)dst & 7) == 0) && ((size & 7) == 0)));

        if (inval_dst) {
                /* Flush dst buff edges */
                gal_fast_cache_dcache_flush_mlines((u32)dst, 1);
                gal_fast_cache_dcache_flush_mlines((u32)dst + size - 1, 1);
        }

        if (size >= 512) {
                memset(src, data, 512);
                gal_fast_cache_dcache_flush_mlines((u32)src, 512);
                if (inval_dst)
                        gal_fast_cache_dcache_invalidate_mlines((u32)dst, 512);
                gal_fast_l2dma_mem_to_mem_512(dst, src, apc_id);
                left -= 512;
                dst += 512;
        } else {
                memset(src, data, 256);
                gal_fast_cache_dcache_flush_mlines((u32)src, 256);
                if (inval_dst)
                        gal_fast_cache_dcache_invalidate_mlines((u32)dst, 256);
                gal_fast_l2dma_mem_to_mem_256(dst, src, apc_id);
                left -= 256;
                dst += 256;
        }
        if (data == 0) {
                while (left >= 512) {
                        if (inval_dst)
                                gal_fast_cache_dcache_invalidate_mlines((u32)dst, 512);
                        gal_fast_l2dma_l2t_to_mem_512(dst, apc_id);
                        left -= 512;
                        dst += 512;
                }
        } else {
                while (left >= 512) {
                        if (inval_dst)
                                gal_fast_cache_dcache_invalidate_mlines((u32)dst, 512);
                        gal_fast_l2dma_mem_to_mem_512(dst, src, apc_id);
                        left -= 512;
                        dst += 512;
                }
        }
        if (left > 256) {
                if (inval_dst)
                        gal_fast_cache_dcache_invalidate_mlines((u32)dst - (512 - left), 512);
                gal_fast_l2dma_mem_to_mem_512(dst - (512 - left), src, apc_id);
        } else if (left > 0) {
                if (inval_dst)
                        gal_fast_cache_dcache_invalidate_mlines((u32)dst - (256 - left), 256);
                gal_fast_l2dma_mem_to_mem_256(dst - (256 - left), src, apc_id);
        }

        gal_fast_l2dma_async_memcpy_end(apc_id);
}

/*
 * gal_fast_l2dma_is_txns_valid - Checking the validity of the transaction for L2DMA use.
 *
 * Input:
 *         @num_transactions -  Number of transactions to do.
 *         @transactions - Array of transactions.
 *
 * Return value:
 *        true - transactions is valid to use L2DMA.
 *        false - transactions isn't valid to use L2DMA.
 */
static inline __attribute__((always_inline)) bool gal_fast_l2dma_is_txns_valid(uint num_transactions, struct gal_fast_l2dma_l4_l2_transaction *transactions)
{
	if (num_transactions < 1 || num_transactions > 2)
		return false;
	for (uint i = 0; i < num_transactions; i++) {
		if (transactions[i].l2_mode != GAL_L2T_MODE_64 || transactions[i].num_steps != 1)
			return false;
	}
	return true;
}

/*
 * gal_fast_l2dma_mem_to_l2_start - Copy data from L4/L3 to specific L2-APC using L2DMA.
 *
 * Input:
 *         @apc_id - L2-APC-# (0 - L2-APC 0/ 1 - L2-APC-1).
 *         @num_transactions -  Number of transactions to do.
 *         @transactions - Array of transactions.
 *         @l2_ready_attr - l2_ready state for the L2-APC-# after all transactions ended.
 *
 * Comments:
 *         See L2DMA transaction description in libgal.h.
 *        After calling this function you must call to gal_fast_l2dma_sync() or gal_fast_sync_many() for transactions completion.
 *        If the number of transactions is 1 or 2, the L2T mode is GAL_L2T_MODE_64 and each tratransaction is only one step, the L2DMA work without interrupts.
 */
static inline __attribute__((always_inline)) void gal_fast_l2dma_mem_to_l2_start(uint apc_id, uint num_transactions, struct gal_fast_l2dma_l4_l2_transaction *transactions, enum gal_l2dma_cmd_attr l2_ready_attr)
{
#ifdef DMA_DIAGNOSIS
	uint32_t busy_loop_count = 0;
#endif
	GSI_DEBUG_ASSERT(gal_fast_l2dma_is_txns_valid(num_transactions, transactions));
	const char *timeout_error = "COND_L2_READY timed out (make sure l2_ready is set before using gal_fast_l2dma_mem_to_l2_start)";
	u32 timeout = 0;

	if (num_transactions == 1) {
		/* In case L1 <-> L2 transaction is not finished
		* wait for the background fragment to set the l2_ready
		*/
		if (GAL_L2DMA_APC_ID_0 == apc_id) {
			while (!gal_fast_apuc_cond(GAL_FAST_APUC_COND_L2_READY_A)) {
				if (timeout++ > GAL_FAST_L2DMA_TIMEOUT)
					gsi_fatal("%s", timeout_error);
			}
			while (apc0_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
				BUSY_LOOP()
			}
			apc0_l2dma_queue_mem_to_l2_m64(transactions[0].l2_col_group, transactions[0].l4_addr, transactions[0].step_size_num_512b_chunk, l2_ready_attr);
		} else {
			while (!gal_fast_apuc_cond(GAL_FAST_APUC_COND_L2_READY_B)) {
				if (timeout++ > GAL_FAST_L2DMA_TIMEOUT)
					gsi_fatal("%s", timeout_error);
			}
			while (apc1_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
				BUSY_LOOP()
			}
			apc1_l2dma_queue_mem_to_l2_m64(transactions[0].l2_col_group, transactions[0].l4_addr, transactions[0].step_size_num_512b_chunk, l2_ready_attr);
		}
	} else {	/* num_transactions == 2 */
		if (GAL_L2DMA_APC_ID_0 == apc_id) {
			while (!gal_fast_apuc_cond(GAL_FAST_APUC_COND_L2_READY_A)) {
				if (timeout++ > GAL_FAST_L2DMA_TIMEOUT)
					gsi_fatal("%s", timeout_error);
			}
			while (apc0_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
				BUSY_LOOP()
			}
			apc0_l2dma_queue_mem_to_l2_m64(transactions[0].l2_col_group, transactions[0].l4_addr, transactions[0].step_size_num_512b_chunk, GAL_L2DMA_L2_READY_NOP);
			while (apc0_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
				BUSY_LOOP()
			}
			apc0_l2dma_queue_mem_to_l2_m64(transactions[1].l2_col_group, transactions[1].l4_addr, transactions[1].step_size_num_512b_chunk, l2_ready_attr);
		} else {
			while (!gal_fast_apuc_cond(GAL_FAST_APUC_COND_L2_READY_B)) {
				if (timeout++ > GAL_FAST_L2DMA_TIMEOUT)
					gsi_fatal("%s", timeout_error);
			}
			while (apc1_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
				BUSY_LOOP()
			}
			apc1_l2dma_queue_mem_to_l2_m64(transactions[0].l2_col_group, transactions[0].l4_addr, transactions[0].step_size_num_512b_chunk, GAL_L2DMA_L2_READY_NOP);
			while (apc1_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
				BUSY_LOOP()
			}
			apc1_l2dma_queue_mem_to_l2_m64(transactions[1].l2_col_group, transactions[1].l4_addr, transactions[1].step_size_num_512b_chunk, l2_ready_attr);
		}
	}
}

/*
 * gal_fast_l2dma_mem_to_l2_start_indirect - Copy data from L4DMA descriptors to specific L2-APC using L2DMA.
 *
 * Input:
 *         @apc_id - L2-APC-# (0 - L2-APC 0/ 1 - L2-APC-1).
 *         @num_transactions -  Number of transactions to do.
 *         @transactions - Array of transactions.
 *         @l2_ready_attr - l2_ready state for the L2-APC-# after all transactions ended.
 *
 * Comments:
 *         See L2DMA transaction description in libgal.h.
 *         There is no use of transactions->l4_addr in this function.
 *        After calling this function you must call to gal_fast_l2dma_sync() or gal_fast_sync_many() for transactions completion.
 *        If the number of transactions is 1 or 2, the L2T mode is GAL_L2T_MODE_64 and each tratransaction is only one step, the L2DMA work without interrupts.
 */
static inline __attribute__((always_inline)) void gal_fast_l2dma_mem_to_l2_start_indirect(uint apc_id, uint num_transactions, struct gal_fast_l2dma_l4_l2_transaction *transactions, enum gal_l2dma_cmd_attr l2_ready_attr)
{
#ifdef DMA_DIAGNOSIS
	uint32_t busy_loop_count = 0;
#endif
	GSI_DEBUG_ASSERT(gal_fast_l2dma_is_txns_valid(num_transactions, transactions));
	const char *timeout_error = "COND_L2_READY timed out (make sure l2_ready is set before using gal_fast_l2dma_mem_to_l2_start_indirect)";
	u32 timeout = 0;

	if (num_transactions == 1) {
		/* In case L1 <-> L2 transaction is not finished
		* wait for the background fragment to set the l2_ready
		*/
		if (GAL_L2DMA_APC_ID_0 == apc_id) {
			while (!gal_fast_apuc_cond(GAL_FAST_APUC_COND_L2_READY_A)) {
				if (timeout++ > GAL_FAST_L2DMA_TIMEOUT)
					gsi_fatal("%s", timeout_error);
			}
			while (apc0_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
				BUSY_LOOP()
			}
			apc0_l2dma_queue_mem_to_l2_m64_indirect(transactions[0].l2_col_group, transactions[0].step_size_num_512b_chunk, l2_ready_attr);
		} else {
			while (!gal_fast_apuc_cond(GAL_FAST_APUC_COND_L2_READY_B)) {
				if (timeout++ > GAL_FAST_L2DMA_TIMEOUT)
					gsi_fatal("%s", timeout_error);
			}
			while (apc1_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
				BUSY_LOOP()
			}
			apc1_l2dma_queue_mem_to_l2_m64_indirect(transactions[0].l2_col_group, transactions[0].step_size_num_512b_chunk, l2_ready_attr);
		}
	} else {	/* num_transactions == 2 */
		if (GAL_L2DMA_APC_ID_0 == apc_id) {
			while (!gal_fast_apuc_cond(GAL_FAST_APUC_COND_L2_READY_A)) {
				if (timeout++ > GAL_FAST_L2DMA_TIMEOUT)
					gsi_fatal("%s", timeout_error);
			}
			while (apc0_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
				BUSY_LOOP()
			}
			apc0_l2dma_queue_mem_to_l2_m64_indirect(transactions[0].l2_col_group, transactions[0].step_size_num_512b_chunk, GAL_L2DMA_L2_READY_NOP);
			while (apc0_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
				BUSY_LOOP()
			}
			apc0_l2dma_queue_mem_to_l2_m64_indirect(transactions[1].l2_col_group, transactions[1].step_size_num_512b_chunk, l2_ready_attr);
		} else {
			while (!gal_fast_apuc_cond(GAL_FAST_APUC_COND_L2_READY_B)) {
				if (timeout++ > GAL_FAST_L2DMA_TIMEOUT)
					gsi_fatal("%s", timeout_error);
			}
			while (apc1_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
				BUSY_LOOP()
			}
			apc1_l2dma_queue_mem_to_l2_m64_indirect(transactions[0].l2_col_group, transactions[0].step_size_num_512b_chunk, GAL_L2DMA_L2_READY_NOP);
			while (apc1_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
				BUSY_LOOP()
			}
			apc1_l2dma_queue_mem_to_l2_m64_indirect(transactions[1].l2_col_group, transactions[1].step_size_num_512b_chunk, l2_ready_attr);
		}
	}
}

/*
 * gal_fast_l2dma_sync - Wait for transactions completion.
 *
 * Input:
 *         @ioxs - Handle to transactions.
 *         @do_blocking - true: function wait until the transactions complete.
 *                                     false: function return without transactions complete, user responsibility to check when the transactions complete.
 *
 * Return value:
 *        true - transactions completed.
 *        false - transactions not completed.
 */
static inline __attribute__((always_inline)) bool gal_fast_l2dma_sync(gal_l2dma_hndl_t *ioxs, u32 apc_id, bool do_blocking)
{
	if (unlikely(ioxs != NULL))
		return gal_l2dma_sync(ioxs, do_blocking);

	gal_fast_l2dma_async_memcpy_end(apc_id);

	return true;
}

/*
 * gal_fast_sync_many_blocking - Wait for transactions completion from different L2-APC's.
 *
 * Input:
 *         @ioxs - Array of handles to transactions from different L2-APC's.
 *         @count - Size of the handles array (array max size count = 2, L2-APC-A/L2-APC-B).
 */
static inline __attribute__((always_inline)) void gal_fast_sync_many_blocking(gal_l2dma_hndl_t **ioxs, int count)
{
	if (ioxs[0])
		return gal_sync_many_blocking(ioxs, count);

	apc0_l2dma_clean_queue();
	apc1_l2dma_clean_queue();
}

enum {
	GAL_FAST_APUC_CTRL_REG_APUC_ID_MASK	= (u32)0x3,
	GAL_FAST_APUC_CTRL_STT_REG		=  0xF0000000,
};


/* get APCC ID. each ARC core has different ID. */
static inline __attribute__((always_inline)) u32 gal_fast_apuc_id(void)
{
	volatile u32 *stt_strl_reg;

	stt_strl_reg = (u32 *)(GAL_FAST_APUC_CTRL_STT_REG);

	return (*stt_strl_reg) & GAL_FAST_APUC_CTRL_REG_APUC_ID_MASK;
}

enum {
	GAL_FAST_APUC_HZ	= 400000000,
	GAL_FAST_CYCLES_PER_US =  GAL_FAST_APUC_HZ / 1000000,
};

/*
 * gal_fast_us_delay - Set dealy in microseconds.
 *
 * Input:
 *         @us - Number of microseconds.
 */
static inline __attribute__((always_inline)) void gal_fast_us_delay(u32 us)
{
	unsigned long long start = gal_get_pm_cycle_count(true);

	while (start + us * GAL_FAST_CYCLES_PER_US > gal_get_pm_cycle_count(true));
}

/*
 * gal_fast_cycles_delay - Set dealy in cycles.
 *
 * Input:
 *         @cycles - Number of cycles.
 */
static inline __attribute__((always_inline)) void gal_fast_cycles_delay(u32 cycles)
{
	unsigned long long start = gal_get_pm_cycle_count(true);

	while (start + cycles > gal_get_pm_cycle_count(true));
}

/*
 * gal_fast_malloc_cache_aligned - Allocate aligned memory from L3.
 *
 * Return value:
 *         Pointer to aligned address on L3 - OK.
 *         Pointer with ENOMEM value - allocation failed.
 *
 * Comments:
 *         Validate pointer with GSI_IS_ERR_PTR define.
 *         If size = 0, assert will appear in debug mode.
 */
static inline __attribute__((always_inline)) void *gal_fast_malloc_cache_aligned(u32 size, GSI_UNUSED(bool invalidate))
{
	u8 *p = gal_malloc(size + 32 + 32);
	if (GAL_FAST_IS_ERR_PTR_OR_NULL(p))
		return p;

	u32 *algn_p_u32 = (u32 *)((u32)(p + 32) & 0xffffffe0);

	*(algn_p_u32 - 1) = (u32)p;

	if (invalidate)
		gal_fast_cache_dcache_invalidate_mlines((u32)algn_p_u32, size);
// 	gsi_info("gal_fast_malloc p = %p algn_p_u32 %p size %d", p, algn_p_u32, size);
	return (void *)algn_p_u32;
}

/*
 * gal_fast_free_cache_aligned - Deallocate aligned memory on L3.
 *
 * Input:
 *         @p - pointer to memory.
 */
static inline __attribute__((always_inline)) void gal_fast_free_cache_aligned(void *algn_p)
{
	if (GAL_FAST_IS_ERR_PTR_OR_NULL(algn_p))
		return;
	gal_free((void *)(*(((u32 *)algn_p) - 1)));
}

/*
 * gal_fast_l2dma_mem_to_l2_start - Copy data from L2-APC to L4/L3 using L2DMA.
 *
 * Input:
 *         @apc_id - L2-APC-# (0 - L2-APC 0/ 1 - L2-APC-1).
 *         @num_transactions -  Number of transactions to do.
 *         @transactions - Array of transactions.
 *         @l2_ready_attr - l2_ready state for the L2-APC-# after all transactions ended.
 *
 * Comments:
 *         See L2DMA transaction description in libgal.h.
 *        After calling this function you must call to gal_fast_l2dma_sync() or gal_fast_sync_many() for transactions completion.
 *        If the number of transactions is 1 or 2, the L2T mode is GAL_L2T_MODE_64 and each tratransaction is only one step, the L2DMA work without interrupts.
 */
static inline __attribute__((always_inline)) void gal_fast_l2dma_l2_to_mem_start(uint apc_id, uint num_transactions, struct gal_fast_l2dma_l4_l2_transaction *transactions, enum gal_l2dma_cmd_attr l2_ready_attr)
{
	GSI_DEBUG_ASSERT(gal_fast_l2dma_is_txns_valid(num_transactions, transactions));
	const char *timeout_error = "COND_L2_READY timed out (make sure l2_ready is set before using gal_fast_l2dma_l2_to_mem_start)";
	u32 timeout = 0;
#ifdef DMA_DIAGNOSIS
	uint32_t busy_loop_count = 0;
#endif

	if (num_transactions == 1) {
		/* In case L1 <-> L2 transaction is not finished
		 * wait for the background fragment to set the l2_ready
		 */
		if (GAL_L2DMA_APC_ID_0 == apc_id) {
			while (!gal_fast_apuc_cond(GAL_FAST_APUC_COND_L2_READY_A)) {
				if (timeout++ > GAL_FAST_L2DMA_TIMEOUT)
					gsi_fatal("%s", timeout_error);
			}
			while (apc0_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
				BUSY_LOOP()
			}
			mapc0_l2dma_queue_l2_to_mem_m64(transactions[0].l2_col_group, transactions[0].l4_addr, transactions[0].step_size_num_512b_chunk, l2_ready_attr);
		} else {
			while (!gal_fast_apuc_cond(GAL_FAST_APUC_COND_L2_READY_B)) {
				if (timeout++ > GAL_FAST_L2DMA_TIMEOUT)
					gsi_fatal("%s", timeout_error);
			}
			while (apc1_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
				BUSY_LOOP()
			}
			mapc1_l2dma_queue_l2_to_mem_m64(transactions[0].l2_col_group, transactions[0].l4_addr, transactions[0].step_size_num_512b_chunk, l2_ready_attr);
		}
	} else {        /* num_transactions == 2 */
		if (GAL_L2DMA_APC_ID_0 == apc_id) {
			while (!gal_fast_apuc_cond(GAL_FAST_APUC_COND_L2_READY_A)) {
				if (timeout++ > GAL_FAST_L2DMA_TIMEOUT)
					gsi_fatal("%s", timeout_error);
			}
			while (apc0_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
				BUSY_LOOP()
			}
			mapc0_l2dma_queue_l2_to_mem_m64(transactions[0].l2_col_group, transactions[0].l4_addr, transactions[0].step_size_num_512b_chunk, GAL_L2DMA_L2_READY_NOP);
			while (apc0_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
				BUSY_LOOP()
			}
			mapc0_l2dma_queue_l2_to_mem_m64(transactions[1].l2_col_group, transactions[1].l4_addr, transactions[1].step_size_num_512b_chunk, l2_ready_attr);
		} else {
			while (!gal_fast_apuc_cond(GAL_FAST_APUC_COND_L2_READY_B)) {
				if (timeout++ > GAL_FAST_L2DMA_TIMEOUT)
					gsi_fatal("%s", timeout_error);
			}
			while (apc1_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
				BUSY_LOOP()
			}
			mapc1_l2dma_queue_l2_to_mem_m64(transactions[0].l2_col_group, transactions[0].l4_addr, transactions[0].step_size_num_512b_chunk, GAL_L2DMA_L2_READY_NOP);
			while (apc1_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
				BUSY_LOOP()
			}
			mapc1_l2dma_queue_l2_to_mem_m64(transactions[1].l2_col_group, transactions[1].l4_addr, transactions[0].step_size_num_512b_chunk, l2_ready_attr);
		}
	}
}

/*
 * gal_fast_l2dma_mem_to_l2_start_indirect - Copy data from specific L2-APC to the L4 .
 *
 * Input:
 *         @apc_id - L2-APC-# (0 - L2-APC 0/ 1 - L2-APC-1).
 *         @num_transactions -  Number of transactions to do.
 *         @transactions - Array of transactions.
 *         @l2_ready_attr - l2_ready state for the L2-APC-# after all transactions ended.
 *
 * Comments:
 *         See L2DMA transaction description in libgal.h.
 *         There is no use of transactions->l4_addr in this function.
 *        After calling this function you must call to gal_fast_l2dma_sync() or gal_fast_sync_many() for transactions completion.
 *        If the number of transactions is 1 or 2, the L2T mode is GAL_L2T_MODE_64 and each tratransaction is only one step, the L2DMA work without interrupts.
 */
static inline __attribute__((always_inline)) void gal_fast_l2dma_l2_to_mem_start_indirect(uint apc_id, uint num_transactions, struct gal_fast_l2dma_l4_l2_transaction *transactions, enum gal_l2dma_cmd_attr l2_ready_attr)
{
	GSI_DEBUG_ASSERT(gal_fast_l2dma_is_txns_valid(num_transactions, transactions));
	const char *timeout_error = "COND_L2_READY timed out (make sure l2_ready is set before using gal_fast_l2dma_l2_to_mem_start)";
	u32 timeout = 0;
#ifdef DMA_DIAGNOSIS
	uint32_t busy_loop_count = 0;
#endif

	if (num_transactions == 1) {
		/* In case L1 <-> L2 transaction is not finished
		 * wait for the background fragment to set the l2_ready
		 */
		if (GAL_L2DMA_APC_ID_0 == apc_id) {
			while (!gal_fast_apuc_cond(GAL_FAST_APUC_COND_L2_READY_A)) {
				if (timeout++ > GAL_FAST_L2DMA_TIMEOUT)
					gsi_fatal("%s", timeout_error);
			}
			while (apc0_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
				BUSY_LOOP()
			}
			mapc0_l2dma_queue_l2_to_mem_m64_indirect(transactions[0].l2_col_group, transactions[0].step_size_num_512b_chunk, l2_ready_attr);
		} else {
			while (!gal_fast_apuc_cond(GAL_FAST_APUC_COND_L2_READY_B)) {
				if (timeout++ > GAL_FAST_L2DMA_TIMEOUT)
					gsi_fatal("%s", timeout_error);
			}
			while (apc1_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
				BUSY_LOOP()
			}
			mapc1_l2dma_queue_l2_to_mem_m64_indirect(transactions[0].l2_col_group, transactions[0].step_size_num_512b_chunk, l2_ready_attr);
		}
	} else {        /* num_transactions == 2 */
		if (GAL_L2DMA_APC_ID_0 == apc_id) {
			while (!gal_fast_apuc_cond(GAL_FAST_APUC_COND_L2_READY_A)) {
				if (timeout++ > GAL_FAST_L2DMA_TIMEOUT)
					gsi_fatal("%s", timeout_error);
			}
			while (apc0_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
				BUSY_LOOP()
			}
			mapc0_l2dma_queue_l2_to_mem_m64_indirect(transactions[0].l2_col_group, transactions[0].step_size_num_512b_chunk, GAL_L2DMA_L2_READY_NOP);
			while (apc0_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
				BUSY_LOOP()
			}
			mapc0_l2dma_queue_l2_to_mem_m64_indirect(transactions[1].l2_col_group, transactions[1].step_size_num_512b_chunk, l2_ready_attr);
		} else {
			while (!gal_fast_apuc_cond(GAL_FAST_APUC_COND_L2_READY_B)) {
				if (timeout++ > GAL_FAST_L2DMA_TIMEOUT)
					gsi_fatal("%s", timeout_error);
			}
			while (apc1_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
				BUSY_LOOP()
			}
			mapc1_l2dma_queue_l2_to_mem_m64_indirect(transactions[0].l2_col_group, transactions[0].step_size_num_512b_chunk, GAL_L2DMA_L2_READY_NOP);
			while (apc1_l2dma_get_cmd_lo_reg_uc() & (GAL_FAST_L2DMA_CMD_LOW_ENABLE_MASK)) {
				BUSY_LOOP()
			}
			mapc1_l2dma_queue_l2_to_mem_m64_indirect(transactions[1].l2_col_group, transactions[0].step_size_num_512b_chunk, l2_ready_attr);
		}
	}
}

/*
 * gal_fast_event - Write event to L3 buffer
 *
 * Input:
 *         @buffer - L3 buffer address
 *         @event - Event to write to the buffer.
 *
 * Comments:
 *         The buffer can contain up to 256(L3_DEBUG_BUFFER_SIZE/sizeof(u32)) events at the same time, additional event will delete the oldest event.
 */
static inline __attribute__((always_inline)) void gal_fast_event(u32 buffer, u32 event)
{
	//	The first 4 bytes represnt the buffer index
	volatile _Uncached u32 *l3_block_idx = (volatile _Uncached u32 *)buffer - 1;
	volatile _Uncached u32 *l3_block = (volatile _Uncached u32 *)buffer;

//	Buffer size is L3_DEBUG_BUFFER_SIZE/sizeof(u32), to get the index in power of 2 buffer size we can do AND with size-1.
	*l3_block_idx &= 255;

	*(l3_block + *l3_block_idx) = event;
	++(*l3_block_idx);
}

/*
 * gal_fast_set_l4_dma_desc - set the descriptors for the L4 DMA for both APC's and activate it.
 *
 * Input:
 *         @cmd_desc - a command descriptors.
 * 		   @type - type of transaction (read/write).
 *
 * Return value:
 *
 * 			= 0 - OK.
 *  		!= 0 - error code
 *
 * Comments:
 * 			- cmd_desc.num_l4_addrs must be <= 32
 * 			- cmd_desc.repeat must be <= 4095
 * 			- This function should only be called when indirect mode is enabled, if the function is called in
 * 			  direct mode then the next time l2dma will be called in indirect mode undefined behavior could occur.
 * 			- the function prepares the descriptors for both APC's, if there is a need to work with a single APC then DIRECT DMA mode should be used.
 * 			- The function should not be called again until the L2 DMA has finished transfering all the data that was described in the descriptors,
 * 			  if the function is called before the DMA has finished with all the L4 descriptors the function will block until the DMA has finished.
 * 			- currently l2t_mode and step_stride_in_col_group are unused.
 */
static inline __attribute__((always_inline)) void gal_fast_set_l4_dma_desc(struct gal_l4dma_cmd_desc *cmd_desc, enum gal_l4_dma_transaction_type type)
{
	uint32_t cmd_offset = GAL_FAST_MB_READ_CMD_OFFSET;
	uint32_t db_offset = GAL_FAST_READ_DB_OFFSET; 
	uint32_t db = 0, mb_offset = 0x0, total_APC_addrs = 0;
	uint32_t is_last = 1, reserved = 0, apuc_num;
	
	uint32_t *ctrl_reg = (uint32_t *)0xF0000000;
	apuc_num = *ctrl_reg & GAL_FAST_CORE_BIT_MASK;

	uint32_t request_in_progress_addr = GAL_FAST_INDIRECT_RD_REQUEST_IN_PROGRESS_GPR4_REG_ADDRESS;

	if(type == GAL_L4DMA_WRITE) {
 		cmd_offset = GAL_FAST_MB_WRITE_CMD_OFFSET;
		db_offset = GAL_FAST_WRITE_DB_OFFSET;
		request_in_progress_addr = GAL_FAST_INDIRECT_WR_REQUEST_IN_PROGRESS_GPR5_REG_ADDRESS;
	}

	while(gal_fast_cache_uc_u32_rd(request_in_progress_addr));
	gal_fast_cache_uc_u32_wr(request_in_progress_addr, 1);

	gal_fast_cache_uc_u32_wr(GAL_FAST_MB0_ADDRESS + cmd_offset + GAL_FAST_MB_CONTROL_WORD_OFFSET , (is_last << 31) | (reserved << 30) | ( (cmd_desc->repeat - 1) << 18) | apuc_num << 16 | (cmd_desc->step_size - 1));
	gal_fast_cache_uc_u32_wr(GAL_FAST_MB0_ADDRESS + cmd_offset + GAL_FAST_MB_L2T_MODE_CONTROL_WORD_OFFSET, (cmd_desc->interleaved_factor << 24) | (cmd_desc->padding << 12) | reserved << 10 | reserved << 8 | cmd_desc->num_l4_addrs);
	gal_fast_cache_uc_u32_wr(GAL_FAST_MB0_ADDRESS + cmd_offset + GAL_FAST_MB_L4_STEP_STRIDE_OFFSET, cmd_desc->l4_step_stride);

	total_APC_addrs = cmd_desc->num_l4_addrs * 2;

	for(uint i = 0; i < total_APC_addrs; i+=2, mb_offset += 0x4) {
		gal_fast_cache_uc_u32_wr(GAL_FAST_MB0_ADDRESS + cmd_offset + GAL_FAST_MB_L4_ADDRS_APC_A_OFFSET + mb_offset, (uint32_t)cmd_desc->APC_l4_addr[i]);
		gal_fast_cache_uc_u32_wr(GAL_FAST_MB0_ADDRESS + cmd_offset + GAL_FAST_MB_L4_ADDRS_APC_B_OFFSET + mb_offset, (uint32_t)cmd_desc->APC_l4_addr[i + 1]);
	}

	gal_fast_cache_uc_u32_wr(GAL_FAST_DB_BASE_ADDR + db_offset, db);
}

#endif /* GAL_FAST_FUNCS_H_ */

