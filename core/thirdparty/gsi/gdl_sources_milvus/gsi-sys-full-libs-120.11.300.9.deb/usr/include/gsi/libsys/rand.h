/*
 * Copyright (C) 2016, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */

#ifndef GSI_RAND_H
#define GSI_RAND_H

#include "config.h"

#if defined(GSI_LIBSYS_AARCH64) || defined(GSI_LIBSYS_X86_64) || defined(GSI_LIBSYS_X86_32)

#include <stdlib.h>
#include "types.h"
#include "assert.h"

extern void SimpleRNG_SetState(unsigned int u, unsigned int v);
extern void SimpleRNG_GetState(unsigned int *up, unsigned int *vp);
extern unsigned int SimpleRNG_GetUint2(unsigned int *up, unsigned int *vp);
extern unsigned int SimpleRNG_GetUint(void);

/* Get uniform distribution in the open range (0, 1) */
extern double SimpleRNG_GetUniform2(unsigned int *up, unsigned int *vp);
extern double SimpleRNG_GetUniform(void);

/*
 * Get normal (Gaussian) random sample with specified mean and standard deviation
 * @standardDeviation must be positive non-zero
 */
extern double SimpleRNG_GetNormal2(double mean, double standardDeviation);

static inline double SimpleRNG_GetNormal(void)
{
	return SimpleRNG_GetNormal2(/* mean */ 0.0, /* standardDeviation */ 1.0);
}

/*
 * Get exponential random sample with specified mean
 * @mean must be positive non-zero
 */
extern double SimpleRNG_GetExponential(double mean /* = 1.0 */);

/*
 * Get gamma random sample with specified shape and scale
 * @shape must be positive non-zero
 */
extern double SimpleRNG_GetGamma(double shape, double scale);

/* A chi squared distribution with n degrees of freedom */
extern double SimpleRNG_GetChiSquare(double degreesOfFreedom);

extern double SimpleRNG_GetInverseGamma(double shape, double scale);

extern double SimpleRNG_GetWeibull(double shape, double scale);

/* @scale must be positive */
extern double SimpleRNG_GetCauchy(double median, double scale);

/* @degreesOfFreedom must be positive */
extern double SimpleRNG_GetStudentT(double degreesOfFreedom);

// The Laplace distribution is also known as the double exponential distribution.
extern double SimpleRNG_GetLaplace(double mean, double scale);

extern double SimpleRNG_GetLogNormal(double mu, double sigma);

/* @a and @b must be positive */
extern double SimpleRNG_GetBeta(double a, double b);

extern int SimpleRNG_PoissonSmall(double lambda);
extern int SimpleRNG_PoissonLarge(double lambda);

static inline int SimpleRNG_GetPoisson(double lambda)
{
	return (lambda < 30.0) ? SimpleRNG_PoissonSmall(lambda) : SimpleRNG_PoissonLarge(lambda);
}

extern double SimpleRNG_LogFactorial(int n);

#define	GSI_RAND_MAX	((uint)RAND_MAX)

void gsi_srandom(uint seed);

/*
 * Return a random non-negative integer
 * not thread safe!
 */
static inline uint gsi_random(void)
{
	return SimpleRNG_GetUint();
}

/* returns an integer in the range [0, max] */
extern uint gsi_random_at_most(uint max);

/* returns an integer in the range [min, max) */
static inline int gsi_random_range(int min, int max)
{
	GSI_ASSERT(max > min);
	return min + gsi_random_at_most(max - min - 1);
}

/* like gsi_random_range but for doubles */
extern double gsi_random_range_double(double min, double max);

static inline bool gsi_random_bit(void)
{
	return gsi_random_range(0, 2);
}

/* returns random 8 bits */
static inline u8 gsi_random_8(void)
{
	return (u8)gsi_random();
}

/* returns random 16 bits */
static inline u16 gsi_random_16(void)
{
	return (u16)gsi_random();
}

/* returns random 32 bits */
static inline u32 gsi_random_32(void)
{
	return (u32)gsi_random();
}

/* returns random 64 bits */
static inline u64 gsi_random_64(void)
{
	return ((u64)gsi_random_32() << 32) | gsi_random_32();
}

extern void gsi_random_memset(void *buf, size_t size);

#endif /* defined(GSI_LIBSYS_AARCH64) || defined(GSI_LIBSYS_X86_64) || defined(GSI_LIBSYS_X86_32) */

#endif /* GSI_RAND_H */
