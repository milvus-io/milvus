/*
 * API for Host code running User Tasks remotely on GSI's APU System
 *
 * Copyright (C) 2016, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */
#ifndef GSI_TEST_API_H
#define GSI_TEST_API_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef GSI_LIBSYS_X86_64
#define GSI_LIBSYS_X86_64
#endif
#include <gsi/libsys.h>

#include <gsi/libgdl.h>
#include <gsi/gsi_sim_config.h>

struct gdtl_sim_config {
	uint sim_num_contexts;
	struct gsi_sim_contexts sim_ctxs[GSI_SIM_MAX_SIM_CONTEXTS];
};

struct gdtl_updated_by_argv {
	bool seed;
	bool num_iters;
	bool mode;
	bool sim_config;
};

typedef enum  {
	GDTL_SIMULATOR_INITTED,
	GDTL_HARDWARE_INITTED,
	GDTL_ALREADY_INNITED,
	GDTL_FAILURE,
} gdtl_return_status;

enum gdtl_mode {
	GDTL_MODE_INVALID = -1,
	GDTL_MODE_DEFAULT = 0,
	GDTL_MODE_NIGHTLY = 1,
};

struct gdtl_config {
	int seed;
	int num_iters;
	enum gdtl_mode mode;
	struct gdtl_sim_config sim_config;
	struct gdtl_updated_by_argv updated_status;
};

/*
 * gdtl_init -  initializes the gsi device test library
 *
 * Input:
 *   @argc - command line options recieved from the application
 *   @argv - command line options recieved from the application
 *   @app_opts - additional options to be used in the application ( can be NULL )
 *
 * Output:
 *   config -  a struct to be filled with the parameters of the current application.
 * 		       could be either default values or command line parameters that were given and parsed.
 * 			   can be NULL.
 *
 * Return value:
 * 	 status according to the enum gdtl_return_status
 *
 * Comments:
 *	 in addition to parsing the paramaters, the function initalizes the simulator if needed, inits the gsi device library (gdl) and allocates all the
 *   contexts that are available.
 *	 the struct gdtl_updated_by_argv is used to determine whether the gdtl_config parameters were
 *	 updated by command line options or by the default values of the gdtl.
 */
gdtl_return_status gdtl_init(int argc, char *argv[], struct gdtl_config *config, struct gsi_option *app_opts);

/*
 * gdtl_exit -  exits from the gsi device test library
 *
 * Input:
 *   @test_name - the name of the current application/test. (can be NULL)
 *   @ret - a retval to be checked whether the test was succesful.
 *
 *
 * Comments:
 * 	the function shuts down the simulator if needed , relinquishes all the contexts and
 * 	calls the gsi device library (gdl) exit.
 */
void gdtl_exit(const char *test_name, int ret);

/*
 * gdtl_get_contexts -  retrieves the contexts handles that were allocated
 *
 * Input:
 *   @length - the length of the contexts handle array to specify how many handles to recieve information about
 *
 * Output:
 *   handle -  an array of contexts handles to be filled with the contexts id that were allocated
 *
 * Comments:
 *   incase length is greater than the number of contexts the remaining handles will receive
 *   an invalid context handle ( = -1).
 *   if length requested in smaller than the number of contexts only the amount requested will be
 * 	 filled with a valid handle.
 */
void gdtl_get_contexts(gdl_context_handle_t *handle, uint length);

/*
 * gdtl_is_sim -  check whether the application is in simulator or hardware
 *
 * * Return value:
 * 	 = 1 - true
 *   = 0 - false
 *
 * Comments:
 *	incase the function is called when running on hardware the error code ENOSYS will be returned
 */
bool gdtl_is_sim(void);

#define gdtl_test_fatal(_test_name_, _ret_, ...) do { \
	gdtl_exit(_test_name_, _ret_); \
	gsi_fatal(__VA_ARGS__); \
} while (0)


#ifdef __cplusplus
}
#endif

#endif /* GSI_TEST_API_H */
