/*
 * GSI Device Library for Host code running User Tasks remotely on GSI's APU System
 *
 * Copyright (C) 2019, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */
#ifndef GSI_PREPROC_DEFS_H_
#define GSI_PREPROC_DEFS_H_

#include <stdint.h>

#include <gsi/apl_defs.h>
#include <gsi/seu_inst.h>

#ifndef bool
#define bool    _Bool
#endif

#ifndef true
#define true    1
#endif

#ifndef false
#define false   0
#endif

#define _DIV_ROUND_DOWN_NUM(x, n)	((x) / (n))
#define _DIV_ROUND_UP_NUM(x, n)		_DIV_ROUND_DOWN_NUM((x) + (n) - 1, (n))

#define likely(x)       __builtin_expect((x),true)
#define unlikely(x)     __builtin_expect((x),false)


enum sm_regs {
	SM_REG_0 = 0,
	SM_REG_1 = 1,
	SM_REG_2 = 2,
	SM_REG_3 = 3,
	SM_REG_4 = 4,
	SM_REG_5 = 5,
	SM_REG_6 = 6,
	SM_REG_7 = 7,
	SM_REG_8 = 8,
	SM_REG_9 = 9,
	SM_REG_10 = 10,
	SM_REG_11 = 11,
	SM_REG_12 = 12,
	SM_REG_13 = 13,
	SM_REG_14 = 14,
	SM_REG_15 = 15,

	NUM_SM_REGS,
};

enum rownum_regs {
	RN_REG_0 = 0,
	RN_REG_1 = 1,
	RN_REG_2 = 2,
	RN_REG_3 = 3,
	RN_REG_4 = 4,
	RN_REG_5 = 5,
	RN_REG_6 = 6,
	RN_REG_7 = 7,
	RN_REG_8 = 8,
	RN_REG_9 = 9,
	RN_REG_10 = 10,
	RN_REG_11 = 11,
	RN_REG_12 = 12,
	RN_REG_13 = 13,
	RN_REG_14 = 14,
	RN_REG_15 = 15,

	NUM_RN_REGS = 16,
};

enum rowmask_regs {
	RE_REG_0 = 0,
	RE_REG_1 = 1,
	RE_REG_2 = 2,
	RE_REG_3 = 3,
	NUM_RE_REGS = 4,

	EWE_REG_0 = 0,
	EWE_REG_1 = 1,
	EWE_REG_2 = 2,
	EWE_REG_3 = 3,
	NUM_EWE_REGS = 4,
};

typedef unsigned char u8;
typedef unsigned short int u16;

struct apl_seu_vliw {
	union seu_inst u[GSI_SPREADER_NUM_LANES];
};
enum gsi_seu_defs {
	/* APU Architecture Spec version 0.90,  2017-04-24 */
	GSI_SEU_IFR_ADDR_BIT = 0,
	GSI_SEU_IFR_ADDR_BITS = 13,
	GSI_SEU_IFR_ADDR_MASK = ((1 << GSI_SEU_IFR_ADDR_BITS) - 1) << GSI_SEU_IFR_ADDR_BIT,
	GSI_SEU_IFR_RESERVED_BIT = GSI_SEU_IFR_ADDR_BIT + GSI_SEU_IFR_ADDR_BITS,
	GSI_SEU_IFR_RESERVED_BITS = 3,
	GSI_SEU_IFR_LEN_BIT = GSI_SEU_IFR_RESERVED_BIT + GSI_SEU_IFR_RESERVED_BITS,
	GSI_SEU_IFR_LEN_BITS = 8,
	GSI_SEU_IFR_LEN_MASK = ((1 << GSI_SEU_IFR_LEN_BITS) - 1) << GSI_SEU_IFR_LEN_BIT,

	GSI_SEU_WREG_VAL_BITS = 24,
	GSI_SEU_WREG_VAL_MASK = (1 << GSI_SEU_WREG_VAL_BITS) - 1,

	/* APU Architecture Spec 2016-11-30, version 0.8 */
	SEU_IFIN1_BIT = 0,
	SEU_IFIN1_BITS = 4,
	SEU_IFIN1_MASK = ((1 << SEU_IFIN1_BITS) - 1) << SEU_IFIN1_BIT,
	SEU_IFIN0_BIT = SEU_IFIN1_BIT + SEU_IFIN1_BITS,
	SEU_IFIN0_BITS = 3,
	SEU_IFIN0_MASK = ((1 << SEU_IFIN0_BITS) - 1) << SEU_IFIN0_BIT,
	SEU_IFIN_REG_WIDTH = SEU_IFIN0_BITS + SEU_IFIN1_BITS,

	GSI_SEU_GLW_LANE = GSI_SPREADER_NUM_LANES - 1,
};

enum rdlogic_regs_vals {
	RDLOGIC_REG_RWINHSET = VALU_RDLOGIC_NUM_REGS - 2,
	RDLOGIC_REG_RWINHRST = VALU_RDLOGIC_NUM_REGS - 1,
};

#define SET_RD_ROW(idx, _smap_reg, _smap_shift, _smap_inv, sb1, sb2, sb3, _rdlogic_reg, _wmux_ctl, _winv)	\
	.inst[idx].read_rows.inst_type = SEU_INST_RD,				\
	.inst[idx].read_rows.smap_reg = _smap_reg,				\
	.inst[idx].read_rows.smap_shift = _smap_shift,				\
	.inst[idx].read_rows.smap_invert = _smap_inv,				\
	.inst[idx].read_rows.wmux_ctl = _wmux_ctl,				\
	.inst[idx].read_rows.winv = _winv,					\
	.inst[idx].read_rows.rdlogic_reg = _rdlogic_reg,			\
	.inst[idx].read_rows.rownum_reg_0 = sb1,				\
	.inst[idx].read_rows.rownum_reg_1 = sb2,				\
	.inst[idx].read_rows.rownum_reg_2 = sb3,

#define SET_RD_ROW_RWINH(idx, _smap_reg, _smap_shift, _smap_inv, sb1, sb2, sb3, _wmux_ctl, is_set)	\
	.inst[idx].read_rows.inst_type = SEU_INST_RD,				\
	.inst[idx].read_rows.smap_reg = _smap_reg,				\
	.inst[idx].read_rows.smap_shift = _smap_shift,				\
	.inst[idx].read_rows.smap_invert = _smap_inv,				\
	.inst[idx].read_rows.wmux_ctl = _wmux_ctl,				\
	.inst[idx].read_rows.winv = 0,						\
	.inst[idx].read_rows.rdlogic_reg =  ((is_set) ? RDLOGIC_REG_RWINHSET : RDLOGIC_REG_RWINHRST), \
	.inst[idx].read_rows.rownum_reg_0 = sb1,				\
	.inst[idx].read_rows.rownum_reg_1 = sb2,				\
	.inst[idx].read_rows.rownum_reg_2 = sb3,

#define SET_RD_WR_ROW(idx, _smap_reg, _smap_shift, _smap_inv, sb1, sb2, sb3, _rdlogic_reg, _wmux_ctl, _winv)	\
	.inst[idx].rdwr_rows.inst_type = SEU_INST_R2W1,				\
	.inst[idx].rdwr_rows.smap_reg = _smap_reg,				\
	.inst[idx].rdwr_rows.smap_shift = _smap_shift,				\
	.inst[idx].rdwr_rows.smap_invert = _smap_inv,				\
	.inst[idx].rdwr_rows.wmux_ctl = _wmux_ctl,				\
	.inst[idx].rdwr_rows.winv = _winv,					\
	.inst[idx].rdwr_rows.rdlogic_reg = _rdlogic_reg,			\
	.inst[idx].rdwr_rows.rownum_reg_0 = sb1,				\
	.inst[idx].rdwr_rows.rownum_reg_1 = sb2,				\
	.inst[idx].rdwr_rows.rownum_reg_2 = sb3,

#define SET_WR_ROW(idx, _smap_reg, _smap_shift, _smap_inv, sb1, sb2, sb3, _wmux_ctl, _winv, _wifval)	\
	.inst[idx].write_rows.inst_type = SEU_INST_WR,		\
	.inst[idx].write_rows.smap_reg = _smap_reg,		\
	.inst[idx].write_rows.smap_shift = _smap_shift,		\
	.inst[idx].write_rows.smap_invert = _smap_inv,		\
	.inst[idx].write_rows.wmux_ctl = _wmux_ctl,		\
	.inst[idx].write_rows.winv = _winv,			\
	.inst[idx].write_rows.wifval = _wifval,			\
	.inst[idx].write_rows.rownum_reg_0 = sb1,		\
	.inst[idx].write_rows.rownum_reg_1 = sb2,		\
	.inst[idx].write_rows.rownum_reg_2 = sb3,

#define SET_RD_MSK_SRC(idx, _smap_reg, _smap_shift, _smap_inv, _rdlogic_reg, _wmux_ctl, _winv)	\
	.inst[idx].rdwr_by_mask.inst_type = SEU_INST_RWM,				\
	.inst[idx].rdwr_by_mask.smap_reg = _smap_reg,					\
	.inst[idx].rdwr_by_mask.smap_shift = _smap_shift,				\
	.inst[idx].rdwr_by_mask.smap_invert = _smap_inv,				\
	.inst[idx].rdwr_by_mask.wmux_ctl = _wmux_ctl,					\
	.inst[idx].rdwr_by_mask.winv = _winv,						\
	.inst[idx].rdwr_by_mask.wifval = 0,						\
	.inst[idx].rdwr_by_mask.rdlogic_reg = _rdlogic_reg,				\
	.inst[idx].rdwr_by_mask.re_en = 1,						\
	.inst[idx].rdwr_by_mask.re_reg = (1 << VALU_ROWMASK_REGS_BITS) - 1,		\
	.inst[idx].rdwr_by_mask.ewe_en = 0,						\
	.inst[idx].rdwr_by_mask.ewe_reg = (1 << VALU_ROWMASK_REGS_BITS) - 1,		\
	.inst[idx].rdwr_by_mask.row_mask_shift = 0,					\
	.inst[idx].rdwr_by_mask.row_mask_invert = 0,

#define SET_RD_MSK(idx, _smap_reg, _smap_shift, _smap_inv, _rdlogic_reg)		\
	.inst[idx].rdwr_by_mask.inst_type = SEU_INST_RWM,				\
	.inst[idx].rdwr_by_mask.smap_reg = _smap_reg,					\
	.inst[idx].rdwr_by_mask.smap_shift = _smap_shift,				\
	.inst[idx].rdwr_by_mask.smap_invert = _smap_inv,				\
	.inst[idx].rdwr_by_mask.wmux_ctl = 0,						\
	.inst[idx].rdwr_by_mask.winv = 0,						\
	.inst[idx].rdwr_by_mask.wifval = 0,						\
	.inst[idx].rdwr_by_mask.rdlogic_reg = _rdlogic_reg,				\
	.inst[idx].rdwr_by_mask.re_en = 1,						\
	.inst[idx].rdwr_by_mask.re_reg = (1 << VALU_ROWMASK_REGS_BITS) - 1,		\
	.inst[idx].rdwr_by_mask.ewe_en = 0,						\
	.inst[idx].rdwr_by_mask.ewe_reg = (1 << VALU_ROWMASK_REGS_BITS) - 1,		\
	.inst[idx].rdwr_by_mask.row_mask_shift = 0,					\
	.inst[idx].rdwr_by_mask.row_mask_invert = 0,

#define SET_RD_RWM(idx, _smap_reg, _smap_shift, _smap_inv, _rdlogic_reg, _wmux_ctl, _winv, _re_reg, _row_mask_shift, _row_mask_invert)	\
	.inst[idx].rdwr_by_mask.inst_type = SEU_INST_RWM,				\
	.inst[idx].rdwr_by_mask.smap_reg = _smap_reg,					\
	.inst[idx].rdwr_by_mask.smap_shift = _smap_shift,				\
	.inst[idx].rdwr_by_mask.smap_invert = _smap_inv,				\
	.inst[idx].rdwr_by_mask.wmux_ctl = _wmux_ctl,					\
	.inst[idx].rdwr_by_mask.winv = _winv,						\
	.inst[idx].rdwr_by_mask.wifval = 0,						\
	.inst[idx].rdwr_by_mask.rdlogic_reg = _rdlogic_reg,				\
	.inst[idx].rdwr_by_mask.re_en = 1,						\
	.inst[idx].rdwr_by_mask.re_reg = _re_reg,					\
	.inst[idx].rdwr_by_mask.ewe_en = 0,						\
	.inst[idx].rdwr_by_mask.ewe_reg = (1 << VALU_ROWMASK_REGS_BITS) - 1,		\
	.inst[idx].rdwr_by_mask.row_mask_shift = _row_mask_shift,			\
	.inst[idx].rdwr_by_mask.row_mask_invert = _row_mask_invert,

#define SET_WR_RWM(idx, _smap_reg, _smap_shift, _smap_inv, _wmux_ctl, _winv, _wifval, _ewe_reg, _row_mask_shift, _row_mask_invert)	\
	.inst[idx].rdwr_by_mask.inst_type = SEU_INST_RWM,				\
	.inst[idx].rdwr_by_mask.smap_reg = _smap_reg,					\
	.inst[idx].rdwr_by_mask.smap_shift = _smap_shift,				\
	.inst[idx].rdwr_by_mask.smap_invert = _smap_inv,				\
	.inst[idx].rdwr_by_mask.wmux_ctl = _wmux_ctl,					\
	.inst[idx].rdwr_by_mask.winv = _winv,						\
	.inst[idx].rdwr_by_mask.wifval = _wifval,					\
	.inst[idx].rdwr_by_mask.rdlogic_reg = 0,					\
	.inst[idx].rdwr_by_mask.re_en = 0,						\
	.inst[idx].rdwr_by_mask.re_reg = (1 << VALU_ROWMASK_REGS_BITS) - 1,		\
	.inst[idx].rdwr_by_mask.ewe_en = 1,						\
	.inst[idx].rdwr_by_mask.ewe_reg = _ewe_reg,					\
	.inst[idx].rdwr_by_mask.row_mask_shift = _row_mask_shift,			\
	.inst[idx].rdwr_by_mask.row_mask_invert = _row_mask_invert,

#define RWINH_SET_RST(idx, is_set, _smap_reg, _smap_shift, _smap_inv)	\
	.inst[idx].rdwr_by_mask.inst_type = SEU_INST_RWM,				\
	.inst[idx].rdwr_by_mask.smap_reg = _smap_reg,					\
	.inst[idx].rdwr_by_mask.smap_shift = _smap_shift,				\
	.inst[idx].rdwr_by_mask.smap_invert = _smap_inv,				\
	.inst[idx].rdwr_by_mask.wmux_ctl = 0,						\
	.inst[idx].rdwr_by_mask.winv = 0,						\
	.inst[idx].rdwr_by_mask.wifval = 0,						\
	.inst[idx].rdwr_by_mask.rdlogic_reg = ((is_set) ? RDLOGIC_REG_RWINHSET : RDLOGIC_REG_RWINHRST), \
	.inst[idx].rdwr_by_mask.re_en = 1,						\
	.inst[idx].rdwr_by_mask.re_reg = (1 << VALU_ROWMASK_REGS_BITS) - 1,		\
	.inst[idx].rdwr_by_mask.ewe_en = 0,						\
	.inst[idx].rdwr_by_mask.ewe_reg = (1 << VALU_ROWMASK_REGS_BITS) - 1,		\
	.inst[idx].rdwr_by_mask.row_mask_shift = 0,					\
	.inst[idx].rdwr_by_mask.row_mask_invert = 0,

#define SET_RSP16(idx, _smap_reg, _smap_shift, _smap_inv)	\
	.inst[idx].rvd.inst_type = SEU_INST_RVD,		\
	.inst[idx].rvd.smap_reg = _smap_reg,			\
	.inst[idx].rvd.smap_shift = _smap_shift,		\
	.inst[idx].rvd.smap_invert = _smap_inv,			\
	.inst[idx].rvd.rsp16 = 1,


#define SET_GL_GGL(idx, _smap_reg, _smap_shift, _smap_inv, gl, ggl)	\
	.inst[idx].rvd.inst_type = SEU_INST_RVD,			\
	.inst[idx].rvd.smap_reg = _smap_reg,				\
	.inst[idx].rvd.smap_shift = _smap_shift,			\
	.inst[idx].rvd.smap_invert = _smap_inv,				\
	.inst[idx].rvd.rvd4 = ggl,					\
	.inst[idx].rvd.rvd16 = gl,

#define GLW_INST()	\
	.inst[GSI_SEU_GLW_LANE].global_io.inst_type = SEU_INST_GLW,

#define L1_LOAD_STORE(store, _l1_reg, _l1_row_offs)	\
	.inst[GSI_SEU_GLW_LANE].global_io.l1_gre = !(store),		\
	.inst[GSI_SEU_GLW_LANE].global_io.l1_gwe = !!(store),		\
	.inst[GSI_SEU_GLW_LANE].global_io.l1_reg = _l1_reg,		\
	.inst[GSI_SEU_GLW_LANE].global_io.l1_bank_offs = 0,		\
	.inst[GSI_SEU_GLW_LANE].global_io.l1_grp_offs = 0,		\
	.inst[GSI_SEU_GLW_LANE].global_io.l1_row_offs = _l1_row_offs,

#define L1_LOAD_STORE_L2(store, _l1_reg, _l1_bank_offs, _l1_grp_offs, _l1_row_offs)	\
	.inst[GSI_SEU_GLW_LANE].global_io.l1_l2_mode = true,		\
	.inst[GSI_SEU_GLW_LANE].global_io.l1_gre = !(store),		\
	.inst[GSI_SEU_GLW_LANE].global_io.l1_gwe = !!(store),		\
	.inst[GSI_SEU_GLW_LANE].global_io.l1_reg = _l1_reg,		\
	.inst[GSI_SEU_GLW_LANE].global_io.l1_bank_offs = _l1_bank_offs,	\
	.inst[GSI_SEU_GLW_LANE].global_io.l1_grp_offs = _l1_grp_offs,	\
	.inst[GSI_SEU_GLW_LANE].global_io.l1_row_offs = _l1_row_offs,

#define L2_LOAD_STORE(store, _l2_row_offs)	\
	.inst[GSI_SEU_GLW_LANE].global_io.l2_gre = !(store),		\
	.inst[GSI_SEU_GLW_LANE].global_io.l2_gwe = !!(store),		\
	.inst[GSI_SEU_GLW_LANE].global_io.l2_row_offs = _l2_row_offs,

#define L2_END_()	\
	.inst[GSI_SEU_GLW_LANE].global_io.l2_end = 1,

#define RSP_START_RET_()	\
	.inst[GSI_SEU_GLW_LANE].global_io.rspStartRet = 1,

#define RSP_END_()	\
	.inst[GSI_SEU_GLW_LANE].global_io.rspEND = 1,

#define SET_RSP256()	\
	.inst[GSI_SEU_GLW_LANE].global_io.rsp256sel = 1,

#define SET_RSP2K()	\
	.inst[GSI_SEU_GLW_LANE].global_io.rsp2Ksel = 1,

#define SET_RSP32K()	\
	.inst[GSI_SEU_GLW_LANE].global_io.rsp32Ksel = 1,

#define NOOP_(idx, _fsel)	\
	.inst[idx].nop.inst_type = SEU_INST_NOOP, \
	.inst[idx].nop.fsel = (_fsel),

#define DBG_PRNT(idx, sb1, sb2, sb3)	\
	.inst[idx].dbg_prnt.inst_type = SEU_INST_DBG,	\
	.inst[idx].dbg_prnt.rownum_reg_0 = sb1,		\
	.inst[idx].dbg_prnt.rownum_reg_1 = sb2,		\
	.inst[idx].dbg_prnt.rownum_reg_2 = sb3,


struct apl_4lanes_valu_ins {
	union seu_inst inst[GSI_SPREADER_NUM_LANES];
} __attribute__((packed));

#define APLPP_ALIGNED(_nbytes_)	__attribute__ ((aligned (_nbytes_)))

struct apl_frag_desc {
	const struct apl_4lanes_valu_ins *const code;
	const char *const name;
	u32 *const ifr;
	const u8 num_instructions;
} APLPP_ALIGNED(sizeof(intptr_t) * 4);

void apl_run_frag(const char *apl_file, int apl_line, const char *frag_name, unsigned int frag_ifr);
unsigned short int apl_frag_error(const struct apl_frag_desc *frag);

#endif /*GSI_PREPROC_DEFS_H_ */
