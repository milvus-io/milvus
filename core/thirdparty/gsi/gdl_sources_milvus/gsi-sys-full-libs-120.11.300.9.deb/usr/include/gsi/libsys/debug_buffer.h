/*
 * Copyright (C) 2018, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */
#ifndef GSI_DEBUG_BUFFER_H
#define GSI_DEBUG_BUFFER_H

#include "debug.h"

#ifdef DEBUG_BUILD

struct gsi_debug_buffer {
	int debug_level;
	uint buf_size;
	uint count;
	char *buf;
};

struct gsi_debug_buffer *gsi_debug_buffer_create(int debug_level, uint buf_size);

/* Create a new debug buffer */
struct gsi_debug_buffer *gsi_debug_buffer_begin(int debug_level);

void _gsi_debug_buffer_printf(const char *file, int line, const char *func,
                              struct gsi_debug_buffer *db, const char *fmt, ...) __attribute__((format(printf, 5, 6)));

/* Print into a debug buffer using a format string
 *
 * Newlines are not added automatically.
 * Debug prefix of the call is added to the beginning of each line.
 * The buffer is automatically extended as needed.
 */
#define gsi_debug_buffer_printf(_db_, _fmt_, ...) do { \
	if ((_db_)->debug_level <= gsi_debug_module_level()) { \
		_gsi_debug_buffer_printf(__FILE__, __LINE__, __func__, _db_, _fmt_, ##__VA_ARGS__); \
	} \
} while (0)

/* Flush a debug buffer onto the output stream
 *
 * Newline will be added automatically if needed.
 * The buffer is reset and may be re-used for further debugging.
 */
void gsi_debug_buffer_flush(struct gsi_debug_buffer *);

/* Flush and destroy a debug buffer */
void gsi_debug_buffer_end(struct gsi_debug_buffer *);

#else // DEBUG_BUILD

struct gsi_debug_buffer;

static inline struct gsi_debug_buffer *gsi_debug_buffer_create(GSI_UNUSED(int debug_level), GSI_UNUSED(uint buf_size))
{
	return NULL;
}

static inline struct gsi_debug_buffer *gsi_debug_buffer_begin(GSI_UNUSED(int debug_level))
{
	return NULL;
}

/* Print into a debug buffer using a format string
 *
 * Newlines are not added automatically.
 * Debug prefix of the call is added to the beginning of each line.
 * The buffer is automatically extended as needed.
 */
static inline void gsi_debug_buffer_printf(GSI_UNUSED(struct gsi_debug_buffer *db), GSI_UNUSED(const char *fmt), ...)
{
}

/* Flush a debug buffer onto the output stream
 *
 * Newline will be added automatically if needed.
 * The buffer is reset and may be re-used for further debugging.
 */
static inline void gsi_debug_buffer_flush(GSI_UNUSED(struct gsi_debug_buffer *db))
{
}

/* Flush and destroy a debug buffer */
static inline void gsi_debug_buffer_end(GSI_UNUSED(struct gsi_debug_buffer *db))
{
}

#endif // DEBUG_BUILD

#endif /* GSI_DEBUG_BUFFER_H */
