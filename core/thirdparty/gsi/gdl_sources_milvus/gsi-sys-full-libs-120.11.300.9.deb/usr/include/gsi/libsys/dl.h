/*
 * Copyright (C) 2017, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */
#include <gsi/libsys/config.h>

#if defined(GSI_LIBSYS_X86_64) || defined(GSI_LIBSYS_X86_32)

#ifndef GSI_DL_H
#define GSI_DL_H

void *gsi_dlsym(void **cache, const char *name);

#endif /* GSI_DL_H */

#endif /* defined(GSI_LIBSYS_X86_64) || defined(GSI_LIBSYS_X86_32) */
