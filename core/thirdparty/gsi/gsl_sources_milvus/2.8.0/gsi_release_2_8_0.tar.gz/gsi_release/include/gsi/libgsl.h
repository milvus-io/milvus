/*
 * Copyright (C) 2019, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */

#ifndef GSI_LIBGSL_H
#define GSI_LIBGSL_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <stdint.h>
#include <stdbool.h>
#include <gsi/libgdl.h>
#include <gsi/libgsl_matrix.h>


/***************************
 * GSL LIBRARY DESCRIPTION
 ***************************
 * The GSI Search Library (GSL) provides methods to search for records inside a database (DB).
 * A GSL DB record contains list of features. Each DB may have a different type of feature.
 *
 * GSL DB features
 * ===============
 * GSL supports the following types of features:
 *   - bit-feature   : One bit per feature.
 *   - float-feature : One single precision floating point number
 *                     per feature.
 *
 * GSL DBs
 * =======
 * GSL handles the following kinds of DBs:
 *   - bdb       (bit-database):             Flat DB of bit-features. The number of bits
 *                                           per record must be a multiple of CHAR_BIT
 *   - fdb       (float-database):           Flat DB of float-features.
 *
 * GSL KNN search
 * ==============
 * The K-Nearest Neighbor (KNN) search process finds the K closest (most similar) records
 * from a given DB to a given new record (query).
 *
 * GSL KNN search distance/similarity methods
 * ==========================================
 * The distance/similarity method defines the distance/similarity between records.
 * It gets two records and returns a value that represents the distance (smaller is closer)
 * or similarity (bigger is more similar) between the two records.
 *
 * The GSL supports the following distance/similarity methods between
 * two feature records x[0..n] and y[0..n]:
 *
 *   Hamming distance (smaller is closer)
 *   ------------------------------------
 *      Feature type : bit-feature
 *      Distance     : sum(x[i] ^ y[i]) when {i = 0..n}
 *
 *   Tanimoto similarity (bigger is more similar)
 *   --------------------------------------------
 *      Feature type : bit-feature
 *      Similarity   : sum(x[i] & y[i]) / sum(x[i] & y[i]) when {i = 0..n}
 *
 *   Cosine similarity (bigger is more similar)
 *   ------------------------------------------
 *      Feature type : float-feature
 *      Similarity   : sum(x[i] * y[i]) when {i = 0..n}
 *
 *   NOTE: x and y should be normalized, i.e. sqrt(sum(x[i] * x[i])) <= 1 and
 *         sqrt(sum(y[i] * y[i])) <= 1 when {i = 0..n}
 *
 * GSL KNN search functions
 * ========================
 * GSL provides the following kinds of searches inside its DBs:
 *   - gsl_knn_hamming_bdb         : KNN hamming search inside bit-database
 *   - gsl_knn_tanimoto_bdb        : KNN tanimoto search inside bit-database
 *
 */


/********************
 *  GSL CONTEXT
 ********************/

/*
 * GSL Context
 * -----------
 * Used as a handle to a set of hardware resources, threads and APU
 * boards to indicate to GSL where it can allocate memory and which
 * boards it can use for search operations.
 */
typedef struct gsli_context *gsl_context;

/*
 * gsl_create_context - To create gsl_context based on hw_ctx
 *
 * Inputs:
 * 	@max_num_threads - The maximal number of threads this context may use. If 0 then GSL uses its default.
 * 			   The process may create more than @max_num_threads threads but at most @max_num_threads
 * 			   will be execute at the same time, except for negligible periods.
 *
 * NOTE: When hw_ctx is NULL or num_hw_ctxes is zero, the gsl_context is not using any device
 *       i.e. the process is executed only on host cpus
 */
int gsl_create_context(gsl_context *ctx, gdl_context_handle_t *hw_ctx, uint32_t num_hw_ctxes, uint32_t max_num_threads);

/* gsl_destroy_context - To destroy the gsl_context */
int gsl_destroy_context(gsl_context ctx);


/********************
 *  GSL ENCODING
 ********************/

/*
 * GSL Encoding
 * ------------
 * Used to encode float-feature records as bit-feature records by various
 * methods. GSL can encode both databases and queries.
 */

enum gsl_bdb_encoding {
	GSL_BDB_ENCODING_NONE = 0,
	GSL_BDB_ENCODING_LINEAR_LSH,
	GSL_BDB_ENCODING_NEURAL_HASH,
};

struct gsl_bdb_encoding_linear_lsh_desc {
	struct gsl_matrix_f32 hyperplane_matrix;
	struct gsl_matrix_f32 threshold_vector;
};

struct gsl_bdb_encoding_neural_hash_layer_desc {
	struct gsl_matrix_f32 matrix;
	struct gsl_matrix_f32 bias_vector;
};

#define GSL_BDB_ENCODING_NEURAL_HASH_MAX_LAYERS 3
struct gsl_bdb_encoding_neural_hash_desc {
	int num_layers;
	struct gsl_bdb_encoding_neural_hash_layer_desc layers[GSL_BDB_ENCODING_NEURAL_HASH_MAX_LAYERS];
};

struct gsl_bdb_encoding_desc {
	bool normalize; /* true  : Normalize vector before encoding
                         * false : Don't Normalize vector
                         */
	enum gsl_bdb_encoding bdb_encoding;
	union {
		struct gsl_bdb_encoding_linear_lsh_desc linear_lsh_desc;
		struct gsl_bdb_encoding_neural_hash_desc neural_hash_desc;
	};
};


/********************
 *  GSL DB HANDLES
 ********************/

/*
 * Used to hold records. The input data is copied into GSL, after creating
 * a database it is possible to release the input data.
 * Up to GSL_MAX_SPARE_RECS may be added to the database.
 */


#define GSL_MAX_SPARE_RECS 4000
#define GSL_NULL_DB_HDL NULL

typedef void *gsl_db_hdl;               /* general database handle */
typedef void *gsl_bdb_hdl;              /* bit-database handle */
typedef void *gsl_fdb_hdl;              /* float-database handle */

typedef void *gsl_clstr_db_hdl;         /* general clustered database handle */
typedef void *gsl_clstr_bdb_hdl;        /* clustered bit-database handle */

/* gsl_create/destroy_bdb - To create/destroy gsl bit-database handle */
int gsl_create_bdb(gsl_context ctx, gsl_bdb_hdl *bdbh, struct gsl_matrix_u1 *bdb);
int gsl_destroy_bdb(gsl_bdb_hdl bdbh);

/* gsl_create/destroy_fdb - To create/destroy gsl float-database handle */
int gsl_create_fdb(gsl_context ctx, gsl_fdb_hdl *fdbh, struct gsl_matrix_f32 *fdb, int normalize);
int gsl_destroy_fdb(gsl_fdb_hdl fdbh);

/* gsl_create/destroy_clstr_bdb - To create/destroy gsl clustered bit-database handle */
int gsl_create_clstr_bdb(gsl_context ctx, gsl_clstr_bdb_hdl *clstr_bdbh, struct gsl_clstr_matrix_u1 *clstr_bdb);
int gsl_destroy_clstr_bdb(gsl_clstr_bdb_hdl clstr_bdbh);

/* gsl_create_bdb_from_fdb - Create a bit-database by converting floating-point records */
int gsl_create_bdb_from_fdb(
        gsl_context ctx,
        gsl_bdb_hdl *bdbh,
        gsl_fdb_hdl fdb,
        struct gsl_bdb_encoding_desc *bdb_encoding_desc);

int gsl_get_recs_from_bdb(struct gsl_matrix_u1 *bdb_matrix, gsl_bdb_hdl bdb_hdl);

/************************
 *  GSL SEARCH SESSION
 ************************/
/*
 * The resources, participants and steps GSL takes to prepare for a
 * search are abstracted in a search session handle.
 * There are multiple functions that create a search session
 * handle to allow different kinds of searches.
 */

typedef struct gsli_search_session *gsl_search_session_hdl;

int gsl_search_session_destroy(gsl_search_session_hdl session_hdl);

/*************************
 *  GSL SEARCH FUNCTIONS
 *************************/

enum gsl_search_func {
	GSL_ALG_KNN_FIRST_SEARCH_FUNC,
	GSL_ALG_KNN_HAMMING_BDB = GSL_ALG_KNN_FIRST_SEARCH_FUNC,
	GSL_ALG_KNN_TANIMOTO_BDB,
	GSL_ALG_KNN_L2_FDB,
	GSL_ALG_KNN_COSIM_FDB,
	GSL_ALG_KNN_NUM_SEARCH_FUNCS
};

/*
 * An optional re-rank search step allows narrowing down the KNN
 * using a computationally expensive rerank_func and searching
 * only part of the database
 */
struct gsl_rerank_desc {
	enum gsl_search_func rerank_func;
	gsl_fdb_hdl fdbh;
	int max_k;
};

#include <gsi/libgsl_flat_hamming.h>
#include <gsi/libgsl_flat_tanimoto.h>
#include <gsi/libgsl_clstr_hamming.h>

/*************************
 *  GSL SEARCH IN FOCUS
 *************************/

/*
 * The concept of setting a search in focus is tied directly to the way GSL
 * views an application's lifetime. There are two phases, setup time and
 * search time.
 *
 * Search time is when the user queries a database, looking for the most
 * similar records. This phase should be as fast as possible.
 * Database and search session creation happens at setup time and enables
 * fast searches.
 *
 * The user describes the expected workload to GSL by calling gsl_search_in_focus().
 * GSL then does as much as it can to avoid heavy operations during search.
 * Workloads describe to GSL the database and the range of values that will
 * be seen during search.
 *
 * The user can create multiple search session per GSL context based on
 * the workloads expected by the application. However, only a single
 * search session can be in-focus per GSL context.
 */

int gsl_search_in_focus(gsl_search_session_hdl session_hdl);

/* gsl_version_str - gsl version string */
const char *gsl_version_str(void);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* GSI_LIBGSL_H */
