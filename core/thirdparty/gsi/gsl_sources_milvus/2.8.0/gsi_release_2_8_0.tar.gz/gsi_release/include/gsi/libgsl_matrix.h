/*
 * Copyright (C) 2020, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */

#ifndef GSI_LIBGSL_MATRIX_H
#define GSI_LIBGSL_MATRIX_H

#include <stdint.h>

/********************
 *  GSL MATRICES
 ********************/

/*
 * GSL normal matrices
 * -------------------
 * Used to represent queries, out_vals and out_indices.
 * Data is stored in C style / row major.
 */

struct gsl_matrix_f32 {
	uint32_t        row_size;
	uint32_t        row_stride;
	uint32_t        num_rows;
	float          *rows_f32;
};
struct gsl_matrix_u32 {
	uint32_t        row_size;
	uint32_t        row_stride;
	uint32_t        num_rows;
	uint32_t       *rows_u32;
};
struct gsl_matrix_u16 {
	uint32_t        row_size;
	uint32_t        row_stride;
	uint32_t        num_rows;
	uint16_t       *rows_u16;
};
struct gsl_matrix_u1 {
	uint32_t        row_size;
	uint32_t        row_stride;
	uint32_t        num_rows;
	void           *rows_u1;
};

/*
 * GSL clustered matrices
 * ----------------------
 * Used to represent clusters of records.
 * Data is stored in C style / row major.
 */
struct gsl_clstr_u1 {
	uint32_t        num_rows;
	void           *rows_u1;
};

struct gsl_clstr_matrix_u1 {
	uint32_t                row_size;
	uint32_t                row_stride;
	uint32_t                num_clstrs;
	struct gsl_clstr_u1    *clstrs_u1;
};

#endif /* GSI_LIBGSL_MATRIX_H */
