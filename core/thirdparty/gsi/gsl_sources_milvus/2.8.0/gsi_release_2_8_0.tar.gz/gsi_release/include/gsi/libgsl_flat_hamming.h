/*
 * Copyright (C) 2020, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */

#ifndef GSI_LIBGSL_FLAT_HAMMING_H
#define GSI_LIBGSL_FLAT_HAMMING_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <gsi/libgsl.h>

/* Hamming flat search
 *
 * In a flat search, each query is searched against the entire database.
 * The functions in this header are based on Hamming distance.
 *
 * GSL provides two ways of using Hamming distance. In the first one,
 * GSL expects all inputs to be binary-feature records. GSL find the
 * nearest neighbors for each query according to their Hamming
 * distance.
 * To choose this, create a search session with a value of NULL
 * for the "encoding" and "rerank" members of "hamming_desc" parameters.
 * Use the function "gsl_flat_hamming_search_u1()" to search.
 *
 * Alternatively, users can call "gsl_flat_hamming_search_f32()" which
 * accepts floating-point queries.
 * In this scenario, the input queries have floating-point features, and
 * the search is made up of 2 or 3 steps:
 * 1. Encode floating-point queries as binary queries
 * 2. Perform Hamming search to find the "k" nearest
 *    neighbors to each binary query.
 * 3. Optionally, use the original floating-point queries and
 *    floating-point database to refine the results from the
 *    prvious step.
 *    GSL computes the cosine similarity ratio for a query and
 *    each of its nearest neighbors found in step 2. It uses
 *    the floating-point query and floating-point record to find
 *    the closest neighbors, based on the value of the rerank-k.
 *
 * By using the optional re-rank step, gsl_flat_hamming_search_f32()
 * approximates cosine similarity.
 * The quality of the results depends on the extent that Hamming distance
 * between encoded records reflects the cosine distance between
 * their original floating-point records.
 *
 */
struct gsl_flat_hamming_desc {
	int typical_num_queries;
	int max_num_queries;

	/* Use NULL for gsl_flat_hamming_search_u1() */
	struct gsl_bdb_encoding_desc *encoding;

	/* Binary database for Hamming search step, never NULL */
	gsl_bdb_hdl hamming_bdbh;
	/*
	 * Max number of nearest neighbors for each query
	 * according to Hamming search.
	 */
	int max_k;

	/*
	 * Re-rank step descriptor. A re-rank step
	 * implies an encoding step. The re-rank
	 * function must be GSL_ALG_KNN_COSIM_BDB
	 */
	struct gsl_rerank_desc *rerank;
};

/* gsl_flat_hamming_create_search_session - creates a flat Hamming session
 *
 * Once gsl_flat_hamming_create_search_session() completes successfully,
 * it is possible to run searches on it by calling either
 * gsl_flat_hamming_search_u1() or gsl_flat_hamming_search_f32(),
 * depending on the value of *@hamming_desc.
 *
 * Inputs:
 * @gsl_context  - defines which boards searches on the output session
 *                 will run on.
 * @hamming_desc - Properties of searches on the output @session_hdl.
 *                 To search using calls to gsl_flat_hamming_search_u1()
 *                 the encoding and rerank members should be NULL.
 *                 To search by calling gsl_flat_hamming_search_f32()
 *                 set encoding, optionally, rerank members.
 *
 * Outputs:
 * @session_hdl  - session for doing Hamming based searches as described
 *                 above.
 */
int gsl_flat_hamming_create_search_session(gsl_context ctx,
                                           gsl_search_session_hdl *session_hdl,
                                           struct gsl_flat_hamming_desc *hamming_desc);

/*gsl_flat_hamming_get_max_k - provides the maximum k value supported for search.
 *
 * The value of k in @hamming_desc ignored and will not change.
 *
 * Inputs:
 * @hamming_desc - Pointer to a Hamming descriptor.
 *
 * Outputs:
 * @max_k - The maximum k supported for search.
 */
int gsl_flat_hamming_get_max_k(struct gsl_flat_hamming_desc *hamming_desc,
                               int *max_k);

/* gsl_flat_hamming_search_u1 - KNN search using Hamming distance
 *
 * For each query in @queries, find the nearest neighbors and their
 * Hamming distance from the query.
 *
 * Inputs:
 * @session_hdl - Search session created by passing "desc" as the "hamming_desc"
 *                to parameter to gsl_flat_hamming_create_session()
 * @queries     - A "q x f" matrix. "q" is less than or equal
 *                to "desc.max_num_queries".
 *                Each row represents a record of "f" binary features.
 *                The number of binary features should be the same as
 *                the number of binary features in the records of
 *                "desc.hamming_bdbh".
 *
 * Outputs:
 * @indices     - Matrix holding the indices of the nearest neighbors for each query.
 *                @indices is a "q x k" matrix. The i'th row holds the indices of the
 *                "k" nearest neighbors to the i'th query. "k" must be less than or equal
 *                to "desc.k"
 *                Within each rows the indices are sorted in ascending order according
 *                to their distance from the query.
 * @distances   - Matrix holding the distances of a query from its nearest neighbors.
 *                @distances is a "q x k" matrix. The i'th row holds the distances
 *                of the i'th query from each of its "k" nearest neighbors in
 *                "desc.hamming_bdbh".
 *
 *
 * Returns:
 *  0           - On success
 *  != 0        - Otherwise. See errno for details
 */
int gsl_flat_hamming_search_u1(gsl_search_session_hdl session_hdl,
                               struct gsl_matrix_u32 *indices,
                               struct gsl_matrix_f32 *distances,
                               struct gsl_matrix_u1  *queries);

/* gsl_flat_hamming_search_f32 - KNN search on floating-point queries
 *
 * Convert the floating-point queries to binary and find their k nearest
 * neighbors according to Hamming distance. Optionally, refine the
 * results by using cosine similarity, as desribed above.
 *
 * Inputs:
 * @session_hdl - Search session created by passing "desc" to
 *                gsl_flat_hamming_create_session()
 * @queries     - Matrix with at most "desc.max_num_queries" rows
 *                and the same number of columns (features) as the
 *                matrix used to create "desc.rerank->fdbh"
 *
 * Outputs:
 * @indices     - Matrix holding the indices of the nearest neighbors for each query.
 *                @indices is a "q x k" matrix. The i'th row holds the indices of the
 *                "k" nearest neighbors to the i'th query. If re-rank step is required,
 *                "k" must be less than or equal to "desc.rerank->k". Otherwise, "k"
 *                must be less than or equal to "desc.k".
 *                Within each rows the indices are sorted in descending order according
 *                to their distance from the query.
 * @distances   - Matrix holding the distances of a query from its nearest neighbors.
 *                @distances is a "q x k" matrix. If no re-rank step is required by the
 *                session, the values are the Hamming distances and are sorted in
 *                ascending order. Otherwise the values are the cosine similarity ratios
 *                and are sorted in descending order.
 *                The i'th row holds the values of the i'th query from each of its "k"
 *                nearest neighbors.
 *
 * Returns:
 *  0           - On succes
 *  != 0        - Otherwise. See errno for details
 */
int gsl_flat_hamming_search_f32(gsl_search_session_hdl session_hdl,
                                struct gsl_matrix_u32 *indices,
                                struct gsl_matrix_f32 *distances,
                                struct gsl_matrix_f32 *queries);

/* gsl_flat_hamming_mask_search_f32 - Mask off records before KNN search
 *
 * Only consider records with set bits for the KNN search.
 *
 * Inputs:
 * @session_hdl - Search session created by passing "desc" to
 *                gsl_flat_hamming_create_session()
 * @queries     - Matrix with at most "desc.max_num_queries" rows
 *                and the same number of columns (features) as the
 *                matrix used to create "desc.rerank->fdbh"
 * @bitmasks    - Binary matrix with the same number of rows as @queries. Each row
 *                has one bit per record of the database(s). Only records with set
 *                bits are searched for a particular query.
 *
 *                Memory Layout
 *                The bits are arranged in bytes, in little-endian order. Inside
 *                each byte, bits are packed and appear in little-endian order too.
 *
 *                If "uint8_t *p = (uint8_t *)bitmasks->rows_u1 + N * bitmasks->row_stride"
 *                then the bit of the record at index i is given by:
 *
 *                    p[i/8] & (1 << (i%8))
 *
 * Outputs:
 * @indices     - Matrix holding the indices of the nearest neighbors for each query.
 *                @indices is a "q x k" matrix. The i'th row holds the indices of the
 *                "k" nearest neighbors to the i'th query. If re-rank step is required,
 *                "k" must be less than or equal to "desc.rerank->k". Otherwise, "k"
 *                must be less than or equal to "desc.k".
 *                Within each row the indices are sorted in descending order according
 *                to their distance from the query.
 *                If there are not enough results for the i-th query because less than "k"
 *                bits are set for it, then the remaining indices have value 0xffffffff.
 * @distances   - Matrix holding the distances of a query from its nearest neighbors.
 *                @distances is a "q x k" matrix. If no re-rank step is required by the
 *                session, the values are the Hamming distances and are sorted in
 *                ascending order. Otherwise the values are the cosine similarity ratios
 *                and are sorted in descending order.
 *                The i'th row holds the values of the i'th query from each of its "k"
 *                nearest neighbors.
 *                If there are not enough results for the i-th query because less than "k"
 *                bits are set for it, the remaining values will have the value 0xffff
 *                if the metric is Hamming and -inf if the values represent cosine similarity.
 *
 */
int gsl_flat_hamming_mask_search_f32(gsl_search_session_hdl session_hdl,
                                     struct gsl_matrix_u32 *indices,
                                     struct gsl_matrix_f32 *distances,
                                     struct gsl_matrix_f32 *queries,
                                     struct gsl_matrix_u1  *bitmasks);

/* gsl_flat_hamming_append_recs_u1 - Add records to a search session's database(s)
 *
 * Add a batch of records to the end of the databases associated with
 * @session_hdl.
 *
 * Inputs:
 * @session_hdl - Search session handle
 * @recs        - Batch of binary-feature records. Must have
 *                the same number of features as the database
 *                associated with @session_hdl.
 *
 * Return:
 *  0           - On success
 *  != 0        - Otherwise. See errno.h for details
 */
int gsl_flat_hamming_append_recs_u1(gsl_search_session_hdl session_hdl,
                                    struct gsl_matrix_u1 *recs);

/* gsl_flat_hamming_append_recs_f32 - Add records to a search session's database(s)
 *
 * Add a batch of records to the end of the databases associated with
 * @session_hdl. @session_hdl must have a floating-point database and
 * an encoding.
 *
 * Inputs:
 * @session_hdl - Search session handle
 * @recs        - Batch of floating-point feature records. Must have
 *                the same number of features as the floating-point
 *                database associated with @session_hdl via
 *                the re-rank step. The encoding associated with
 *                @session_hdl must be able to convert @recs
 *                to binary records with the same number of records
 *                as the binary database associated with @session_hdl.
 *
 * Return:
 *  0           - On success
 *  != 0        - Otherwise. See errno.h for details
 */
int gsl_flat_hamming_append_recs_f32(gsl_search_session_hdl session_hdl,
                                     struct gsl_matrix_f32 *recs);

/* gsl_flat_hamming_remove_recs - Remove records from a search session's database(s)
 *
 * Remove a batch of records from all of the databases associated
 * with @session_hdl. The output parameter @perms holds the changes
 * to the databases records.
 *
 * Inputs:
 * @session_hdl - Search session handle
 * @rec_idxes   - a 1D matrix of records' unique indices
 *                to remove.
 *
 * Outputs:
 * @perms       - a Mx2 matrix of the changes to the records'
 *                indices as a result of the removal.
 *                M equals @rec_idxes->row_size.
 *                Each row is a pair (old index, new index)
 *                describing the new index of existing
 *                records after the operation.
 * 		  When number of changes is less than M,
 * 		  the excess entries are filled with 0xffffffff.
 *
 * Returns:
 *  0           - On success
 *  != 0        - Otherwise. See errno.h for details
 *
 */
int gsl_flat_hamming_remove_recs(gsl_search_session_hdl session_hdl,
                                 struct gsl_matrix_u32 *perms,
                                 struct gsl_matrix_u32 *rec_idxes);
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* GSI_LIBGSL_FLAT_HAMMING_H */
