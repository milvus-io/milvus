/*
 * Copyright (C) 2020, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */

#ifndef GSI_LIBGSL_FLAT_TANIMOTO_H
#define GSI_LIBGSL_FLAT_TANIMOTO_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <gsi/libgsl.h>

/* Tanimoto flat search
 *
 * In a flat search, each query is searched against the entire database.
 *
 * NOTE:
 *   - tanimoto_bdh can not be NULL
 */
struct gsl_flat_tanimoto_desc {
	int typical_num_queries;
	int max_num_queries;
	gsl_bdb_hdl tanimoto_bdbh;
	int max_k;
};

int gsl_flat_tanimoto_create_search_session(gsl_context ctx,
                                            gsl_search_session_hdl *session_hdl,
                                            struct gsl_flat_tanimoto_desc *tanimoto_desc);

/* gsl_flat_tanimoto_search_u1 - KNN search using Tanimoto ratio
 *
 * Find the closest "k" records to a set of other records (@queries)
 * using Tanimoto ratio. The function computes their indices and
 * the Tanimoto ratios.
 *
 * Inputs:
 * @session_hdl - Search session created by calling "gsl_flat_tanimoto_create_search_session()"
 *                with "desc" as the argument for "tanimoto_desc" parameter.
 * @queries     - Matrix of "q" rows and "f" columns. "q" must not exceed "desc.max_num_queries".
 *                Each row corresponds to a query with "f" feature.
 *                The number of features of "desc.tanimoto_bdbh" must be "f" as well.
 *
 * Outputs:
 * @indices     - Matrix of "q" rows and "k" columns. The i'th row holds the indices
 *                of the "k" nearest neighbors to the i'th query. It must hold that
 *                "k <= desc.k"
 * @distances   - Matrix of "q" rows and "k" columns. The i'th row holds the distances
 *                of the i'th query from each of its "k" nearest neighbors in
 *                "desc.tanimoto_bdbh".
 *                The value at i'th row and j'th column is the Tanimoto ratio between
 *                the i'th query and the record at index @indices[i, j]
 *
 * Returns:
 *  0           - On success
 *  != 0        - Otherwise. See errno for details
 */
int gsl_flat_tanimoto_search_u1(gsl_search_session_hdl session_hdl,
                                struct gsl_matrix_u32 *indices,
                                struct gsl_matrix_f32 *distances,
                                struct gsl_matrix_u1  *queries);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* GSI_LIBGSL_FLAT_TANIMOTO_H */

