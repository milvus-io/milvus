/*
 * Copyright (C) 2020, GSI Technology, Inc. All rights reserved.
 *
 * This software source code is the sole property of GSI Technology, Inc.
 * and is proprietary and confidential.
 */
#ifndef GSI_LIBGSL_CLSTR_HAMMING_H
#define GSI_LIBGSL_CLSTR_HAMMING_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <gsi/libgsl.h>

/* Hamming Centroids Cluster Search
 *
 * The functions in this header support finding the K
 * nearest neighbors in a clustered database using a
 * centroids database.
 *
 * Each centroid corresponds to exactly one cluster.
 * If a record is close to a centroid, it should also
 * be close to each record of its associated cluster.
 *
 * Searching a clustered database using centroids sacrafices
 * accuracy for speed gained by searching only a subset of
 * the clusters.
 *
 * First, the nearest centroids to a query are found. Then,
 * only the clusters corresponding to the centroids are searched
 * for the k nearest neighbors of the query. The number of
 * centroids searched determines the accuracy of the search
 * at the expanse of search duration. An optional re-ranking
 * step can further reduce the number of centroids before
 * the clusters are searched.
 *
 */
struct gsl_clstr_hamming_desc {
	int typical_num_queries;
	int max_num_queries;

	struct gsl_bdb_encoding_desc *centroids_encoding;
	struct gsl_bdb_encoding_desc *clusters_encoding;

	gsl_bdb_hdl centroids_bdbh;
	int centroids_k;

	struct gsl_rerank_desc *centroids_rerank;

	gsl_clstr_bdb_hdl clusters_bdbh;
	int max_k;
};

/* gsl_clstr_hamming_create_search_session
 *
 * The value of *@hamming_desc will determine which search function
 * can be invoked with *@session_hdl, after calling
 * gsl_search_in_focus(*@session_hdl).
 *
 * See each of the search functions for details
 */
int gsl_clstr_hamming_create_search_session(gsl_context ctx,
                                            gsl_search_session_hdl *session_hdl,
                                            struct gsl_clstr_hamming_desc *hamming_desc);

/* gsl_clstr_hamming_centroids_search_f32 - Cluster Hamming KNN search using centroids
 *
 * This function find the k nearest neighbors of @queries in a clustered database by:
 * 1. Convert float-feature queries to bit-features queries
 * 2. Finding the nearest centroids.
 * 3. Optionally, refine the centroids from previous step with a re-rank step
 * 4. Find the k nearest neighbors by searching the clusters corresponding
 *    to the centroids.
 *
 * Each result is given by the index of the cluster it's in, its index within
 * that cluster, and the Hamming distance between the record and the query.
 *
 * Inputs:
 * @session_hdl   - Search session handle created by calling gsl_clstr_hamming_create_search_session()
 *                  with a value of the hamming_desc parameter such that:
 *                  1. hamming_desc->clusters_bdbh != NULL
 *                  2. hamming_desc->centroids_bdbh != NULL
 *                  3. hamming_desc->centroids_encoding != NULL
 *                  4. hamming_desc->clusters_encoding != NULL
 *                  5. The centroids of @hamming_desc->centroids_bdbh should be a
 *                     subset of @hamming_desc->centroids_encoding's range
 *                  6. The records of @hamming_desc->clusters_bdbh should be a
 *                     subset of @hamming_desc->clusters_encoding's range
 *
 * @queries       - a "q x f" matrix holding the queries to search against. Each row
 *                  contains "f" floating-point features, and represents a query.
 *                  "haming_desc->rerank->fdbh" must have "f" features. "q" must be
 *                  less than or equal to "hamming_desc->max_num_queries"
 *
 * Outputs:
 * @out_indices   - The indices of the nearest neighbors. Each index is relative
 *                  to a cluster. It tells that records index within a cluster.
 *                  @out_indices is a "q x k" matrix where "k <= hamming_desc.max_k".
 *                  The i'th row contains the indices of the nearest neighbors to
 *                  i'th query.
 * @out_clstrs    - The clusters of the nearest neighbors. @out_clstrs is a "q x k"
 *                  matrix where the i'th row contains the cluster indices of the
 *                  nearest neighbors to the i'th query.
 * @out_distances - The Hamming distances of the nearest neighbors from the queries.
 *                  @out_distances is a "q x k" matrix. The i'th row holds the
 *                  distances of the nearest neighbors from the i'th query.
 *
 * Returns:
 * 0              - On success
 * != 0           - Otherwise. See errno.h for details
 */
int gsl_clstr_hamming_centroids_search_f32(gsl_search_session_hdl session_hdl,
                                           struct gsl_matrix_u32 *out_indices,
                                           struct gsl_matrix_u32 *out_clstrs,
                                           struct gsl_matrix_f32 *out_distances,
                                           struct gsl_matrix_f32 *queries);
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* GSI_LIBGSL_CLSTR_HAMMING_H */
