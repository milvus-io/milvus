#!/usr/bin/env python3

import argparse
import numpy as np

from tmp_api import *
import gdl_bindings as gdl

#-----------------------------------------------------------------------------------------------------------------------#
                                    # GSL-EXAMPLE-APP #

    # This application shows the use of GSI Search Library.
    # The flow represent here is Hamming search with neural hash encoding and rerank.
    # For bridging between the application and 'C' source files we will import 2 python files:
    # 1. tmp_api - functions that call to 'C' libgsl.h file.
    # 2. gdl_bindings - functions that directly call 'C' libgdl.h file that allows host to 'talk' with GSI device library.

    # APPLICATION FLOW WILL BE:
    # 1. Get User's input.
    # 2. Check User's input.
    # 2. Allocate cards.
    # 3. Create GSL float database.
    # 4. Create GSL bit data base by using encoding (float weights).
    # 5. Create session with specified workload.
    # 6. Search in focus for specific session.
    # 7. Search on specific session that is already in focus.
    # 8. Exit properly.

    ########### FOR NEXT EXPLANATIONS GO TO main() ###########

def raise_exception_and_exit_properly(gsl_ctx, exception):
    print(exception)
    del gsl_ctx
    gdl.gdl_exit()

    raise exception


def print_out_results(np_fqueries, np_out_indices):
    print_align = 20
    titles  = '|'.join(title.center(print_align) for title in ['query number' ,'best records indices'])
    print("{}\n".format(titles))
    for idx, query_indices in enumerate(np_out_indices):
        print("{}\n".format('|'.join((str(title)).center(print_align) for  title in [idx, str(query_indices)])))

    print('\n********************************************************************************************************\n')

#-----------------------------------------------------------------------------------------------------------------------#
                        # RUN-APP-MAIN #
def main(fdb_path, fqueries_path, weights_path, num_cards, k,
         rerank_k, to_normalize, num_typical_queries, num_max_queries, print_results):
    print('======================RUNNING======================')

    #-------------------------------------------------------------------------------------------------------------------#
    # FIRST LETS CHECK USER'S INPUT:
    # INPUT ARGUMENT - fdb_path
    # Load numpy file with float records.
    # np_fdb - Each row represents a single float record.
    #        - Each record contains list of float features (number of columns).
    np_fdb = np.load(fdb_path, allow_pickle=True)
    assert np_fdb.dtype == 'float32', 'fdb_file must include numpy of type float32.'

    # INPUT ARGUMENT - fqueries_path - will be explained later on.
    # INPUT ARGUMENT - weights_path
    # Load numpy file with float weights.
    # np_weights - Here we use NEURAL HASH ENCODING. Weights are represented by matrices and biases.
    #            - You should pay attention to dimensions of matrices and biases.
    #              In process of encoding (np_fdb_encoded = np_fdb * mat + bias) - for each pair.
    #            - In the end of encoding process you will get bit-database.
    np_weights = np.load(weights_path, allow_pickle=True)
    assert np_weights[0].dtype == 'float32', 'weights_file must include numpy of type float32.'
    assert np_weights[0].shape[0] == np_fdb.shape[1], "np_weights's rows should match np_fdb's columns"

    list_pair_layers = [NHEncoding.NHLayer(mat, np.resize(bias,(1, bias.shape[0]))) \
                        for mat, bias in zip(np_weights[0::2], np_weights[1::2])]

    # INPUT ARGUMENT - num_cards
    #       Number of cards that User would like to use, however they may not match the current state of device.
    # INPUT ARGUMENT - k
    #       Number of most similar records per query that User ask to find. The search is done over bit-database.
    # INPUT ARGUMENT - rerank_k
    #       Number of records User ask to find after k results are found.
    #       The search is done over float-database.
    # INPUT ARGUMENT - to_normalize
    #       If true all records will be normalized before encoding.
    #       It is in User responsibility to pass true when float records is not normalized.
    #       Otherwise the results may not be correct especially when re-rank option is used.
    # INPUT ARGUMENT - num_typical_queries
    #       Relevant with create_search_session().
    #       It is number of queries usually used in this specific session.
    # INPUT ARGUMENT - num_max_queries
    #       Relevant with create_search_session().
    #       It is maximum number of queries that can be used in this specific session.
    assert k <= np_fdb.shape[0], 'Number of k best records cannot exceed the number of existing records'
    assert k >= rerank_k, 'Number of rerank_k cannot exceed k best records'

    #-------------------------------------------------------------------------------------------------------------------#
    # ALLOCATE CARDS:
    # Before the work starts You should always:

    # GDL:
    # 1. Initialize the GSI device library. (gdl.gdl_init())
    # Remember to call gdl.gdl_exit() in the end of application flow.
    gdl.gdl_init()

    # 2. Get the number of hardware contexts of device - number of existing cards. (gdl.gdl_context_count_get(...))
    status, num_gdl_ctxes = gdl.gdl_context_count_get()
    if status:
        raise Exception('gdl.gdl_context_count_get() failed with {}'.format(s))
    if num_cards > num_gdl_ctxes:
        raise Exception("Requested {} cards but only {} are available".format(num_cards, num_gdl_ctxes))

    # 3. Get list of hardware contexts descriptors (named tuple). (gdl.gdl_context_desc_get(...))
    status, gdl_ctx_desc = gdl.gdl_context_desc_get(num_gdl_ctxes)
    if status:
        raise Exception('gdl.gdl_context_desc_get() failed with {}'.format(s))

    # 4. Create list of valid context id-s. Valid in this case are contexts ready for use.
    cards_ids = [desc.ctx_id for desc in gdl_ctx_desc if desc.status == gdl.GDL_CONTEXT_READY]
    if  len(cards_ids) < num_cards:
        raise Exception('Not enough GDL_CONTEXT_READY cards.')

    # GSL:
    # 5. Create GSL context. (Context(...)) Necessary to start the work with GSI Search Library.
    # For this you will need the list of valid contexts id-s (p.4),
    # the number of cards you ask for and the maximal number of threads GSL may use.
    num_max_threads = 10
    gsl_ctx = Context(cards_ids[:num_cards], num_max_threads)

    #-------------------------------------------------------------------------------------------------------------------#
    # CREATE GSL FLOAT DATABASE:
    # fdb_hdl - Create fdb object that GSL knows how to work with. gsl_create_fdb(...).
    # To make it work you should pass:
    #  - np_fdb - float data base.
    #  - to_normalize - if true np_fdb will be normalized before saved in fdb_hdl.
    # To free GSL's gdl_context_handle remember del gsl_context in the end use.
    try :
        fdb_hdl = gsl_ctx.create_fdb(np_fdb, to_normalize)
    except GslException as e:
        raise_exception_and_exit_properly(gsl_ctx, e)

    #-------------------------------------------------------------------------------------------------------------------#
    # CREATE GSL BIT DATA BASE BY USING ENCODING:
    # bdb_hdl - Create bdb object that GSL knows how to work with, create_bdb_from_fdb()
    # To make it work you should pass:
    #  - fdb_hdl - GSL float data base.
    #  - encod_desc - encoding descriptor object NHEncoding()
    # fdb_hdl is converted into GSL bit-records data base. It is done by using given NHEncoding encoding object.
    encod_desc = NHEncoding(list_pair_layers, to_normalize)

    try :
        bdb_hdl = gsl_ctx.create_bdb_from_fdb(fdb_hdl, encod_desc)
    except GslException as e:
        gsl_ctx.destroy_fdb(fdb_hdl)
        raise_exception_and_exit_properly(gsl_ctx, e)

    #-------------------------------------------------------------------------------------------------------------------#
    # CREATE SESSION WITH SPECIFIED WORKLOAD.
    # session_hdl - Create GSL session of specified workload (k, rerank_k, num_max_queries ...).
    #
    # To make it work you should pass:
    #  - hamming_desc - Hamming descriptor. Created with FlatHammingDesc().
    #
    # You can create several sessions with same GSL data base but with different workloads.
    # There is also the maximum k supported for search that User must check if allowed.

    rerank_desc = CosineRerankDesc(fdb_hdl, rerank_k)
    hamming_desc = FlatHammingDesc(num_max_queries, num_typical_queries, rerank_desc, encod_desc, bdb_hdl)

    max_k = gsl_ctx.get_max_k(hamming_desc)
    assert k <= max_k , 'Number of k best records cannot exceed the maximum k supported for search'
    hamming_desc.max_k = k

    try :
        session_hdl = gsl_ctx.create_session(hamming_desc)
    except GslException as e:
        gsl_ctx.destroy_fdb(fdb_hdl)
        gsl_ctx.destroy_bdb(bdb_hdl)
        raise_exception_and_exit_properly(gsl_ctx, e)

    #-------------------------------------------------------------------------------------------------------------------#
    # SEARCH IN FOCUS FOR SPECIFIC SESSION.
    # The user describes the expected workload(session_hdl) to GSL by calling search_in_focus().
    # Search in focus prepares the context to optimally execute the workload the search session is associated with.
    # Only a single session_hdl can be in-focus before calling to search function.
    gsl_ctx.search_in_focus(session_hdl)

    #-------------------------------------------------------------------------------------------------------------------#
    # LETS GO BACK TO USER'S INPUT: INPUT ARGUMENT - fqueries_path
    # Load numpy file with float queries.
    # np_fqueries  - Each row represents a single query.
    #              - Each query contains list of float features (number of columns).
    np_fqueries = np.load(fqueries_path, allow_pickle=True)
    assert np_fqueries.dtype == 'float32', 'queries_file must include numpy of type float32'
    assert np_fqueries.shape[1] == np_fdb.shape[1], 'records and queries must have the same number of (floating-point) features - columns.'
    assert np_fqueries.shape[0] <= num_max_queries, 'Number of queries cannot exceed num_max_queries.'

    #-------------------------------------------------------------------------------------------------------------------#
    # SEARCH ON SPECIFIC SESSION THAT IS ALREADY IN FOCUS.
    # To make it work you should pass:
    #  - outputs -     a tuple that contain the following:
    #                       - np_out_indices, np_out_vals - User prepares buffers for values and indices results.
    #                       - Each row(i'th query) represents rerank_k best values/indices.
    #  - np_fqueries - float queries.
    # For each search User can use different number of fqueries.
    # make sure that session is in focus before calling search()
    np_out_vals = np.empty((np_fqueries.shape[0], rerank_k), np.float32)
    np_out_indices = np.empty((np_fqueries.shape[0], rerank_k), np.uint32)
    outputs = FlatOutputs(indices=np_out_indices, values=np_out_vals)
    try :
        gsl_ctx.search(np_fqueries, outputs)
    except GslException as e:
        print(e)
        raise(e)
    finally:
         # FREE ALL GSL HANDLESRS.
        gsl_ctx.destroy_session(session_hdl)
        gsl_ctx.destroy_bdb(bdb_hdl)
        gsl_ctx.destroy_fdb(fdb_hdl)

    #-------------------------------------------------------------------------------------------------------------------#
    # PRINT OUT THE RESULTS:
    if print_results:
        print_out_results(np_fqueries, np_out_indices)

    #-------------------------------------------------------------------------------------------------------------------#
    # EXIT PROPERLY:

    # GDL:
    # 2. Exit from the GSI device library. (gdl.gdl_exit(...))
    gdl.gdl_exit()

    print('================RUNNING-FINSHED - ok===============')

#-------------------------------------------------------------------------------------------------------------------#
    # USER INPUT:
    # You will be asked to enter number of arguments:
    # float records data base, float (NPH)weights, float queries, num_cards, k,
    # rerank_k, to_normalize, num_typical_queries, num_max_queries.
    # They are explained later in code(In main()).

def check_if_np_file(path):
    if path.split('.')[-1] != 'npy':
        raise argparse.ArgumentTypeError('Parser excepts only numpy files. : {} '.format(path))

    return path

def check_if_non_negative(value):
    ivalue = int(value)
    if ivalue < 0:
        raise argparse.ArgumentTypeError("%s is a negative value" % value)

    return ivalue

parser_description = '''
*--------------------------------------------------------------------------------*

# GSL EXAMPLE APP #
Represented flow is Hamming search with neural hash encoding and refinement step.

'''

parser = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter, description=parser_description)
parser.add_argument('-d', '--fdb_path', type=check_if_np_file, required=True, metavar='',
                    help='path to numpy file - float records')
parser.add_argument('-q', '--fqueries_path', type=check_if_np_file, required=True, metavar='',
                    help='path to numpy file - float queries')
parser.add_argument('-w', '--weights_path', type=check_if_np_file, required=True, metavar='',
                    help='path to numpy file - float weights')
parser.add_argument('-c', '--num_cards', type=check_if_non_negative, required=True, metavar='',
                    help='number of cards')
parser.add_argument('-k', '--k', type=check_if_non_negative, required=True, metavar='', help='k')
parser.add_argument('-r', '--rerank_k', type=check_if_non_negative, required=True, metavar='', help='rerank_k')
parser.add_argument('-n', '--normalize', type=int, choices=[0, 1], required=True, metavar='', help='normalize')
parser.add_argument('-q_t', '--num_typical_queries', type=check_if_non_negative, required=True, metavar='',
                    help='number of typical queries')
parser.add_argument('-q_m', '--num_max_queries', type=check_if_non_negative, required=True, metavar='',
                    help='number of max queries')
parser.add_argument('-p', '--print_results', action='store_true', help='if set application prints results')
args = parser.parse_args()

if __name__ == '__main__':
    main(args.fdb_path, args.fqueries_path, args.weights_path, args.num_cards, args.k,
         args.rerank_k, args.normalize, args.num_typical_queries, args.num_max_queries, args.print_results)
