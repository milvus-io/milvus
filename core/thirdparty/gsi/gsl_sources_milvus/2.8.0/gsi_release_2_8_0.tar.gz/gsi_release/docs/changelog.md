# GSL Changelog

This is a changelog for GSL, GSI Search Library. It describes the
changes in each release. For information about GSL conslut the
examples, readme file, and internal documentation in libgsl.h.

## Package Structure

version-number       ;  2.8.0
package-mode         ;     └── {debug, release}
applications         ;          ├── bin
                     ;          │   ├── gsl-basic-test
                     ;          │   ├── gsl-test
                     ;          │   └── tests
                     ;          │       └── gsl_hamming_flat_1card_inmem_perf_test_300mhz.txt
python3 bindings     ;          ├── bindings
bindings to GDL      ;          │   ├── gdl_bindings.cpython-36m-x86_64-linux-gnu.so
bindings to GSL      ;          │   └── gsl_bindings.cpython-36m-x86_64-linux-gnu.so
                     ;          │   └── gsl_utils.py
documentation        ;          ├── docs
                     ;          │   ├── changelog.md
random tests file    ;          │   ├── release-test-1card-inmem-tests.txt
release tests output ;          │   ├── release-test.out
                     ;          |   ├── gsl_example_app.py
                     ;          |   └── gsl_example_app.c
                     ;          ├── include
                     ;          │   └── gsi
main GSL header      ;          │       ├── libgsl.h
flat Hamming search  ;          │       ├── libgsl_flat_hamming.h
flat Tanimoto search ;          │       ├── libgsl_flat_tanimoto.h
cluster Hamming      ;          │       ├── libgsl_clstr_hamming.h
matrix definitions   ;          │       └── libgsl_matrix.h
                     ;          └── libs
static library       ;              ├── libgsl.a
dynamic library      ;              └── libgsl.so

### Debug and Release Modes

In debug mode, GSL's code is unoptimized and will achieve good
stated performance. The code does contain additional checks
of user parameters and prints error messages to the screen.
These checks should make learning GSL's API easier.

In release mode fewer checks are made to make the code faster.

## Release - 2.8.0  2021-05-09

### Added

* APU-5304 - allocate less memory for DB in GSL.

### Fixed

* APU-5296 - Fix mask search performance.

### Changed

* APU-2096  - Reduce search in focus power consumption if it does not impair performance

* Move to system version 120.11.300.9

* tmp_api depends on the dataclass module

## Release - 2.7.0  2021-03-21

### Added

* APU-4656 - Enable stdout logging in debug mode

* APU-5048 - Add search function for masked records;
	     gsl_flat_hamming_mask_search_f32().

### Fixed

* APU-5072 - Fix GSL's behavior when the number of records in clusters is less than k.
	     Distances for invalid entries get value 0xffff. Invalid indices get value 0xffffffff

### Changed

* Adapt gsl python example app to use new python API

* Move to system version 120.11.300.8


## Release - 2.6.1  2021-02-24

### Fixed

* APU-5022 - Fix hang in GSL when doing Tanimoto flat search.

* APU-4957 - Fix wrong behavior of max_num_threads in gsl_create_context() by giving each
	     context its own copy of the number of threads.


## Release - 2.6.0  2021-02-15

### Added

* APU-4002 - Add gsl_example_app.py to docs folder.

* APU-4780 - Add gsl_example_app.c to docs folder.

* APU-4653 - gsl_create_context() supports an additional, integer
             parameter to restrict CPU threads usage.
             In gsl_bindings this parameter is optional.

* APU-4940 - Add new python API in addition to existing API

### Fixed

* APU-4598 - Fix know issue in append/remove (APU-4333).
             The minimal number of records in the database(s) equals the max number
             of nearest neighbors searched using Hamming distance passed to GSL when
             creating the search session. This is independent of the number of APU boards.

### Changed

* APU-4759 - Removed functions from libgsl.h;
             gsl_flat_hamming_remove_rec_using_last(),
             gsl_flat_hamming_append_rec_u1(),
             gsl_flat_hamming_append_rec_f32().

             Removed functions from gsl_utils.py;
             flat_hamming_append_re(),
             flat_hamming_remove_rec_using_last().

             Removed functions from gsl_bindings.c;
             _gsl_flat_hamming_append_rec_f32(),
             _gsl_flat_hamming_append_rec_u1(),
             _gsl_flat_hamming_remove_rec_using_last().

* APU-4863 - Removed gdl_bindings.gdl_bindings_context_get_valid_ctx_hndls().

* APU-4907 - Move to system version 120.11.300.7. Move to GVML version 00.07.03.


### Known Issues

* APU-4653 - Possible performance hit when using multiple contexts with different
             number of max_num_threads.

* APU-4653 - Invalid behavior when running two contexts _simultaneously_.

* APU-4695 - gsl_search_in_focus() takes longer than before.

## Release - 2.5.1  2021-01-27

### Fixed

* APU-4731 - Allow threads in gsl bindings
	     Add  boolean'hold_lock' parameter to gsl_search_session.py 'search'
	     functions, set it to False for allow multiple threads


## Release - 2.5.0  2020-12-28

### Added

* APU-4606 - Add functions for adding/removing a batch of records:
                      gsl_flat_hamming_append_recs_u1(), gsl_flat_hamming_append_recs_f32() and
                      gsl_flat_hamming_remove_recs()

* APU-4573 - Support variable k in search functions.

### Fixed

* APU-4598 - Known issus APU-4333 -
             when more than one board in used,
	     Allow to remove records until only k records remaining in db.


* APU-4254 - Support running gsl with host only in debug mode

* APU-4637 - Remove record - Return error when record index
             bigger than the number of records id DB.

### Changed

* APU-4606 - Remove these functions in the _next_  release:
                      gsl_flat_hamming_remove_rec_using_last(),
                      gsl_flat_hamming_append_rec_u1(),
                      gsl_flat_hamming_append_rec_f32()

* APU-4591 - Deprecate gdl_bindings_context_get_valid_ctx_hndls().

## Release - 2.4.0  2020-11-29

### Changed

* APU-4567 - Move to system version 120.11.300.6. Move to GVML version 00.06.08

## Release - 2.3.0  2020-10-25

### Added

* APU-4333 - For GSL Hamming method add support for records removal and addition.
	     For removal:  gsl_flat_hamming_remove_rec_using_last().
	     For addition: gsl_flat_hamming_append_rec_u1().
		           gsl_flat_hamming_append_rec_f32().

### Known Issues

* APU-4333 - When more than one board is used records removal is limited.
	     The reason is that apu allows minimum k number of records.
	     Removal limit will be host records + GSL_MAX_SPARE_RECS + apu's limit.

* APU-4444 - gsl_flat_hamming_append_rec_f32 fail when running with more than 1 card


### Fixed

* APU-4416 - Fixed wrong calculation of maximum k in gsl_flat_hamming_get_max_k().

* APU-4448 - New records division between APUs and host that takes into consideration k parameter.
	     Before this change APU number of records could be less than the given k.

## Release - 2.2.1  2020-10-12

### Added

* Add support for empty clusters

## Release - 2.2.0  2020-10-06

### Added

* Add gsl_flat_hamming_get_max_k() to header libgsl_flat_hamming.h.
  Users should call gsl_flat_hamming_get_max_k() to check the value
  of k is supported by GSL.

## Release - 2.1.1  2020-09-15

The only changes in this release compared to 2.1.0 are to the
changelog. There are _no_ changes to the code.

## Release - 2.1.0  2020-09-15

### Changed

* APU-4245 - Move memory allocations to search session creation.
             This change makes gsl_search_in_focus() faster and
	     allows switching between sessions faster

### Added

* APU-4286 - Perform encoding in queries cluster in parallel with centroids search.

* APU-4322 - Rerank K may equal the search k

* APU-4270 - Add gsl-basic-test to the package

* APU-4269 - Allow flat/cluster Hamming f32 search functions
             to run without boards (on the CPU)

* APU-4263 - Add cluster Hamming centroids search vi libgsl_clstr_hamming.h
             header

* APU-4243 - Add gsl_utils.py module to present a nicer interface over GSL
             bindings

* APU-4162 - Add type checks in GSL bindings when creating search sessions,
             this also solves APU-4262

* APU-4195 - Improved performance of create_bdb_from_fdb()


### Fixed

* APU-4240 - Change bit packing order in GSL's neural hash and linear
             LSH algorithms to match Numpy's packbits function

* APU-4173 - Fixed wrong division of records between APUs and host in gsl_*_create_search_session().
	     The error caused GSL to crash in gsl_search_in_focus().
	     It also fixed APU-4193 and APU-4199 bugs.

* APU-4304 - Fixed invalid write in libgsl_apuc_cmd module.

* APU-4309 - Fixed gsl_create_bdb_from_fdb() to works correctly with large database.

## Release - 2.0.1  2020-08-23

### Added

* APU-4138 - Add neural encoding descriptors as number of threads to parallelize
             records for performance purposes in gsl_create_bdb_from_fdb().

### Fixed

* APU-4055 - Fix gsl_apuc_cmd_ctrl_send_cmd to return gdl_send_task return value

## Release - 2.0.0  2020-08-18

This release of GSL contains changes to the API and is incompatible
with previous releases of GSL. There are 3 kinds of changes in this
release:

1. API changes

   a search session object as a handle to the resources and steps
   required to prepare for searching.

   The gsl_search_in_focus_desc type was getting too cumbersome to
   support all possible search combinations. To support new kinds
   of searches, there are now several functions that create a search
   session. Each function expects a different type of descriptor,
   allowing for simpler descritpors.

   GSL currently supports two kinds of searches, flat Hamming and
   flat Tanimoto. The relevant types and functions are in two new
   new header files: libgsl_flat_hamming.h and
   libgsl_flat_tanimoto.h

2. New Capabilities

   GSL now supports record normalization, LSH and neural proxy hash
   (NPH) encodings and re-ranking using cosine similarity for
   flat Hamming search

3. Performance Improvements

  Various performance improvements to the search code on the APU,
  the most notable change in this release is the support for more
  than 131072 records in an APU's L1 memory.

### Known Issues

* GSL Hamming search with encoding and re-ranking is not well
  tested on multiple boards.

* gsl_create_bdb_from_fdb() may take a long time to complete

* APU-4055 - GSL might freeze when it fails to map task memory

### Changed

* Removed stale files README.md and example.c from docs/ folder

* APU-4110 - Move to system version 120.11.300.2

* APU-4103 - Change gsl_create_fdb() to accept a normalize flag

* APU-4087 - Change GSL's API based on idea of search sessions

### Added

* APU-3981 - Add support for records with number of features that is
             a multiple of 8 in flat Tanimoto search

* APU-3940 - Add support for more than 131072 records in L1 if the record
             size is small enough

* APU-4112 - Add gsl_create_bdb_from_fdb() to convert a floating point DB
             to a binary DB via LSH or NPH encodings.

* APU-4125 - Add gsl_get_recs_from_bdb() to extract binary records from a
             handle to a binary DB. The binary records can then be saved
             to disk

* APU-4095 - Add support for neural proxy hash

* Add support for LSH encoding

* APU-4096 - Support cosine re-ranking in flat Hamming search



## Release - 1.3.0  2020-07-14

### Added

* APU-3888 - Add python binding for gsl_knn_tanimoto_bdb

* APU-3991 - Support values of k up to 4095

## Release - 1.2.0  2020-07-09

### Known Issues

* APU-3983 - Bad results for Hamming with 10,000 queries and 1,000,000
             records.

### Added

* APU-3824 - Initial support for Tanimoto, the number of binary features
             should be a multiple of 64.

### Fixed

* APU-3783 - Fix invalid free pointer error when running GSL for a long period of time using GSL bindings

### Changed

* APU-3896 - gsl-test now dynamically links with libgsl.so. When running gsl-test, make sure
             that LD_LIBRARY_PATH points to the correct version of libgsl.so

* APU-3954 - Move to system version 120.11.300.0

## Release - 1.1.0  2020-06-28

The folder structured of this release has changed. A new "bin/"
folder holds GSL's main test application and an example test
file. To run the example test, from the "bin/" folder run,
`gsl-test -f tests/gsl_hamming_flat_1card_inmem_perf_test_300mhz.txt`


### New Features

* Support GSL context that only runs on the host
* APU-3770 - Add `gsl_version_str()` to libgsl.h to get GSL's version
* APU-3897 - Add gsl-test, GSL's test application, to GSL's package,
             under bin/ folder

### Fixed

* APU-3768 - Flat Hamming search works when with 16M/38M Records and 768/1024 Bits
             Fix segmentation fault caused by unsigned wraparound when allocating DB memory

### Changed

* APU-3840 - Move to system version 120.10.300.9


## Release - 1.0.0  2020-05-31

### New Features

* Add input checks to GSL API functions
  In release mode - GSL search functions perform no checks. Other functions
                    check their arguments
  In debug mode   - GSL search functions check their arguments. Other functions
                    check and print an error message as well

* Improve performance for in-memory databases

* Support full range of required interface parameters

### Changed

* APU-3738 - Move to system version 100.10.300.6-rc

### Known Issues

* Performance for a large batch of queries is below expectations for
  big databases

## Release - 0.0.6  2020-05-11

* Separate (currently) unstable code and stubs from the user facing code

* Add gsl_knn_hamming_subclstr_bdb() - Hierarchic KNN Hamming with sub-clustering.

* Separate bw-test from gsl-test

* Support multiple chunks per apuc in hamming flat search.
  Restrictions can be seen in the next link: https://gsitech.atlassian.net/wiki/spaces/SD/pages/1072398349/Limitations+of+using+hamming+flat+search

* Bug fixed - allow running more than once search in focus on same gsl_context

* Bug fixed - Flat Hamming search works when K and the number of queries are large (APU-3547)

* Move to System version 100.10.0.4-rc

## Release - 0.0.5  2020-03-25

* Add gsl_knn_hamming_refine_bdb() - Hierarchic KNN Hamming with refinement
  of the probes.

* Support records in the database up to 128K + 4k - 1 (135167)
  per APU board.

* Add stub for gsl_knn_hamming_subclstr_bdb().

## Release - 0.0.4  2020-03-05

* Fix merge error in merge causing worse per query latency
  when max_num_queries > typical_num_queries in
  gsl_search_in_focus()

## Release - 0.0.3  2020-03-04

* Fix uninitalized variable in clustered search

## Release - 0.0.2  2020-03-03

 * Add extern C guards to GSL's header
 * Add Python bindings to GSL

## Release - 0.0.1  2020-02-26

 * Initial release
 * Dependencies:
   + System version 0.9.8-rc
   + libNUMA
   + OpenMp
 * Limitations:
   + Only these functions are supported:
    - gsl_create_context()

      The number of GDL context objects must be greater than zero

    - gsl_destroy_context()
    - gsl_create_bdb()
    - gsl_destroy_bdb()
    - gsl_create_clstr_bdb()
    - gsl_destroy_clstr_bdb()
    - gsl_knn_hamming_bdb()

      The number of records in the database must be 512K (524288).
      Only a single query is supported.

    - gsl_knn_hamming_clstr_bdb()

      Only a single query is supported.

    - gsl_knn_hamming_index_bdb()

      The number of records in the database must be 512K (524288).
      Only a single query is supported.

    - gsl_search_in_focus()
