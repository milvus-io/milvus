
#define _GNU_SOURCE
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <sys/time.h>
#include <limits.h>
#include <errno.h>

#include <gsi/libgsl_matrix.h>
#include <gsi/libgsl.h>
#include <gsi/libgsl_flat_tanimoto.h>
#include <gsi/libgdl.h>

/*-----------------------------------------------------------------------------------------------------------------------
                                	   GSL-EXAMPLE-APP

     This application shows the use of GSI Search Library.
     The flow represent here is Tanimoto search.

     The relevant headers files are:
     1. libgsl.h 	       - The GSI Search Library (GSL).
     				 Provides functions for search k nearest neighbors (KNN) inside a database.
     2. libgsl_matrix.h        - The GSL normal matrices header.
     				 Used to represent User records, queries and search results (distances and indices).
     3. libgsl_flat_tanimoto.h - The GSI Search Library (GSL). Provides Tanimoto search flow functions.
     4. libgdl.h 	       - The GSI Device Library. Provides functions that allows User to 'talk' with device.


     APPLICATION FLOW WILL BE:
     1. Get User's input.
     2. Check User's input.
     3. Allocate all needed memory for records, queries, out_distances and out_indices.
     4. Allocate cards.
     5. Create GSL binary database.
     6. Create GSL session with specified workload.
     7. Search in focus for specific session.
     8. Search on specific session that is already in focus.
     9. Exit properly.

			         FOR NEXT EXPLANATIONS GO TO main()
-----------------------------------------------------------------------------------------------------------------------*/
#define ERROR(fmt, ...) fprintf(stderr, "error: line %d " fmt "\n", __LINE__, ##__VA_ARGS__)
#define INFO(fmt, ...) fprintf(stderr, "info: line %d " fmt "\n", __LINE__, ##__VA_ARGS__)

#define ALIGN_SIZE(size, alignment) ((alignment) * (((size) + (alignment) - 1) / (alignment)))
#define GET_MIN(a, b) (((a) < (b)) ? (a) : (b))

#define NUM_QUERIES (3)
#define MAX_K (5)
#define NUM_ITERS (100)
#define MAX_HEAP_ALLOCATIONS (4)
enum {
	SUCCESS = 0,
	FAIL = 1
};

static int check_user_input(int argc, char * const *argv, unsigned int *out_num_records,
			    unsigned int *out_num_bfeatures, FILE **out_fp)
{
	enum user_args {
		APPLICATION_NAME = 0,
		NUM_RECORDS = 1,
		NUM_BIT_FEATURES_PER_REC = 2,
		RECORDS_FILE_PATH = 3,
		NUM_ALL_ARGS = 4
	};

	assert(NUM_ALL_ARGS == argc);
	unsigned int num_records = (unsigned int)atoi(argv[NUM_RECORDS]);
	unsigned int num_bfeatures = (unsigned int)atoi(argv[NUM_BIT_FEATURES_PER_REC]);
	const char *records_file_path = argv[RECORDS_FILE_PATH];

	if (num_bfeatures != ALIGN_SIZE(num_bfeatures, CHAR_BIT)){
		ERROR("number of bits features should be aligned to (%d).", CHAR_BIT);
		return FAIL;
	}
	uint32_t num_bytes_in_rec = num_bfeatures / CHAR_BIT;
	size_t num_all_bytes = num_bytes_in_rec * num_records;

	FILE *fp = fopen(records_file_path, "rb");
	if (NULL == fp) {
        	perror("error: fopen() failed.\n");
       		return FAIL;
   	}

	int status = fseek(fp, 0, SEEK_END);
	if (SUCCESS != status) {
		perror("error: fseek() failed\n");
		return FAIL;
	}
	int num_bytes_in_bfile = ftell(fp);
	if (num_all_bytes != num_bytes_in_bfile) {
		ERROR("number of bytes in binary file is(%d) when calculated is(%ld).",
				num_bytes_in_bfile, num_all_bytes);
		return FAIL;
	}
	status = fseek(fp, 0, SEEK_SET);
	if (SUCCESS != status) {
		perror("error: fseek() failed\n");
		return FAIL;
	}
	assert(getc(fp) != EOF);

	*out_num_records = num_records;
	*out_num_bfeatures = num_bfeatures;
	*out_fp = fp;

	return 0;
}

static double current_timestamp_ms(void)
{
	struct timeval time = { 0 };
	gettimeofday(&time, NULL);
	/* calculate milliseconds */
	double milliseconds = (double)time.tv_sec * 1000 + (double)(time.tv_usec) / 1000;

	return milliseconds;
}

static void print_results(double time_per_search, const struct gsl_matrix_u32 *indices,
			  const struct gsl_matrix_f32 *distances, unsigned int num_queries, unsigned int k)
{
	assert(NULL != indices);
	assert(NULL != indices->rows_u32);
	assert(NULL != distances);
	assert(NULL != distances->rows_f32);

	const char *time_str = "TIME PER SEARCH IN MILLISECONDS:";
	(time_per_search == 0) ? printf("%s %.0f\n", time_str, time_per_search) :
				 printf("%s %.2f\n", time_str, time_per_search);

	printf("INDICES:\n");
	uint32_t *indices_buff = NULL;
	for (unsigned int i = 0; i < num_queries; ++i) {
		indices_buff = (uint32_t *)((char *)indices->rows_u32 + indices->row_stride * i);
		for (unsigned int j = 0; j < k; ++j)
			printf("[%d]", indices_buff[j]);
		printf("\n");
	}

	printf("DISTANCES:\n");
	float *distances_buff = NULL;
	for (unsigned int i = 0; i < num_queries; ++i) {
		distances_buff = (float *)((char *)distances->rows_f32 + distances->row_stride * i);
		for (unsigned int j = 0; j < k; ++j)
			printf("[%f]", distances_buff[j]);
		printf("\n");
	}
}

/*-----------------------------------------------------------------------------------------------------------------------*/
			 			// RUN-APP-MAIN //
int main(int argc, char *argv[])
{
	/*---------------------------------------------------------------------------------------------------------------*/
	/* GET USER'S INPUT AND CHECK IT: */
	int num_records = 0;
	int num_bfeatures = 0;
	FILE *fp = NULL;
	int status = check_user_input(argc, argv, &num_records, &num_bfeatures, &fp);
	if (FAIL == status)
		return 0;

	/*---------------------------------------------------------------------------------------------------------------*/
	/* ALLOCATE ALL NEEDED MEMORY FOR RECORDS, QUERIES, OUT_DISTANCES AND OUT_INDICES: */
	void *heap_allocations[MAX_HEAP_ALLOCATIONS] = { 0 };
	unsigned int counter_heap_allocations = 0;

	uint32_t num_bytes_in_rec = num_bfeatures / CHAR_BIT;
	size_t db_size = num_bytes_in_rec * num_records;
	struct gsl_matrix_u1 bdb = {
		.row_size = num_bfeatures,
		.row_stride = num_bytes_in_rec,
		.num_rows = num_records,
		.rows_u1 = malloc(db_size)
	};
	if (NULL == bdb.rows_u1) {
		ERROR("no memory to allocate.");
       		goto FREE_CASE_1;
	}
	heap_allocations[++counter_heap_allocations] = bdb.rows_u1;

	char *buff = (char *)bdb.rows_u1;
	for (size_t i = 0; i <= num_records; i += num_bytes_in_rec, buff += num_bytes_in_rec) {
		size_t read_bytes = fread((void *)buff, sizeof(char), num_bytes_in_rec, fp);
		assert(read_bytes == num_bytes_in_rec);
	}

	int num_queries = GET_MIN(num_records, NUM_QUERIES);
	struct gsl_matrix_u1 queries = {
		.row_size = num_bfeatures,
		.row_stride = num_bytes_in_rec,
		.num_rows = num_queries,
		.rows_u1 = queries.rows_u1 = malloc(num_queries * num_bytes_in_rec)
	};
	if (NULL == queries.rows_u1) {
		ERROR("no memory to allocate.");
		goto FREE_CASE_1;
	}
	heap_allocations[++counter_heap_allocations] = (void *)queries.rows_u1;
	memcpy(queries.rows_u1, bdb.rows_u1, queries.row_stride * num_queries);

	int k = GET_MIN(num_records, MAX_K);
	int max_num_queries = num_queries;
	struct gsl_matrix_u32 indices = {
		.row_size = k,
		.row_stride = k * sizeof(uint32_t),
		.num_rows = max_num_queries,
		.rows_u32 = (uint32_t *)calloc(k * max_num_queries, sizeof(uint32_t))
	};
	if (NULL == indices.rows_u32) {
		ERROR("no memory to allocate.");
		goto FREE_CASE_1;
	}
	heap_allocations[++counter_heap_allocations] = (void *)indices.rows_u32;

	struct gsl_matrix_f32 distances = {
		.row_size = k,
		.row_stride = k * sizeof(float),
		.num_rows = max_num_queries,
		.rows_f32 = (float *)calloc(k * max_num_queries, sizeof(float))
	};
	if (NULL == distances.rows_f32) {
		ERROR("no memory to allocate.");
		goto FREE_CASE_1;
	}
	heap_allocations[++counter_heap_allocations] = (void *)distances.rows_f32;

	/*---------------------------------------------------------------------------------------------------------------*/
	/* ALLOCATE CARDS: */
	status = gdl_init();
	if (SUCCESS != status) {
		ERROR("gdl_init() failed (%d).", status);
		goto FREE_CASE_1;
	}

	unsigned int num_req_cards = 1;
	unsigned int num_existing_cards = 0;
	status = gdl_context_count_get(&num_existing_cards);
	if (SUCCESS != status) {
		ERROR("gdl_context_count_get() failed (%d).", status);
		goto FREE_CASE_2;
	}
	if (num_req_cards > num_existing_cards) {
		ERROR("requested %d cards but only %d exists.", num_req_cards, num_existing_cards);
		goto FREE_CASE_2;
	}

	struct gdl_context_desc cards_desc[GDL_MAX_NUM_CONTEXTS] = {0};
	status = gdl_context_desc_get(cards_desc, num_req_cards);
	if (SUCCESS != status) {
		ERROR("gdl_context_desc_get failed() (%d).", status);
		goto FREE_CASE_2;
	}

	unsigned int num_ready_cards = 0;
	gdl_context_handle_t cards_ids[GDL_MAX_NUM_CONTEXTS] = {0};
	for (unsigned int i = 0; i < num_existing_cards; ++i) {
		if (cards_desc[i].status == GDL_CONTEXT_READY) {
			cards_ids[num_ready_cards] = cards_desc[i].ctx_id;
			++num_ready_cards;
		}
	}
	if (num_req_cards > num_ready_cards) {
		ERROR("requested %d cards but only %d ready for use", num_req_cards, num_ready_cards);
		goto FREE_CASE_2;
	}

	gsl_context gsl_ctx = NULL;
	unsigned int idx_first_occupied_card = 0;
	uint32_t max_num_threads = 0;
	while ((idx_first_occupied_card + num_req_cards) <= num_ready_cards) {
		status = gsl_create_context(&gsl_ctx, &cards_ids[idx_first_occupied_card], num_req_cards, max_num_threads);
		if (SUCCESS == status) {
			break;
		} else if (ENOSYS == status) {
			INFO("gsl_create_context () (%d). Number of threads allowed to use is too small", status);
			break;
		}
		INFO("failed to create %d gsl contexts starting from %d, lets move to the next one.",
				num_req_cards, idx_first_occupied_card);
		++idx_first_occupied_card;
	}
	if (SUCCESS != status && ENOSYS != status) {
		ERROR("gsl_create_context() failed (%d).", status);
		goto FREE_CASE_2;
	}

	/*---------------------------------------------------------------------------------------------------------------*/
	/* CREATE GSL BINARY DATABASE: */
	gsl_bdb_hdl bdbh = 0;
	status = gsl_create_bdb(gsl_ctx, &bdbh, &bdb);
	if (SUCCESS != status){
		ERROR("failed to create a bit-database handle. gsl_create_bdb() (%d).", status);
		goto FREE_CASE_2;
	}

	/* CREATE GSL SESSION WITH SPECIFIED WORKLOAD: */
	struct gsl_flat_tanimoto_desc tanimoto_desc = {
		.typical_num_queries = num_queries,
		.max_num_queries = max_num_queries,
		.tanimoto_bdbh = bdbh,
		.max_k = k
	};
	gsl_search_session_hdl session_hdl = NULL;
	status = gsl_flat_tanimoto_create_search_session(gsl_ctx, &session_hdl, &tanimoto_desc);
	if (SUCCESS != status) {
		ERROR("failed to crete search session gsl_flat_tanimoto_create_search_session() (%d).", status);
		goto FREE_CASE_3;
	}

	/* SEARCH IN FOCUS FOR SPECIFIC SESSION: */
	status = gsl_search_in_focus(session_hdl);
	if (SUCCESS != status) {
		ERROR("failed to crete search in focus gsl_search_in_focus() (%d).", status);
		goto FREE_CASE_4;
	}

	/* SEARCH ON SPECIFIC SESSION THAT IS ALREADY IN FOCUS; (NUM_ITERS times to meassure performance time). */
	double start = current_timestamp_ms();
	for (size_t i = 0; i < NUM_ITERS; ++i) {
		status = gsl_flat_tanimoto_search_u1(session_hdl, &indices, &distances, &queries);
	}
	double end = current_timestamp_ms();
	double time_per_search = end - start;
	print_results(time_per_search, &indices, &distances, num_queries, k);

	/*---------------------------------------------------------------------------------------------------------------*/
	/* EXIT PROPERLY: */
FREE_CASE_4:
	gsl_search_session_destroy(session_hdl);

FREE_CASE_3:
	gsl_destroy_bdb(bdbh);

FREE_CASE_2:
	gdl_exit();

FREE_CASE_1:
	for (size_t i = 0; i < MAX_HEAP_ALLOCATIONS; ++i)
		free(heap_allocations[i]);

	/*---------------------------------------------------------------------------------------------------------------*/
	status = fclose(fp);
	if (status)
		perror("error: fclose() failed.\n");

	return 0;
}
