import gsl_bindings as gsl
import numpy as np
from collections import namedtuple
from abc import ABC, abstractmethod

binary_params = namedtuple('binary_params', 'typical_num_queries max_num_queries k bdb')

cluster_binary_params = namedtuple('cluster_binary_params', 'k clstr_bdb')

rerank_params = namedtuple('rerank_params', 'rerank_func fdb k')

lsh_params = namedtuple('lsh_params', 'hyperplane_matrix threshold_vector')

nph_params = namedtuple('nph_params', 'matrix bias_vector')

class encoding(ABC):
    @abstractmethod
    def __init__(self, encoding_type, params, normalize):
        self.encoding_type = encoding_type
        self.params = params
        self.normalize = normalize

    def _data_to_tuple(self):
        return (self.encoding_type, self.params, self.normalize)

class lsh_encoding(encoding):
    def __init__(self, params, normalize=False):
        if type(params) is not lsh_params:
            raise TypeError('Expected lsh_params')
        super().__init__(gsl.GSL_BDB_ENCODING_LINEAR_LSH, params, normalize)

class nph_encoding(encoding):
    def __init__(self, params, normalize=False):
        if any(type(p) is not nph_params for p in params):
            raise TypeError('Expected iterable (list) of nph_params')
        super().__init__(gsl.GSL_BDB_ENCODING_NEURAL_HASH, params, normalize)

def check_search_session_params(h, e=None, r=None):
    if type(h) is not binary_params:
        raise TypeError('Expected binary_params')
    if e and not isinstance(e, encoding):
        raise TypeError('Expected encoding')
    if r and type(r) is not rerank_params:
        raise TypeError('Expected rerank_params')

def flat_hamming_create_search_session(ctx, h, *, e=None, r=None):
    check_search_session_params(h, e, r)
    return gsl._gsl_flat_hamming_create_search_session(ctx, h, e._data_to_tuple() if e else None, r)

def flat_hamming_get_max_k(h, *, e=None, r=None):
    check_search_session_params(h, e, r)
    return gsl._gsl_flat_hamming_get_max_k(h, e._data_to_tuple() if e else None, r)

def create_bdb_from_fdb(ctx, fdb, *, e):
        if e and not isinstance(e, encoding):
            raise TypeError('Expected encoding')
        return gsl._gsl_create_bdb_from_fdb(ctx, fdb, e._data_to_tuple() if e else None)

def clstr_hamming_create_search_session(ctx, centroids_p, clusters_p, *, centroids_e=None, clusters_e=None, centroids_r=None):
    if type(centroids_p) is not binary_params:
        raise TypeError('Expected binary_params')
    if type(clusters_p) is not cluster_binary_params:
        raise TypeError('Expected cluster_binary_params')
    if centroids_e and not isinstance(centroids_e, encoding):
        raise TypeError('Expected encoding')
    if clusters_e and not isinstance(clusters_e, encoding):
        raise TypeError('Expected encoding')
    if centroids_r and type(centroids_r) is not rerank_params:
        raise TypeError('Expected rerank_params')

    return gsl._gsl_clstr_hamming_create_search_session(
        ctx,
        centroids_p,
        clusters_p,
        centroids_e._data_to_tuple() if centroids_e else None,
        clusters_e._data_to_tuple() if clusters_e else None,
        centroids_r)

def remove_recs(search_ssesion_hdl, perms, recs_idx):
    recs_idx = np.resize(recs_idx,(1, recs_idx.shape[0]))
    return gsl._gsl_flat_hamming_remove_recs(search_ssesion_hdl, perms, recs_idx)

def append_recs(search_ssesion_hdl, recs):
        if recs.dtype == np.float32:
            return gsl._gsl_flat_hamming_append_recs_f32(search_ssesion_hdl, recs)
        elif recs.dtype in [np.uint32, np.uint16, np.uint8]:
            return gsl._gsl_flat_hamming_append_recs_u1(search_ssesion_hdl, recs)
        else:
            raise TypeError('Unexpected record data type')
