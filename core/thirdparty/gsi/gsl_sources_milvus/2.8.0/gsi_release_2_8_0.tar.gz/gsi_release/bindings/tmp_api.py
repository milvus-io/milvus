from collections import namedtuple
from abc import ABC, abstractmethod
from dataclasses import dataclass
import gsl_bindings as gsl
import numpy as np

CosineRerankDesc = namedtuple('CosineRerankDesc', ['fdb', 'k'])


FlatCosineDesc = namedtuple('FlatCosineDesc', [
                            'fdb',
                            'max_k'])

FlatTanimotoDesc = namedtuple('FlatTanimotoDesc', [
                               'max_num_queries',
                               'typical_num_queries',
                               'max_k',
                               'bdb'])

ClusterHammingDesc = namedtuple('ClusterHammingDesc', [
                                'max_num_queries',
                                'typical_num_queries',
                                'centroid_bdb',
                                'centroid_k',
                                'max_k',
                                'rerank_cosine_desc',
                                'centroids_encoding_desc',
                                'cluster_encoding_desc',
                                'cluster_bdb'])

FlatOutputs = namedtuple('FlatOutputs', ['indices', 'values'])

ClusterOutputs = namedtuple('ClusterOutputs', ['indices', 'clusters', 'values'])




class GslException(Exception):
    def __init__(self, func_name, error):
        self.func_name = func_name
        self.error = error
        super().__init__("function:{}() failed with status: {}".format(self.func_name,  self.error))


class Encoding(ABC):
    def __init__(self, encoding_type, encoding_arrays, normalize):
        self._encoding_type = encoding_type
        self._encoding_array = encoding_arrays
        self._normalize = normalize

    def data_to_tuple(self):
        return (self._encoding_type, self._encoding_array, self._normalize)

    def get_num_binary_features(self):
        pass

class LSHEncoding(Encoding):
    def __init__(self, hyperplane_matrix, threshold_vector, normalize = False):
        super().__init__(gsl.GSL_BDB_ENCODING_LINEAR_LSH, (hyperplane_matrix, threshold_vector), normalize)

    def get_num_binary_features(self):
        return self._encoding_array[1].shape[1]

class NHEncoding(Encoding):
    NHLayer = namedtuple('NHLayer', 'matrix bias_vector')
    def __init__(self, layers, normalize = False):
        super().__init__(gsl.GSL_BDB_ENCODING_NEURAL_HASH, layers, normalize)

    def get_num_binary_features(self):
        return self._encoding_array[-1].bias_vector.shape[1]


class Database(ABC):
    def __init__(self, ctx):
        self._ctx = ctx

    @property
    def num_features(self):
        pass

    @property
    def ctx(self):
        return self._ctx

class DatabaseFloat(Database):

    def __init__(self, ctx, array, normalize):
        super().__init__(ctx)
        self._num_features = array.shape[1]
        status, self._db_hdl = gsl.gsl_create_fdb(self._ctx, array, normalize)
        if status:
            raise GslException("DatabaseFloat", status)

    @property
    def num_features(self):
        return self._num_features

    def destroy(self):
        gsl.gsl_destroy_fdb(self._db_hdl)


class DatabaseBinary(Database):

    def __init__(self, ctx, array, num_features=None):
        super().__init__(ctx)

        if (type(array).__module__ == np.__name__):
            status, self._db_hdl = gsl.gsl_create_bdb(ctx, array)
            self._num_features = array[0].nbytes * 8
        else:
            self._db_hdl = array
            self._num_features = num_features


    @classmethod
    def create_bdb_from_fdb(cls, ctx, fdb, encoding):
        sts, db = gsl._gsl_create_bdb_from_fdb(ctx, fdb._db_hdl, encoding.data_to_tuple())
        return cls(ctx, db, encoding.get_num_binary_features() // 8)  # this not accurate


    @property
    def num_features(self):
        return self._num_features

    def get_recs(self, array):
        sts = gsl.gsl_get_recs_from_bdb(array, self._db_hdl)
        if sts:
            raise GslException("get_recs", sts)

        return array

    def destroy(self):
        gsl.gsl_destroy_bdb(self._db_hdl)



class DatabaseCluster(Database):
    def __init__(self, ctx, cluster):
        super().__init__(ctx)
        status, self._db_hdl = gsl.gsl_create_clstr_bdb(ctx, cluster)
        if status :
            raise GslException(DatabaseCluster.__name__, status)

        self._num_clusters = len(cluster)

    @property
    def num_clusters(self):
        return self._num_clusters

    def destroy(self):
        gsl.gsl_destroy_clstr_bdb(self._db_hdl)


@dataclass
class FlatHammingDesc:
    max_num_queries: int
    typical_num_queries:int
    rerank_cosine_desc:tuple
    encoding_desc:Encoding
    hamming_bdb:DatabaseBinary
    max_k:int = 0

class Session(ABC):

    def __init__(self, ctx, session_hdl):
        self._ctx = ctx
        self._session_hdl = session_hdl

    @property
    def ctx(self):
        return self._ctx


    @property
    def session_hdl(self):
        return self._session_hdl

    def destroy(self):
        gsl.gsl_search_session_destroy(self._session_hdl)


class FlatHammingSession(Session):

    def __init__(self, context, session_desc):
        self._max_queries = session_desc.max_num_queries
        self._typical_queries = session_desc.typical_num_queries
        self._max_k = session_desc.max_k
        self._rerank_k = None
        self._fdb = None
        self._bdb = session_desc.hamming_bdb
        self._encoding = session_desc.encoding_desc
        self._out_shape_cols = self._max_k
        self._rerank_desc = None

        if session_desc.rerank_cosine_desc:
            self._rerank_k = session_desc.rerank_cosine_desc.k
            self._out_shape_cols = self._rerank_k
            self._fdb = session_desc.rerank_cosine_desc.fdb
            self._rerank_desc = (gsl.GSL_ALG_KNN_COSIM_FDB, self._fdb._db_hdl, self._rerank_k)

        binary = (self._typical_queries, self._max_queries, self._max_k, self._bdb._db_hdl)
        sts, session_hdl = gsl._gsl_flat_hamming_create_search_session(
                               context,
                               binary,
                               self._encoding.data_to_tuple() if self._encoding  else None,
                               self._rerank_desc)

        if sts:
            raise GslException("FlatHammingSession", sts)

        super().__init__(context, session_hdl)


    @property
    def fdb(self):
        return self._fdb

    @property
    def max_k(self):
        return self._max_k

    @property
    def rerank_k(self):
        return self._rerank_k

    @property
    def ctx(self):
        return self._ctx

    @property
    def encoding(self):
        return self._encoding

    @property
    def bdb(self):
        return self._bdb

    @property
    def typical_queries(self):
        self._typical_queries

    @property
    def max_queries(self):
        return self._max_queries

    @property
    def max_k(self):
        return self._max_k

    @classmethod
    def _get_max_k(cls, session_desc):
        binary = (session_desc.typical_num_queries, session_desc.max_num_queries, session_desc.max_k, session_desc.hamming_bdb._db_hdl)
        rerank = None
        if session_desc.rerank_cosine_desc:
            rerank = (gsl.GSL_ALG_KNN_COSIM_FDB, session_desc.rerank_cosine_desc.fdb._db_hdl, session_desc.rerank_cosine_desc.k)

        sts , max_k = gsl._gsl_flat_hamming_get_max_k(binary, session_desc.encoding_desc.data_to_tuple() if session_desc.encoding_desc else None, rerank)
        if sts:
            raise GslException("get_max_k", sts)

        return max_k


    def _search(self, queries, outputs, hold_lock=True, bitmasks=None):
        if self._encoding != None:
            if bitmasks is not None:
                sts = gsl.gsl_flat_hamming_mask_search_f32(self._session_hdl, outputs.indices, outputs.values, queries, bitmasks, hold_lock)
            else:
                sts = gsl.gsl_flat_hamming_search_f32(self._session_hdl, outputs.indices, outputs.values, queries, hold_lock)
        else :
            sts = gsl.gsl_flat_hamming_search_u1(self._session_hdl,outputs.indices, outputs.values, queries, hold_lock)

        if sts:
            raise GslException("search", sts)

        return outputs



    def append_recs(self, records):
        if records.dtype == np.float32:
            sts =  gsl._gsl_flat_hamming_append_recs_f32(self._session_hdl, records)
        elif records.dtype in {np.uint32, np.uint16, np.uint8}:
            sts = gsl._gsl_flat_hamming_append_recs_u1(self._session_hdl, records)


    def remove_recs(self, records_idx, perms=None):
        records_idx = np.resize(records_idx,(1, records_idx.shape[0]))
        if perms is None:
            num_recs_in_row = 2
            perms = np.empty((records_idx.shape[1], num_recs_in_row), np.uint32)

        sts = gsl._gsl_flat_hamming_remove_recs(self._session_hdl, perms, records_idx)
        if sts :
            raise GslException("remove_recs", sts)
        return perms


    def destroy(self):
        super().destroy()


class ClusterHammingSession(Session):

    def __init__(self, context, session_desc):

        self._max_queries = session_desc.max_num_queries
        self._typical_queries = session_desc.typical_num_queries
        self._max_k = session_desc.max_k
        self._centroids_k = session_desc.centroid_k
        self._rerank_k = None
        self._fdb = None
        self._bdb = session_desc.centroid_bdb
        self._cluster_bdb = session_desc.cluster_bdb
        self._encoding_centroids = session_desc.centroids_encoding_desc
        self._encoding_cluster = session_desc.cluster_encoding_desc
        self._rerank_desc = None
        if session_desc.rerank_cosine_desc:
            self._rerank_k = session_desc.rerank_cosine_desc.k
            self._fdb = session_desc.rerank_cosine_desc.fdb
            self._rerank_desc = (gsl.GSL_ALG_KNN_COSIM_FDB, self._fdb._db_hdl, self._rerank_k)

        binary = (self._typical_queries, self._max_queries, self._centroids_k, self._bdb._db_hdl)


        sts, session_hdl = gsl._gsl_clstr_hamming_create_search_session(context,
                                                                        binary,
                                                                        (session_desc.max_k, self._cluster_bdb._db_hdl),
                                                                        self._encoding_centroids.data_to_tuple()  if self._encoding_centroids else None,
                                                                        self._encoding_cluster.data_to_tuple() if self._encoding_cluster else None,
                                                                        self._rerank_desc)

        if sts:
            raise GslException("ClusterHammingSession", sts)

        super().__init__(context, session_hdl)

    @property
    def max_k(self):
        return self._max_k

    def _search(self, queries, outputs, hold_lock=True, bitmasks=None):
        assert(type(outputs) == ClusterOutputs)
        if bitmasks is not None:
            raise TypeError("ClusterHammingSession doesn't support mask search")

        gsl.gsl_clstr_hamming_centroids_search_f32(self._session_hdl, outputs.indices, outputs.clusters, outputs.values, queries, hold_lock)

        return outputs


class TanimotoSession(Session):

    def __init__(self, context, session_desc):

        self._max_num_queries = session_desc.max_num_queries
        self._typical_queries = session_desc.typical_num_queries
        self._max_k = session_desc.max_k
        self._bdb = session_desc.bdb
        binary = (self._typical_queries, self._max_num_queries, self._max_k, self._bdb._db_hdl)
        sts, session_hdl = gsl.gsl_flat_tanimoto_create_search_session(context, binary)
        super().__init__(context, session_hdl)

    def _search(self, queries, outputs, hold_lock=True, bitmasks=None):
        if bitmasks is not None:
            raise TypeError("TanimotoSession doesn't support mask search")

        gsl.gsl_flat_tanimoto_search_u1(self._session_hdl, outputs.indices, outputs.values, queries, hold_lock)

        return outputs

    @property
    def max_k(self):
        return self._max_k

    def destroy(self):
        super().destroy()

class Context:
    def __init__(self, hardware_contexts_ids, max_num_threads=0):
        sts, self._ctx = gsl.gsl_create_context(hardware_contexts_ids, len(hardware_contexts_ids))
        self._session_in_focus = None


    def search_in_focus(self, session_hdl):
        assert(self._ctx == session_hdl.ctx)

        self._session_in_focus = session_hdl
        gsl.gsl_search_in_focus(self._session_in_focus.session_hdl)


    def search(self, queries, outputs, hold_lock=True, bitmasks=None):
        return self._session_in_focus._search(queries, outputs, hold_lock, bitmasks)

    def create_session(self, session):
        if type(session) == FlatHammingDesc:
            return FlatHammingSession(self._ctx, session)
        elif type(session) == ClusterHammingDesc:
            return ClusterHammingSession(self._ctx, session)
        elif type(session) == FlatTanimotoDesc:
            return TanimotoSession(self._ctx, session)
        else:
            raise TypeError

    def destroy_session(self, session_hdl):
        if self._session_in_focus == session_hdl:
            self._session_in_focus = None

        session_hdl.destroy()

    def create_bdb(self, array):
        return DatabaseBinary(self._ctx, array)

    def create_fdb(self, array, normalize):
        return DatabaseFloat(self._ctx, array, normalize)

    def create_cluster_bdb(self, clstrs):
        return DatabaseCluster(self._ctx, clstrs)

    def create_bdb_from_fdb(self, fdb, encoding_desc):
        return DatabaseBinary.create_bdb_from_fdb(self._ctx, fdb, encoding_desc)

    def destroy_fdb(self, db):
        db.destroy()

    def destroy_bdb(self, db):
        db.destroy()

    def destroy_cluster_bdb(self, db):
        db.destroy()

    def append_recs(self, session_hdl, records):
        if type(session_hdl) != FlatHammingSession:
            raise TypeError

        session_hdl.append_recs(records)

    def remove_recs(self, session_hdl, records_indices, perms=None):
        if type(session_hdl) != FlatHammingSession:
            raise TypeError

        session_hdl.remove_recs(records_indices, perms)

    def get_max_k(self, session_desc):
        if type(session_desc) != FlatHammingDesc:
            raise TypeError

        return FlatHammingSession._get_max_k(session_desc)

    def __del__(self):
        gsl.gsl_destroy_context(self._ctx)
