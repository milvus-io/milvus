import gsl_bindings as gsl
import numpy as np
from collections import namedtuple
import gsl_utils

from abc import ABC, abstractmethod


def set_search_session_in_focus(search_session_instance):
    assert(isinstance(search_session_instance, search_session))
    gsl.gsl_search_in_focus(search_session_instance.get_search_session_hdl())

class search_session(ABC):
    bdb_supported_types =  {np.uint16, np.uint8, np.uint32}
    queries_desc = namedtuple('queries_desc', 'typical_num_queries max_num_queries')
    rerank_args = namedtuple('rerank_args', 'knn_alg fdb k')

    def __init__(self, gsl_ctx):
        self._gsl_ctx = gsl_ctx
        self._search_ssesion_hdl = None
        self._bdb_hdl = None
        self._fdb_hdl = None

    @abstractmethod
    def search(self, queries):
        pass

    def get_search_session_hdl(self):
        return self._search_ssesion_hdl

    def destroy(self):
        if self._search_ssesion_hdl != None:
            gsl.gsl_search_session_destroy(self._search_ssesion_hdl)

        if self._bdb_hdl != None:
            gsl.gsl_destroy_bdb(self._bdb_hdl)

        if self._fdb_hdl != None:
            gsl.gsl_destroy_fdb(self._fdb_hdl)

    def create_binary_params(self, np_bdb, queries_desc, k):

        if np_bdb.dtype.type not in search_session.bdb_supported_types:
            raise TypeError('np_bdb type {} is not supported'.format(np_bdb.dtype.type))

        status, self._bdb_hdl = gsl.gsl_create_bdb(self._gsl_ctx, np_bdb)
        if status:
           raise Exception("gsl_create_bdb failed with status {}".format(status))  #todo think on exeption

        return  gsl_utils.binary_params(queries_desc.typical_num_queries, queries_desc.max_num_queries, k, self._bdb_hdl)


    def create_rerank_params(self, rerank_args, normalize=True):

        if rerank_args != None:
            status, self._fdb_hdl = gsl.gsl_create_fdb(self._gsl_ctx, rerank_args.fdb, normalize)
            if status:
                raise Exception("gsl_create_fdb failed with status {}".format(status))

            return gsl_utils.rerank_params(rerank_args.knn_alg, self._fdb_hdl, rerank_args.k)

        return None


class search_session_hamming(search_session):

    def search(self, queries, out_indices=None, out_distances=None, hold_lock=True):

        if out_distances is None:
            out_distances = np.empty((queries.shape[0], self._rerank_args.k if self._rerank_args != None else self._binary_params.k), np.float32)
            out_indices = np.empty(out_distances.shape, np.uint32)

        if self._encoding_args == None:
            s = gsl.gsl_flat_hamming_search_u1(self._search_ssesion_hdl, out_indices, out_distances, queries, hold_lock)
        else:
            s = gsl.gsl_flat_hamming_search_f32(self._search_ssesion_hdl, out_indices, out_distances, queries, hold_lock)

        if s:
            raise Exception("hamming_search failed with status {}".format(s))

        return out_indices, out_distances


    def __init__(self, gsl_ctx, np_bdb, k, queries_desc, encoding_args=None, rerank_args=None):
        super().__init__(gsl_ctx)

        self._encoding_args = encoding_args

        try:
            self._binary_params = search_session.create_binary_params(self, np_bdb, queries_desc, k)
            self._rerank_args = search_session.create_rerank_params(self, rerank_args, encoding_args.normalize if encoding_args != None else None)
        except:
            super().destroy()
            raise

        status, self._search_ssesion_hdl = gsl_utils.flat_hamming_create_search_session(
                                                gsl_ctx, self._binary_params, e=self._encoding_args, r=self._rerank_args)
        if status :
           raise Exception("search_ssesion_hdl failed with status {}".format(status))

    def destroy(self):
        super().destroy()

    def append_recs(self, recs):
        if recs.dtype == np.float32:
            return gsl._gsl_flat_hamming_append_recs_f32(self._search_ssesion_hdl, recs)
        elif recs.dtype in [np.uint32, np.uint16, np.uint8]:
            return gsl._gsl_flat_hamming_append_recs_u1(self._search_ssesion_hdl, recs)
        else:
            raise TypeError('Unxpected record data type')

    def remove_recs(self, recs_idx, perms=None):
        recs_idx = np.resize(recs_idx,(1, recs_idx.shape[0]))
        if perms is None:
            num_recs_in_row = 2
            perms = np.empty((recs_idx.shape[1], num_recs_in_row), np.uint32)



        status = gsl._gsl_flat_hamming_remove_recs(self._search_ssesion_hdl, perms, recs_idx)
        if status :
           raise Exception("gsl_flat_hamming_remove_recs failed with status {}".format(status))

        return perms[(perms != int("0xffffffff", 16)).all(axis=1)]

class search_session_tanimoto(search_session):

    def search(self, queries, out_indices=None, out_distances=None, hold_lock=True):

        if out_distances is None:
            out_distances = np.empty((queries.shape[0], self._binary_params.k), np.float32)
            out_indices = np.empty(out_distances.shape, np.uint32)

        status = gsl.gsl_flat_tanimoto_search_u1(self._search_ssesion_hdl, out_indices, out_distances, queries, hold_lock)
        if status:
            raise Exception('gsl.gsl_clstr_hamming_centroids_search_f32() failed with {}'.format(status))

        return out_indices, out_distances


    def __init__(self, gsl_ctx, np_bdb, k, queries_desc):
        super().__init__(gsl_ctx)

        try:
            self._binary_params = search_session.create_binary_params(self, np_bdb, queries_desc, k)
            _, self._search_ssesion_hdl = gsl.gsl_flat_tanimoto_create_search_session(gsl_ctx, self._binary_params)
        except:
            super().destroy()
            raise


    def destroy(self):
        super().destroy()



class search_session_hamming_clstr(search_session):

    centroids_args = namedtuple('centroids_args', 'k bdb ')
    cluster_args = namedtuple('cluster_args', 'k clstr_list')

    def __init__(self, gsl_ctx, centroids_args, centroids_encoding, cluster_args, cluster_encoding, queries_desc, rerank_args=None):
        super().__init__(gsl_ctx)
        try :
            self._binary_params = search_session.create_binary_params(self, centroids_args.bdb, queries_desc, centroids_args.k)
            self._rerank_args = search_session.create_rerank_params(self, rerank_args, centroids_encoding.normalize)
        except:
           super().destroy()
           raise

        status, clstr_bdbh = gsl.gsl_create_clstr_bdb(gsl_ctx, cluster_args.clstr_list)
        if status:
            super().destroy()
            raise Exception("gsl_create_clstr_bdb failed with status {}".format(status))

        self._clstr_args = gsl_utils.cluster_binary_params(cluster_args.k, clstr_bdbh)

        status, self._search_ssesion_hdl = gsl_utils.clstr_hamming_create_search_session(
            gsl_ctx,
            self._binary_params,
            self._clstr_args,
            centroids_e=centroids_encoding,
            clusters_e=cluster_encoding,
            centroids_r=self._rerank_args)

        if status:
            self.destroy()
            raise Exception('gsl.clstr_hamming_create_search_session() failed with {}'.format(status))


    def search(self, queries, out_indices=None, out_clstrs=None, out_distances=None, hold_lock=True):

        if out_indices is None:
            out_distances = np.empty((queries.shape[0], self._clstr_args.k), np.float32)
            out_indices = np.empty(out_distances.shape, np.uint32)
            out_clstrs = np.empty_like(out_indices)


        status = gsl.gsl_clstr_hamming_centroids_search_f32(self._search_ssesion_hdl, out_indices, out_clstrs, out_distances, queries, hold_lock)
        if status:
            raise Exception('gsl.gsl_clstr_hamming_centroids_search_f32() failed with {}'.format(status))
        return out_indices, out_clstrs, out_distances


    def destroy(self):
        super().destroy()
        gsl.gsl_destroy_clstr_bdb(self._clstr_args.clstr_bdb)

